"""Vector Quantization codebook — compresses Genesis's concept embedding space.

The concept network has thousands of concepts, each with a 210-dimensional
embedding (spectral + TF-IDF + GloVe). Most of these embeddings are
near-duplicates in semantic space — ``dog``, ``puppy``, ``canine`` cluster
tightly. Vector quantization replaces the full set of vectors with a
smaller **codebook** of prototype vectors. Each original vector is encoded
as ``(prototype_id, residual)`` — the prototype plus a small correction.

The residual is quantized to int8 to save space. The reconstruction is::

    vector ≈ codebook[prototype_id] + residual * residual_scale

This reduces storage from ``N × D × 4`` bytes (float32) to
``K × D × 4 + N × (4 + D)`` bytes (codebook + int32 id + int8 residual).
For 12K concepts, 210 dims, 2K prototypes::

    Before: 12,000 × 210 × 4 = 10.1 MB
    After:  2,000 × 210 × 4 + 12,000 × (4 + 210) = 1.7 MB + 2.6 MB = 4.3 MB

The codebook is retrained during algorithmic sleep (N3) via mini-batch
k-means. Concepts that share a prototype with tiny residuals are merge
candidates — the sleep compression pass can fold them together.

# Neuroscience grounding

This models the compression of episodic memories into semantic memory
during sleep consolidation. The hippocampus stores detailed, high-capacity
episodic traces; the neocortex stores compressed, schema-like semantic
knowledge. The codebook prototypes are the "schemas" — the typical
patterns — and the residuals are the episode-specific detail that
distinguishes one instance from another.

(Tononi & Cirelli, 2006; McClelland et al., 1995)
"""

from __future__ import annotations

import logging
import os

import numpy as np

from ._npz_io import load_npz, save_npz, str_array

logger = logging.getLogger(__name__)


class VQCodebook:
    """Vector quantization codebook for concept embeddings.

    Stores K prototype vectors and per-concept encoding (prototype_id +
    int8 residual). The codebook is trained via mini-batch k-means in
    pure numpy (no scipy/sklearn dependency).

    Thread-safe after training. All arrays are read-only post-fit.
    """

    # Default number of prototypes. Actual fidelity is measured by the
    # reconstruction metrics; no fixed quality claim is assumed.
    DEFAULT_K = 2048

    # Number of k-means iterations during training.
    DEFAULT_ITERS = 25

    # Mini-batch size for k-means (controls memory during training).
    DEFAULT_BATCH_SIZE = 1024

    # Residual quantization fallback. Residuals are stored as int8 in
    # [-residual_scale, +residual_scale]. 0.1 was chosen for
    # L2-normalized embeddings where values are in [-1, 1], but real
    # residuals are far smaller — the default construction now derives
    # the scale from the data at fit time; this constant is only the
    # placeholder an explicitly-scaled codebook or a pre-fit save
    # would carry.
    DEFAULT_RESIDUAL_SCALE = 0.1

    # Floor for the fitted scale — keeps an all-zero residual set
    # quantizable (scale must stay positive for encode/save).
    MIN_RESIDUAL_SCALE = 1e-6

    def __init__(
        self,
        dim: int = 210,
        k: int = DEFAULT_K,
        residual_scale: float | None = None,
    ) -> None:
        """Initialize the vector quantization codebook."""
        self.dim = dim
        self.k = k
        # None (the default) fits the int8 range to the data at every
        # fit: the largest residual maps to ±127, so nothing saturates
        # and the quantization floor follows the residual distribution
        # instead of a fixed guess. An explicit scale is honored as-is.
        self._adaptive_residual_scale = residual_scale is None
        self.residual_scale = (
            residual_scale if residual_scale is not None else self.DEFAULT_RESIDUAL_SCALE
        )

        # Trained state
        self._prototypes: np.ndarray = np.zeros((0, dim), dtype=np.float32)
        self._prototype_ids: np.ndarray = np.zeros((0,), dtype=np.int32)
        self._residuals: np.ndarray = np.zeros((0, dim), dtype=np.int8)
        self._concept_names: list[str] = []

        # Statistics from last training
        self._reconstruction_error: float = 0.0
        self._relative_reconstruction_error: float = 0.0
        self._reconstruction_cosine: float = 0.0
        self._residual_saturation_fraction: float = 0.0
        self._training_iters: int = 0

    @property
    def is_trained(self) -> bool:
        """Whether the codebook has been trained."""
        return self._prototypes.shape[0] > 0

    @property
    def n_concepts(self) -> int:
        """Number of concepts currently encoded."""
        return len(self._concept_names)

    @property
    def reconstruction_error(self) -> float:
        """Mean squared reconstruction error from last training."""
        return self._reconstruction_error

    @property
    def relative_reconstruction_error(self) -> float:
        """Mean squared reconstruction error normalized by input energy."""
        return self._relative_reconstruction_error

    @property
    def reconstruction_cosine(self) -> float:
        """Mean per-vector cosine similarity of reconstructed vectors."""
        return self._reconstruction_cosine

    @property
    def residual_saturation_fraction(self) -> float:
        """Fraction of residual coefficients clipped by int8 quantization."""
        return self._residual_saturation_fraction

    @property
    def prototypes(self) -> np.ndarray:
        """The K prototype vectors, shape (K, D)."""
        return self._prototypes

    @property
    def concept_names(self) -> list[str]:
        """Concept names in encoding order."""
        return self._concept_names

    # ─── Training ───────────────────────────────────────────────

    def fit(
        self,
        vectors: np.ndarray,
        concept_names: list[str],
        iters: int = DEFAULT_ITERS,
        batch_size: int = DEFAULT_BATCH_SIZE,
        seed: int = 42,
    ) -> dict[str, float]:
        """Train the codebook via mini-batch k-means.

        Args:
            vectors: (N, D) float32 matrix of concept embeddings.
            concept_names: List of N concept names (parallel to vectors).
            iters: Number of k-means iterations.
            batch_size: Mini-batch size for k-means updates.
            seed: Random seed for reproducibility.

        Returns:
            Dict with raw/normalized reconstruction error, cosine similarity,
            residual saturation, and training dimensions/iterations.
        """
        n, d = vectors.shape
        if d != self.dim:
            self.dim = d
        if len(concept_names) != n:
            raise ValueError("concept_names must have one entry per vector")
        if not np.all(np.isfinite(vectors)):
            raise ValueError("vectors must contain only finite values")
        if not np.isfinite(self.residual_scale) or self.residual_scale <= 0.0:
            raise ValueError("residual_scale must be finite and positive")
        if n == 0:
            # No data to train on — set empty state
            self._reset_to_empty(d)
            return {
                "final_error": 0.0,
                "relative_error": 0.0,
                "cosine": 0.0,
                "saturation": 0.0,
                "iters": 0.0,
                "k": 0.0,
                "n": 0.0,
            }
        k = min(self.k, n)  # can't have more prototypes than points

        gen = self.fit_steps(vectors, concept_names, iters=iters, batch_size=batch_size, seed=seed)
        # fit_steps yields per iteration; run it to completion for
        # the monolithic call. The final value arrives as
        # StopIteration.value.
        for _ in gen:
            pass
        iters = self._training_iters

        stats = {
            "final_error": self._reconstruction_error,
            "relative_error": self._relative_reconstruction_error,
            "cosine": self._reconstruction_cosine,
            "saturation": self._residual_saturation_fraction,
            "iters": float(self._training_iters),
            "k": float(k),
            "n": float(n),
        }
        logger.info(
            "VQ codebook trained: k=%d, n=%d, error=%.6f, iters=%d",
            k,
            n,
            self._reconstruction_error,
            self._training_iters,
        )
        return stats

    def fit_steps(
        self,
        vectors: np.ndarray,
        concept_names: list[str],
        iters: int = DEFAULT_ITERS,
        batch_size: int = DEFAULT_BATCH_SIZE,
        seed: int = 42,
    ):
        """Train the codebook incrementally — one Lloyd iteration per step.

        Identical math to :meth:`fit`, but the training loop is a
        generator: each ``next()`` runs one mini-batch assign+update
        iteration, so a caller can spread a full training pass across
        many small slices — e.g. one iteration per sleep tick, the way
        consolidation actually happens (incrementally across the
        night, not in one blocked pass). Convergence early-exits the
        same way, and ``_encode_all`` runs once at the end.

        Yields:
            ``{"iter": iters_run}`` after each iteration.

        Returns (as ``StopIteration.value``):
            The same stats dict :meth:`fit` returns.
        """
        n, d = vectors.shape
        if d != self.dim:
            self.dim = d
        if len(concept_names) != n:
            raise ValueError("concept_names must have one entry per vector")
        if not np.all(np.isfinite(vectors)):
            raise ValueError("vectors must contain only finite values")
        if not np.isfinite(self.residual_scale) or self.residual_scale <= 0.0:
            raise ValueError("residual_scale must be finite and positive")
        if n == 0:
            self._reset_to_empty(d)
            return {
                "final_error": 0.0,
                "relative_error": 0.0,
                "cosine": 0.0,
                "saturation": 0.0,
                "iters": 0.0,
                "k": 0.0,
                "n": 0.0,
            }
        k = min(self.k, n)

        rng = np.random.default_rng(seed)
        indices = rng.choice(n, size=k, replace=False)
        prototypes = vectors[indices].copy().astype(np.float32)

        prev_error = float("inf")
        iters_run = 0
        for iteration in range(iters):
            batch_n = min(batch_size, n)
            batch_idx = rng.choice(n, size=batch_n, replace=False)
            batch = vectors[batch_idx]

            batch_sq = (batch**2).sum(axis=1, keepdims=True)
            proto_sq = (prototypes**2).sum(axis=1)
            cross = batch @ prototypes.T
            dist_sq = batch_sq + proto_sq - 2 * cross
            assignments = np.argmin(dist_sq, axis=1)

            for ki in range(k):
                mask = assignments == ki
                if mask.any():
                    lr = 1.0 / (1.0 + iteration * 0.1)
                    assigned = batch[mask].mean(axis=0)
                    prototypes[ki] = (1 - lr) * prototypes[ki] + lr * assigned

            iters_run = iteration + 1
            yield {"iter": iters_run}

            error = self._compute_error(vectors, prototypes)
            if abs(prev_error - error) < 1e-6:
                break
            prev_error = error

        self._prototypes = prototypes
        self._training_iters = iters_run
        self._encode_all(vectors, concept_names)

        stats = {
            "final_error": self._reconstruction_error,
            "relative_error": self._relative_reconstruction_error,
            "cosine": self._reconstruction_cosine,
            "saturation": self._residual_saturation_fraction,
            "iters": float(self._training_iters),
            "k": float(k),
            "n": float(n),
        }
        logger.info(
            "VQ codebook trained: k=%d, n=%d, error=%.6f, iters=%d",
            k,
            n,
            self._reconstruction_error,
            self._training_iters,
        )
        return stats

    def _reset_to_empty(self, d: int) -> None:
        """Zero out the trained state for an empty training set."""
        self._prototypes = np.zeros((0, d), dtype=np.float32)
        self._prototype_ids = np.zeros((0,), dtype=np.int32)
        self._residuals = np.zeros((0, d), dtype=np.int8)
        self._concept_names = []
        self._reconstruction_error = 0.0
        self._relative_reconstruction_error = 0.0
        self._reconstruction_cosine = 0.0
        self._residual_saturation_fraction = 0.0
        self._training_iters = 0

    def _compute_error(self, vectors: np.ndarray, prototypes: np.ndarray) -> float:
        """Compute mean squared reconstruction error."""
        # Batch the distance computation to avoid memory issues
        n = vectors.shape[0]
        total_error = 0.0
        batch = 2048
        for i in range(0, n, batch):
            chunk = vectors[i : i + batch]
            chunk_sq = (chunk**2).sum(axis=1, keepdims=True)
            proto_sq = (prototypes**2).sum(axis=1)
            cross = chunk @ prototypes.T
            dist_sq = chunk_sq + proto_sq - 2 * cross
            min_dist = dist_sq.min(axis=1)
            total_error += min_dist.sum()
        return float(total_error / n)

    def _encode_all(self, vectors: np.ndarray, concept_names: list[str]) -> None:
        """Encode all vectors as (prototype_id, int8 residual)."""
        n = vectors.shape[0]

        # Assign each vector to nearest prototype
        prototype_ids = np.empty(n, dtype=np.int32)
        # Batch the assignment
        batch = 2048
        for i in range(0, n, batch):
            chunk = vectors[i : i + batch]
            chunk_sq = (chunk**2).sum(axis=1, keepdims=True)
            proto_sq = (self._prototypes**2).sum(axis=1)
            cross = chunk @ self._prototypes.T
            dist_sq = chunk_sq + proto_sq - 2 * cross
            prototype_ids[i : i + batch] = np.argmin(dist_sq, axis=1)

        # Compute residuals and quantize to int8
        reconstructed = self._prototypes[prototype_ids]
        residuals_f32 = vectors - reconstructed

        # Adaptive scale: map the largest residual to the int8 edge.
        # Saturation is then structurally zero for the fitted set and
        # the quantization noise floor is scale²/12 — derived from the
        # data rather than a constant that can sit orders of magnitude
        # above the actual residuals (a 30x-coarse step quantizes most
        # residuals to 0, so the reported error was the prototype
        # residual itself, uncorrected).
        if self._adaptive_residual_scale:
            max_residual = float(np.abs(residuals_f32).max())
            self.residual_scale = max(max_residual / 127.0, self.MIN_RESIDUAL_SCALE)

        # Quantize: int8 range is [-128, 127]
        # residual_int8 = clip(round(residual / scale), -128, 127)
        scale = self.residual_scale
        quantized = np.round(residuals_f32 / scale)
        clipped = np.clip(quantized, -128, 127)
        self._residual_saturation_fraction = float(np.mean(quantized != clipped))
        residuals_int8 = clipped.astype(np.int8)

        self._prototype_ids = prototype_ids
        self._residuals = residuals_int8
        self._concept_names = list(concept_names)

        # Compute actual reconstruction error with quantized residuals
        recon = self._reconstruct_all()
        error = vectors - recon
        self._reconstruction_error = float(np.mean(error**2))
        input_energy = float(np.sum(vectors * vectors))
        self._relative_reconstruction_error = float(
            np.sum(error * error) / max(input_energy, 1e-12)
        )
        vector_norms = np.linalg.norm(vectors, axis=1)
        recon_norms = np.linalg.norm(recon, axis=1)
        denom = vector_norms * recon_norms
        valid = denom > 1e-12
        if np.any(valid):
            dots = np.sum(vectors[valid] * recon[valid], axis=1)
            self._reconstruction_cosine = float(np.mean(dots / denom[valid]))
        else:
            self._reconstruction_cosine = 0.0

    # ─── Encoding / Decoding ────────────────────────────────────

    def encode(self, vector: np.ndarray) -> tuple[int, np.ndarray]:
        """Encode a single vector as (prototype_id, int8 residual).

        Args:
            vector: (D,) float32 vector.

        Returns:
            Tuple of (prototype_id, residual_int8) where residual is
            (D,) int8.
        """
        if not self.is_trained:
            raise RuntimeError("codebook not trained")
        v = vector.astype(np.float32)
        # Find nearest prototype
        dist_sq = ((self._prototypes - v) ** 2).sum(axis=1)
        pid = int(np.argmin(dist_sq))
        residual = v - self._prototypes[pid]
        residual_int8 = np.clip(
            np.round(residual / self.residual_scale),
            -128,
            127,
        ).astype(np.int8)
        return pid, residual_int8

    def decode(self, prototype_id: int, residual: np.ndarray) -> np.ndarray:
        """Reconstruct a vector from (prototype_id, residual).

        Args:
            prototype_id: Index into the codebook.
            residual: (D,) int8 residual.

        Returns:
            (D,) float32 reconstructed vector.
        """
        if not self.is_trained:
            raise RuntimeError("codebook not trained")
        return self._prototypes[prototype_id] + residual.astype(np.float32) * self.residual_scale

    def reconstruct(self, concept_name: str) -> np.ndarray | None:
        """Reconstruct the vector for a concept.

        Returns None if the concept is not in the codebook.
        """
        if not self.is_trained:
            return None
        try:
            idx = self._concept_names.index(concept_name)
        except ValueError:
            return None
        return self._reconstruct_at(idx)

    def _reconstruct_at(self, idx: int) -> np.ndarray:
        """Reconstruct vector at encoding index."""
        pid = self._prototype_ids[idx]
        residual = self._residuals[idx]
        return self._prototypes[pid] + residual.astype(np.float32) * self.residual_scale

    def _reconstruct_all(self) -> np.ndarray:
        """Reconstruct all vectors."""
        reconstructed = self._prototypes[self._prototype_ids]
        residuals = self._residuals.astype(np.float32) * self.residual_scale
        return reconstructed + residuals

    def reconstruct_all(self) -> np.ndarray:
        """Reconstruct all concept vectors, shape (N, D)."""
        if not self.is_trained:
            raise RuntimeError("codebook not trained")
        return self._reconstruct_all()

    # ─── Merge candidates ───────────────────────────────────────

    def count_merge_candidates(self, threshold: float) -> int:
        """Number of within-prototype pairs closer than ``threshold``.

        This is the cheap half of :meth:`find_merge_candidates`, and it is
        what callers usually want. The full list was being built only to
        be counted and logged: with ~12k concepts in few prototypes that
        is millions of tuples, and materializing them was the single
        largest cost in an N3 sleep pass.
        """
        if not self.is_trained:
            return 0
        recon = self._reconstruct_all()
        threshold_sq = threshold * threshold
        total = 0
        for indices in self._group_indices():
            if len(indices) < 2:
                continue
            block = recon[indices]
            sq = np.einsum("ij,ij->i", block, block)
            diff = sq[:, None] + sq[None, :] - 2.0 * (block @ block.T)
            np.maximum(diff, 0.0, out=diff)
            i_idx, j_idx = np.triu_indices(len(indices), k=1)
            total += int(np.count_nonzero(diff[i_idx, j_idx] < threshold_sq))
        return total

    def find_merge_candidates(
        self,
        threshold: float,
        limit: int | None = 32,
    ) -> list[tuple[str, str, float]]:
        """Closest within-prototype pairs, as (concept_a, concept_b, distance).

        Sorted by distance ascending.

        Args:
            threshold: Maximum L2 distance to be considered a candidate.
            limit: Return at most this many, the closest. Defaults to 32
                because the unbounded case is a trap: with ~12k concepts
                in few prototypes it returns 7.7M tuples and took 142 s of
                a 175 s sleep pass, and the one caller that hit it only
                wanted a count. Pass ``limit=None`` to deliberately get
                everything. Use :meth:`count_merge_candidates` when only
                the number matters — it allocates nothing.
        """
        if not self.is_trained:
            return []

        candidates: list[tuple[float, str, str]] = []
        # One reconstruction shared by every group.
        recon = self._reconstruct_all()
        threshold_sq = threshold * threshold

        for indices in self._group_indices():
            if len(indices) < 2:
                continue
            block = recon[indices]
            # Pairwise L2 via ||a-b||^2 = ||a||^2 + ||b||^2 - 2 a·b, so a
            # group is two matrix products rather than a Python loop with
            # one numpy call per pair.
            sq = np.einsum("ij,ij->i", block, block)
            diff = sq[:, None] + sq[None, :] - 2.0 * (block @ block.T)
            np.maximum(diff, 0.0, out=diff)
            i_idx, j_idx = np.triu_indices(len(indices), k=1)
            close = diff[i_idx, j_idx] < threshold_sq
            if not close.any():
                continue
            ci, cj = i_idx[close], j_idx[close]
            dist = diff[ci, cj]
            if limit is not None and len(ci) > limit:
                # The global top-`limit` holds at most `limit` from any one
                # group, so capping each group here is exact, not lossy.
                keep = np.argpartition(dist, limit - 1)[:limit]
                ci, cj, dist = ci[keep], cj[keep], dist[keep]
            for i, j, d in zip(ci, cj, dist, strict=True):
                candidates.append(
                    (
                        float(d),
                        self._concept_names[int(indices[i])],
                        self._concept_names[int(indices[j])],
                    )
                )

        candidates.sort(key=lambda x: x[0])
        if limit is not None and len(candidates) > limit:
            candidates = candidates[:limit]
        return [(a, b, d) for d, a, b in candidates]

    def _group_indices(self) -> list[list[int]]:
        """Row indices of the reconstructed vectors, grouped by prototype."""
        groups: dict[int, list[int]] = {}
        for i, pid in enumerate(self._prototype_ids):
            groups.setdefault(int(pid), []).append(i)
        return list(groups.values())

    # ─── Persistence ────────────────────────────────────────────

    def save(self, path: str) -> None:
        """Save the codebook to an .npz file."""
        if not self.is_trained:
            raise RuntimeError("cannot save untrained codebook")
        save_npz(
            path,
            prototypes=self._prototypes,
            prototype_ids=self._prototype_ids,
            residuals=self._residuals,
            concept_names=str_array(self._concept_names),
            dim=np.array(self.dim, dtype=np.int32),
            k=np.array(self.k, dtype=np.int32),
            residual_scale=np.array(self.residual_scale, dtype=np.float32),
            reconstruction_error=np.array(self._reconstruction_error, dtype=np.float64),
            relative_reconstruction_error=np.array(
                self._relative_reconstruction_error, dtype=np.float64
            ),
            reconstruction_cosine=np.array(self._reconstruction_cosine, dtype=np.float64),
            residual_saturation_fraction=np.array(
                self._residual_saturation_fraction, dtype=np.float64
            ),
        )

    def load(self, path: str) -> bool:
        """Load the codebook from an .npz file.

        Returns True if loaded, False if file doesn't exist or is
        incompatible.
        """
        if not os.path.exists(path):
            return False
        try:
            data = load_npz(path)
            self._prototypes = data["prototypes"].astype(np.float32)
            self._prototype_ids = data["prototype_ids"].astype(np.int32)
            self._residuals = data["residuals"].astype(np.int8)
            self._concept_names = list(data["concept_names"])
            self.dim = int(data["dim"])
            self.k = int(data["k"])
            self.residual_scale = float(data["residual_scale"])
            self._reconstruction_error = float(data["reconstruction_error"])
            self._relative_reconstruction_error = float(
                data.get("relative_reconstruction_error", 0.0)
            )
            self._reconstruction_cosine = float(data.get("reconstruction_cosine", 0.0))
            self._residual_saturation_fraction = float(
                data.get("residual_saturation_fraction", 0.0)
            )
            return True
        except (KeyError, ValueError, OSError) as e:
            logger.warning("Failed to load VQ codebook: %s", e)
            return False

    # ─── Statistics ─────────────────────────────────────────────

    def compression_ratio(self) -> float:
        """Compute the compression ratio vs. storing full float32 vectors.

        Returns the ratio (uncompressed_size / compressed_size).
        A ratio of 2.0 means the codebook uses half the storage.
        """
        if not self.is_trained:
            return 1.0
        n = len(self._concept_names)
        uncompressed = n * self.dim * 4  # float32
        compressed = (
            self.k * self.dim * 4  # prototypes (float32)
            + n * 4  # prototype_ids (int32)
            + n * self.dim  # residuals (int8)
        )
        return uncompressed / compressed if compressed > 0 else 1.0

    def reconstruction_quality(self) -> float:
        """Return scale-normalized reconstruction quality in [0, 1].

        This is one minus the relative reconstruction error, clamped to
        [0, 1]. The error is measured against the actual stored
        prototype-plus-int8-residual representation from the last fit.
        """
        if not self.is_trained:
            return 0.0
        return float(np.clip(1.0 - self._relative_reconstruction_error, 0.0, 1.0))

    def stats(self) -> dict[str, float]:
        """Return a summary of codebook statistics."""
        return {
            "k": float(self.k) if self.is_trained else 0.0,
            "n_concepts": float(self.n_concepts),
            "dim": float(self.dim),
            "compression_ratio": self.compression_ratio(),
            "reconstruction_error": self._reconstruction_error,
            "relative_reconstruction_error": self._relative_reconstruction_error,
            "reconstruction_cosine": self._reconstruction_cosine,
            "residual_saturation_fraction": self._residual_saturation_fraction,
            "residual_scale": self.residual_scale,
            # Human-facing derivations of the raw error terms — a raw
            # MSE in scientific notation (8.9e-06) reads as "an 8
            # error" on a status line; these carry the same quantity
            # in units that say what they mean.
            "signal_loss_percent": self._relative_reconstruction_error * 100.0,
            "reconstruction_quality": self.reconstruction_quality(),
        }

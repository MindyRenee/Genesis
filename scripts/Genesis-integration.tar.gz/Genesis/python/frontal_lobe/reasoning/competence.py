"""Task competence — domain-general situation → action → skill memory.

This module is the shared substrate underneath domain-specific solvers.
It does not know about grids, tools, code, or conversation. A domain
adapter supplies structured observations and operator names; the
substrate supplies the parts every task needs:

- **Schema recognition:** group states by their structural features,
  available actions, entities, and success conditions rather than by
  surface identity.
- **Affordance learning:** learn which state variables an action
  changes, and with what confidence.
- **Prediction checking:** compare expected effects with observed
  transitions so "solved" means the world actually satisfied a goal.
- **Skill consolidation:** retain verified action sequences and
  retrieve them on structurally similar tasks.

The design separates *schema* from *binding*: the signature says what
kind of situation this is; the concrete state values bind that schema
to the current instance. That mirrors current evidence that task-type
recognition and instance bindings are dissociable, while remaining
small enough to persist as ordinary JSON.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import time
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import TYPE_CHECKING, Any

from genesis_client.swallow import note_swallowed

if TYPE_CHECKING:
    from temporal_lobe.concepts import ConceptNetwork

Scalar = str | int | float | bool | None
State = Mapping[str, Any]

logger = logging.getLogger(__name__)

_MATCH_THRESHOLD = 0.55
_RELIABILITY_OBSERVATIONS = 3.0
# A foreign-domain skill is offered when the task signatures share
# enough schema-level role vocabulary — "constrain", "select" — for an
# analogy to be claimed at all. Variable names can never overlap across
# domains, so roles are the only bridge. 0.2 lets the
# constraint-satisfaction families (sorter/relations/assembly/
# classification) see each other while keeping unrelated families
# (sequence continuation, quantity composition, grid transforms)
# out of reach.
_CROSS_DOMAIN_ROLES = 0.2


def _publishes_evidence(skill: LearnedSkill) -> bool:
    """Whether a foreign skill is readable at all.

    Vocabulary overlap alone is not an analogy — a skill crosses
    domains only when its procedure exposes the normalized
    "support" axis (fraction of an option's constraints satisfied)
    that foreign adapters can rebind onto their own affordance.
    """
    return any(isinstance(step.parameters.get("support"), int | float) for step in skill.steps)


# How an episode's success was established, weakest to strongest:
# - "reported": a caller asserted success; nothing checked it.
# - "solver": an epistemic verifier (e.g. ProblemSolver) confirmed —
#   knowledge-level truth, not observed world change.
# - "external": a world-state check observed the outcome — exact
#   replay, an environment's terminal condition, or a real actuator.
VERIFICATION_KINDS: tuple[str, ...] = ("reported", "solver", "external")
_VERIFICATION_RANK = {kind: rank for rank, kind in enumerate(VERIFICATION_KINDS)}
# Transfer weight by evidence strength — a procedure verified only
# epistemically carries less authority than one checked against the
# world, and an unverified report carries least.
_VERIFICATION_WEIGHT = {"reported": 0.5, "solver": 0.8, "external": 1.0}

# Neuromodulatory consolidation floor — episodes encoded under
# dopamine/arousal below this stay episodic; they don't
# proceduralize into skills.
_SALIENCE_FLOOR = 0.2


def verification_rank(kind: str) -> int:
    """Rank of a verification kind; unknown kinds count as reported."""
    return _VERIFICATION_RANK.get(kind, 0)


def verification_weight(kind: str) -> float:
    """Transfer-confidence weight of a verification kind."""
    return _VERIFICATION_WEIGHT.get(kind, 0.5)


def _canonical(value: Any) -> str:
    """Return a stable, JSON-safe representation of structured data."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _hash(parts: Any) -> str:
    return hashlib.sha256(_canonical(parts).encode("utf-8")).hexdigest()[:16]


def _scalar(value: Any) -> Scalar:
    if value is None or isinstance(value, str | int | float | bool):
        return value
    return _canonical(value)


def _flatten_state(state: State, prefix: str = "") -> dict[str, Scalar]:
    """Flatten a structured observation into named scalar variables."""
    flat: dict[str, Scalar] = {}
    for key, value in state.items():
        name = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(value, Mapping):
            flat.update(_flatten_state(value, name))
        elif isinstance(value, Sequence) and not isinstance(value, str | bytes | bytearray):
            if all(item is None or isinstance(item, str | int | float | bool) for item in value):
                flat[name] = _canonical(list(value))
            else:
                for i, item in enumerate(value):
                    if isinstance(item, Mapping):
                        flat.update(_flatten_state(item, f"{name}.{i}"))
                    else:
                        flat[f"{name}.{i}"] = _scalar(item)
        elif isinstance(value, set | frozenset):
            flat[name] = _canonical(sorted(value, key=repr))
        else:
            flat[name] = _scalar(value)
    return flat


def _feature_set(state: State) -> frozenset[str]:
    """Extract schema-level features from a state observation.

    Concrete values are bindings, not schema identity. The signature
    therefore keeps variable names and qualitative buckets rather than
    every literal value.
    """
    features: set[str] = set()
    for key, value in _flatten_state(state).items():
        features.add(key)
        if isinstance(value, bool):
            if value:
                features.add(f"{key}:true")
        elif isinstance(value, int | float):
            if value == 0:
                bucket = "zero"
            elif value > 0:
                bucket = "positive"
            else:
                bucket = "negative"
            features.add(f"{key}:{bucket}")
        elif isinstance(value, str) and value:
            features.add(f"{key}:{value}")
    return frozenset(features)


def _jaccard(a: frozenset[str], b: frozenset[str]) -> float:
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _as_float(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int | float):
        return float(value)
    return None


_ACTION_TOKEN_RE = re.compile(r"[A-Za-z0-9]+")


def _action_tokens(action: str) -> tuple[str, ...]:
    """Decompose an action name into its lexical tokens.

    Adapters name operators with surface structure — ``align_ravel``,
    ``move_north_2`` — and the shared spans between names are the only
    evidence that two actions play the same role. Opaque single-token
    names simply yield no patterns and are unaffected.
    """
    return tuple(_ACTION_TOKEN_RE.findall(action.lower()))


def _pattern_matches(tokens: tuple[str, ...], pattern: tuple[str, ...]) -> bool:
    return len(tokens) == len(pattern) and all(
        p == "*" or p == t for p, t in zip(pattern, tokens, strict=True)
    )


def _state_shape(features: frozenset[str]) -> frozenset[str]:
    """The nameless qualitative shape of a signature's state features.

    Signatures carry concrete names (``amber``, ``amber:true``) that can
    never overlap across domains. The shape drops the names and keeps
    the qualitative structure — "one variable present", "one variable
    true", "one variable positive" — so ``{amber, amber:true}`` and
    ``{ochre, ochre:true}`` collapse to the same shape. This is what
    lets a learned conditional transfer at all: "the flag was set" is
    a property of the situation's form, not its vocabulary.
    """
    shape: set[str] = set()
    for feature in features:
        if ":" in feature:
            _, bucket = feature.rsplit(":", 1)
            if bucket == "true":
                shape.add("var:true")
            elif bucket in ("zero", "positive", "negative"):
                shape.add(f"var:num:{bucket}")
            else:
                shape.add("var:value")
        else:
            shape.add("var")
    return frozenset(shape)


def _shape_key(features: frozenset[str]) -> str:
    return _canonical(sorted(features))


@dataclass(frozen=True, slots=True)
class GoalCondition:
    """A serializable success predicate over a state variable."""

    key: str
    op: str = "eq"
    value: Any = True
    weight: float = 1.0
    tolerance: float = 1e-9

    def descriptor(self) -> str:
        return f"{self.key}|{self.op}|{_canonical(self.value)}"

    def score(self, state: Mapping[str, Scalar]) -> float:
        """Return how satisfied this condition is, in ``[0, 1]``."""
        present = self.key in state and state[self.key] is not None
        actual = state.get(self.key)
        if self.op == "exists":
            return 1.0 if present else 0.0
        if self.op == "missing":
            return 0.0 if present else 1.0
        if not present:
            return 0.0
        if self.op == "truthy":
            return 1.0 if bool(actual) else 0.0
        if self.op == "contains":
            try:
                return 1.0 if self.value in actual else 0.0  # type: ignore[operator]
            except TypeError:
                return 0.0

        a_num = _as_float(actual)
        e_num = _as_float(self.value)
        if self.op == "eq":
            if a_num is not None and e_num is not None:
                scale = max(abs(e_num), self.tolerance, 1.0)
                return max(0.0, 1.0 - abs(a_num - e_num) / scale)
            return 1.0 if actual == self.value else 0.0
        if self.op == "neq":
            return 0.0 if actual == self.value else 1.0
        if a_num is None or e_num is None:
            return 0.0
        if self.op == "lt":
            return 1.0 if a_num < e_num else 0.0
        if self.op == "le":
            return 1.0 if a_num <= e_num else 0.0
        if self.op == "gt":
            return 1.0 if a_num > e_num else 0.0
        if self.op == "ge":
            return 1.0 if a_num >= e_num else 0.0
        return 0.0

    def satisfied(self, state: Mapping[str, Scalar]) -> bool:
        return self.score(state) >= 1.0 - 1e-9

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "op": self.op,
            "value": self.value,
            "weight": self.weight,
            "tolerance": self.tolerance,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> GoalCondition:
        """Reconstruct a GoalCondition from a serialized mapping."""
        return cls(
            key=str(data["key"]),
            op=str(data.get("op", "eq")),
            value=data.get("value", True),
            weight=float(data.get("weight", 1.0)),
            tolerance=float(data.get("tolerance", 1e-9)),
        )


@dataclass(frozen=True, slots=True)
class TaskSignature:
    """The abstract identity of a task, independent of bound values.

    ``roles`` is the schema-level vocabulary: domain-independent
    structural tags an adapter emits (``"self"``, ``"navigate"``,
    ``"procedure"``…). Where ``state``/``actions``/``entities`` carry
    domain terms that can never match across domains, roles are what
    lets "approach a target while avoiding movers" in one engine look
    like the same family in another.
    """

    domain: str
    state: frozenset[str]
    actions: frozenset[str]
    goals: frozenset[str]
    entities: frozenset[str] = frozenset()
    roles: frozenset[str] = frozenset()

    def similarity(self, other: TaskSignature) -> float:
        """Structural similarity across state, affordances, and goals."""
        # Roles only count when at least one side claims them — two
        # role-less signatures are not thereby identical.
        role_overlap = _jaccard(self.roles, other.roles) if self.roles or other.roles else 0.0
        score = (
            0.35 * _jaccard(self.state, other.state)
            + 0.16 * _jaccard(self.actions, other.actions)
            + 0.24 * _jaccard(self.goals, other.goals)
            + 0.08 * _jaccard(self.entities, other.entities)
            + 0.17 * role_overlap
        )
        # A different domain can still be analogous, but it should not
        # look identical merely because the feature names overlap.
        return score if self.domain == other.domain else score * 0.72

    def key(self) -> str:
        return _hash(
            {
                "domain": self.domain,
                "state": sorted(self.state),
                "actions": sorted(self.actions),
                "goals": sorted(self.goals),
                "entities": sorted(self.entities),
                "roles": sorted(self.roles),
            }
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "domain": self.domain,
            "state": sorted(self.state),
            "actions": sorted(self.actions),
            "goals": sorted(self.goals),
            "entities": sorted(self.entities),
            "roles": sorted(self.roles),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TaskSignature:
        """Reconstruct a TaskSignature from a serialized mapping."""
        return cls(
            domain=str(data.get("domain", "general")),
            state=frozenset(str(v) for v in data.get("state", [])),
            actions=frozenset(str(v) for v in data.get("actions", [])),
            goals=frozenset(str(v) for v in data.get("goals", [])),
            entities=frozenset(str(v) for v in data.get("entities", [])),
            roles=frozenset(str(v) for v in data.get("roles", [])),
        )


@dataclass(slots=True)
class EffectPrediction:
    """A predicted state-variable change for one action."""

    key: str
    kind: str
    expected: Scalar
    confidence: float
    delta: float | None = None

    def matches(self, actual: Scalar) -> bool:
        if self.kind == "delta":
            a_num = _as_float(actual)
            e_num = _as_float(self.expected)
            return a_num is not None and e_num is not None and abs(a_num - e_num) <= 1e-6
        return actual == self.expected

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "kind": self.kind,
            "expected": self.expected,
            "confidence": self.confidence,
            "delta": self.delta,
        }


@dataclass(slots=True)
class TransitionCheck:
    """Expected-vs-observed result for one action."""

    action: str
    predicted: tuple[EffectPrediction, ...]
    observed_changes: tuple[str, ...]
    score: float
    mismatches: tuple[str, ...]


@dataclass(slots=True)
class EffectModel:
    """Learned effect distribution for one state variable."""

    key: str
    observations: int = 0
    unchanged: int = 0
    changed: int = 0
    numeric_changes: int = 0
    delta_sum: float = 0.0
    to_counts: dict[str, int] = field(default_factory=dict)
    to_values: dict[str, Scalar] = field(default_factory=dict)

    def observe(self, before: Scalar, after: Scalar) -> None:
        self.observations += 1
        if before == after:
            self.unchanged += 1
            return
        self.changed += 1
        b_num = _as_float(before)
        a_num = _as_float(after)
        if b_num is not None and a_num is not None:
            self.numeric_changes += 1
            self.delta_sum += a_num - b_num
            outcome = "delta"
            value: Scalar = None
        elif before is None:
            outcome = "added"
            value = after
        elif after is None:
            outcome = "removed"
            value = None
        else:
            outcome = "set"
            value = after
        canonical = _canonical(value)
        key = f"{outcome}:{canonical}"
        self.to_counts[key] = self.to_counts.get(key, 0) + 1
        self.to_values[key] = value

    def predict(self, before: Scalar) -> EffectPrediction | None:
        if self.observations == 0:
            return None
        reliability = min(1.0, self.observations / _RELIABILITY_OBSERVATIONS)
        if self.unchanged >= self.changed:
            confidence = (self.unchanged / self.observations) * reliability
            return EffectPrediction(self.key, "unchanged", before, confidence, delta=0.0)
        outcome, count = max(self.to_counts.items(), key=lambda kv: kv[1])
        confidence = (count / self.observations) * reliability
        if outcome.startswith("delta:"):
            delta = self.delta_sum / max(1, self.numeric_changes)
            b_num = _as_float(before)
            expected: Scalar = None if b_num is None else b_num + delta
            return EffectPrediction(self.key, "delta", expected, confidence, delta=delta)
        return EffectPrediction(
            self.key,
            outcome.split(":", 1)[0],
            self.to_values.get(outcome),
            confidence,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "observations": self.observations,
            "unchanged": self.unchanged,
            "changed": self.changed,
            "numeric_changes": self.numeric_changes,
            "delta_sum": self.delta_sum,
            "to_counts": dict(self.to_counts),
            "to_values": dict(self.to_values),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> EffectModel:
        """Reconstruct an EffectModel from a serialized mapping."""
        return cls(
            key=str(data["key"]),
            observations=int(data.get("observations", 0)),
            unchanged=int(data.get("unchanged", 0)),
            changed=int(data.get("changed", 0)),
            numeric_changes=int(data.get("numeric_changes", 0)),
            delta_sum=float(data.get("delta_sum", 0.0)),
            to_counts={str(k): int(v) for k, v in data.get("to_counts", {}).items()},
            to_values={str(k): _scalar(v) for k, v in data.get("to_values", {}).items()},
        )


@dataclass(slots=True)
class OperatorModel:
    """Learned affordance model for one named action/operator.

    ``effects`` is the unconditional record; ``conditional`` holds the
    same evidence split by the qualitative state shape it was observed
    under. The split is what separates "this action changes this
    variable" from "this action changes this variable *when the flag
    is set*" — a model that averaged over the deciding condition would
    predict wrongly half the time while looking confident.
    """

    action: str
    uses: int = 0
    successes: int = 0
    failures: int = 0
    effects: dict[str, EffectModel] = field(default_factory=dict)
    conditional: dict[str, dict[str, EffectModel]] = field(default_factory=dict)

    @property
    def confidence(self) -> float:
        return (self.successes + 0.5) / (self.uses + 1.0)

    def to_dict(self) -> dict[str, Any]:
        return {
            "action": self.action,
            "uses": self.uses,
            "successes": self.successes,
            "failures": self.failures,
            "effects": [e.to_dict() for e in self.effects.values()],
            "conditional": {
                shape: [e.to_dict() for e in effects.values()]
                for shape, effects in self.conditional.items()
            },
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> OperatorModel:
        """Reconstruct an OperatorModel from a serialized mapping."""
        op = cls(
            action=str(data["action"]),
            uses=int(data.get("uses", 0)),
            successes=int(data.get("successes", 0)),
            failures=int(data.get("failures", 0)),
        )
        for effect in data.get("effects", []):
            model = EffectModel.from_dict(effect)
            op.effects[model.key] = model
        for shape, effects in dict(data.get("conditional", {})).items():
            bucket: dict[str, EffectModel] = {}
            for effect in effects:
                model = EffectModel.from_dict(effect)
                bucket[model.key] = model
            op.conditional[str(shape)] = bucket
        return op


@dataclass(slots=True)
class TaskSchema:
    """A learned task frame: signature plus operators and skills."""

    schema_id: str
    signature: TaskSignature
    episodes: int = 0
    successes: int = 0
    failures: int = 0
    operators: dict[str, OperatorModel] = field(default_factory=dict)
    skill_ids: list[str] = field(default_factory=list)
    last_score: float = 0.0
    # Affordance order as the adapter presented it — the positional
    # vocabulary that lets foreign skills rebind by structure when no
    # action names are shared.
    action_order: list[str] = field(default_factory=list)
    # Lifted operator models: (token-pattern, state-shape) → aggregate
    # evidence across every concrete action matching the pattern under
    # that state shape. This is the induction layer — "align_* solves
    # when the flag is true" learned from outcomes, so held-out
    # bindings like ``align_merek`` inherit a prediction.
    lifted: dict[tuple[str, str], OperatorModel] = field(default_factory=dict)
    # Which proposal families solved tasks of this schema — the
    # learned search prior. "Learning to search": the solver's
    # proposal ordering adapts per task family, not just globally.
    family_priors: dict[str, int] = field(default_factory=dict)
    # Named falsifiable beliefs about this task family — mechanics
    # rules and inferred goal/avoid conditions, verified against the
    # transition stream. A ``HypothesisLedger`` once materialized;
    # lazily created because ``reasoning.hypotheses`` imports this
    # module (the import lives inside the accessors).
    hypotheses: Any = None

    @property
    def confidence(self) -> float:
        return (self.successes + 0.5) / (self.episodes + 1.0)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_id": self.schema_id,
            "signature": self.signature.to_dict(),
            "episodes": self.episodes,
            "successes": self.successes,
            "failures": self.failures,
            "operators": [op.to_dict() for op in self.operators.values()],
            "skill_ids": list(self.skill_ids),
            "last_score": self.last_score,
            "action_order": list(self.action_order),
            "lifted": [
                {
                    "pattern": pattern,
                    "shape": shape,
                    "model": model.to_dict(),
                }
                for (pattern, shape), model in self.lifted.items()
            ],
            "family_priors": dict(self.family_priors),
            "hypotheses": (self.hypotheses.to_dict() if self.hypotheses is not None else None),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> TaskSchema:
        """Reconstruct a TaskSchema from a serialized mapping."""
        schema = cls(
            schema_id=str(data["schema_id"]),
            signature=TaskSignature.from_dict(data.get("signature", {})),
            episodes=int(data.get("episodes", 0)),
            successes=int(data.get("successes", 0)),
            failures=int(data.get("failures", 0)),
            skill_ids=[str(s) for s in data.get("skill_ids", [])],
            last_score=float(data.get("last_score", 0.0)),
            family_priors={str(k): int(v) for k, v in dict(data.get("family_priors", {})).items()},
        )
        for op_data in data.get("operators", []):
            op = OperatorModel.from_dict(op_data)
            schema.operators[op.action] = op
        schema.action_order = [str(a) for a in data.get("action_order", [])]
        for lifted_data in data.get("lifted", []):
            model = OperatorModel.from_dict(lifted_data.get("model", {}))
            schema.lifted[
                (
                    str(lifted_data.get("pattern", "")),
                    str(lifted_data.get("shape", "")),
                )
            ] = model
        hyp_data = data.get("hypotheses")
        if hyp_data:
            from .hypotheses import HypothesisLedger

            schema.hypotheses = HypothesisLedger.from_dict(hyp_data)
        return schema


@dataclass(frozen=True, slots=True)
class ProcedureStep:
    """One serializable step in a reusable procedure.

    ``position`` is the action's ordinal in the affordance list the
    adapter presented at learning time — the step's *structural*
    identity, independent of its name. It is what lets a foreign
    domain rebind the step: when two domains share no vocabulary,
    "the action that was second in the list" is still meaningful.
    """

    action: str
    parameters: dict[str, Any] = field(default_factory=dict)
    family: str = ""
    description: str = ""
    position: int | None = None

    @property
    def label(self) -> str:
        if self.description:
            return self.description
        if not self.parameters:
            return self.action
        args = ", ".join(f"{k}={v}" for k, v in self.parameters.items())
        return f"{self.action}({args})"

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "action": self.action,
            "parameters": self.parameters,
            "family": self.family,
            "description": self.description or self.label,
        }
        if self.position is not None:
            data["position"] = self.position
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> ProcedureStep:
        """Reconstruct a ProcedureStep from a serialized mapping."""
        position = data.get("position")
        return cls(
            action=str(data["action"]),
            parameters=dict(data.get("parameters", {})),
            family=str(data.get("family", "")),
            description=str(data.get("description", "")),
            position=int(position) if position is not None else None,
        )


@dataclass(slots=True)
class LearnedSkill:
    """A verified procedure reusable under a task schema.

    ``verification`` records the strongest evidence behind the skill:
    "reported" (asserted), "solver" (epistemically verified), or
    "external" (checked against observed world state).
    """

    skill_id: str
    signature: TaskSignature
    steps: tuple[ProcedureStep, ...]
    success_conditions: tuple[GoalCondition, ...]
    uses: int = 1
    successes: int = 1
    failures: int = 0
    verification_score: float = 1.0
    verification: str = "reported"
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    @property
    def confidence(self) -> float:
        return (self.successes + 0.5) / (self.uses + self.failures + 1.0)

    def step_labels(self) -> tuple[str, ...]:
        return tuple(step.label for step in self.steps)

    def to_dict(self) -> dict[str, Any]:
        return {
            "skill_id": self.skill_id,
            "signature": self.signature.to_dict(),
            "steps": [s.to_dict() for s in self.steps],
            "success_conditions": [g.to_dict() for g in self.success_conditions],
            "uses": self.uses,
            "successes": self.successes,
            "failures": self.failures,
            "verification_score": self.verification_score,
            "verification": self.verification,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> LearnedSkill:
        """Reconstruct a LearnedSkill from a serialized mapping."""
        return cls(
            skill_id=str(data["skill_id"]),
            signature=TaskSignature.from_dict(data.get("signature", {})),
            steps=tuple(ProcedureStep.from_dict(s) for s in data.get("steps", [])),
            success_conditions=tuple(
                GoalCondition.from_dict(g) for g in data.get("success_conditions", [])
            ),
            uses=int(data.get("uses", 1)),
            successes=int(data.get("successes", 1)),
            failures=int(data.get("failures", 0)),
            verification_score=float(data.get("verification_score", 1.0)),
            # Older saves carry no provenance — "reported" is the
            # honest default, not an upgrade to "external".
            verification=str(data.get("verification", "reported")),
            created_at=float(data.get("created_at", time.time())),
            updated_at=float(data.get("updated_at", time.time())),
        )


@dataclass(slots=True)
class SkillMatch:
    """A retrieved skill plus its structural match evidence."""

    skill: LearnedSkill
    similarity: float
    score: float


@dataclass(slots=True)
class TaskContext:
    """The result of recognizing a task instance.

    ``action_order`` is the affordance order the adapter presented
    for *this* instance — the per-episode positional index skills are
    bound to. (``schema.action_order`` accumulates a family's whole
    vocabulary across merged trials, so it cannot index an episode.)
    """

    signature: TaskSignature
    schema: TaskSchema
    similarity: float
    novel: bool
    skills: tuple[SkillMatch, ...] = ()
    action_order: tuple[str, ...] = ()


class TaskCompetence:
    """Domain-general task-schema, transition, and skill memory.

    Adapters remain responsible for acting in the world. This class
    owns the shared structures that let an adapter recognize a task,
    learn what actions do, verify outcomes, and reuse a verified
    procedure on a structurally similar task.
    """

    def __init__(
        self,
        *,
        match_threshold: float = _MATCH_THRESHOLD,
        network: ConceptNetwork | None = None,
        salience_getter: Callable[[], float] | None = None,
    ) -> None:
        self.match_threshold = match_threshold
        self.network = network
        # Neuromodulation is broadcast, not addressed — every adapter
        # that consolidates reads the same ambient dopamine/arousal
        # state instead of each caller threading it through.
        self.salience_getter = salience_getter
        self.schemas: dict[str, TaskSchema] = {}
        self.skills: dict[str, LearnedSkill] = {}
        self.transition_count = 0

    def _ambient_salience(self) -> float:
        """Current neuromodulatory gain; 1.0 when unmodulated."""
        if self.salience_getter is None:
            return 1.0
        try:
            return max(0.0, min(1.0, float(self.salience_getter())))
        except Exception:  # noqa: BLE001 — a broken gauge must not
            return 1.0  # block consolidation; treat as unmodulated

    def make_signature(
        self,
        *,
        domain: str,
        state: State,
        actions: Iterable[str] = (),
        goal_conditions: Iterable[GoalCondition | str] = (),
        entities: Iterable[str] = (),
        roles: Iterable[str] = (),
    ) -> TaskSignature:
        goals = frozenset(
            g.descriptor() if isinstance(g, GoalCondition) else str(g) for g in goal_conditions
        )
        # Goal *shape* is schema-level vocabulary: "drive a variable
        # to equality" matches across domains even when the variable
        # names don't. Bound descriptors stay in ``goals``.
        role_set = {str(r) for r in roles}
        for g in goal_conditions:
            if isinstance(g, GoalCondition):
                role_set.add(f"goal:{g.op}")
        return TaskSignature(
            domain=domain,
            state=_feature_set(state),
            actions=frozenset(str(a) for a in actions),
            goals=goals,
            entities=frozenset(str(e) for e in entities),
            roles=frozenset(role_set),
        )

    def recognize(
        self,
        *,
        domain: str,
        state: State,
        actions: Iterable[str] = (),
        goal_conditions: Iterable[GoalCondition | str] = (),
        entities: Iterable[str] = (),
        roles: Iterable[str] = (),
    ) -> TaskContext:
        """Recognize a situation as an existing schema or a novel one."""
        ordered_actions = tuple(str(a) for a in actions)
        signature = self.make_signature(
            domain=domain,
            state=state,
            actions=ordered_actions,
            goal_conditions=goal_conditions,
            entities=entities,
            roles=roles,
        )
        schema_id = signature.key()
        exact = self.schemas.get(schema_id)
        best: tuple[TaskSchema, float] | None = None
        if exact is None:
            for schema in self.schemas.values():
                similarity = signature.similarity(schema.signature)
                if best is None or similarity > best[1]:
                    best = (schema, similarity)
        if exact is not None:
            schema, similarity, novel = exact, 1.0, False
        elif best is not None and best[1] >= self.match_threshold:
            schema, similarity, novel = best[0], best[1], False
        else:
            schema = TaskSchema(schema_id=schema_id, signature=signature)
            self.schemas[schema_id] = schema
            similarity, novel = 0.0, True
        # Remember the affordance order the adapter presented — it is
        # the positional vocabulary skills are rebound through when a
        # foreign domain shares no action names.
        for name in ordered_actions:
            if name not in schema.action_order:
                schema.action_order.append(name)
        return TaskContext(
            signature=signature,
            schema=schema,
            similarity=similarity,
            novel=novel,
            skills=tuple(self.skill_matches(signature)),
            action_order=ordered_actions,
        )

    def skill_matches(self, signature: TaskSignature, *, limit: int = 4) -> list[SkillMatch]:
        """Retrieve reusable skills, vocabulary-aligned first.

        Skills that clear full-signature similarity are offered
        first — including foreign skills whose concrete vocabulary
        genuinely aligns (the domain discount lives in
        ``TaskSignature.similarity``).

        Skills from other domains that cannot clear the full bar can
        still transfer on abstract structure alone: shared schema-level
        roles plus a readable procedure interface — a "support" axis
        the foreign adapter can rebind. For a cross match,
        ``SkillMatch.similarity`` carries the role overlap, not the
        full-signature score. Foreign skills are always ranked below
        similarity matches and capped separately, so they can inform
        but never crowd out vocabulary-aligned evidence.
        """
        same: list[SkillMatch] = []
        cross: list[SkillMatch] = []
        for skill in self.skills.values():
            similarity = signature.similarity(skill.signature)
            if similarity >= self.match_threshold:
                score = 0.68 * similarity + 0.32 * skill.confidence
                # Procedures backed by weaker verification transfer with
                # less authority: a reported or solver-only skill must
                # not outrank one checked against the world.
                score *= verification_weight(skill.verification)
                same.append(SkillMatch(skill, similarity, score))
                continue
            if skill.signature.domain == signature.domain:
                continue
            overlap = _jaccard(signature.roles, skill.signature.roles)
            if overlap < _CROSS_DOMAIN_ROLES or not _publishes_evidence(skill):
                continue
            score = 0.68 * overlap + 0.32 * skill.confidence
            score *= verification_weight(skill.verification)
            cross.append(SkillMatch(skill, overlap, score))
        same.sort(key=lambda m: (-m.score, m.skill.skill_id))
        cross.sort(key=lambda m: (-m.score, m.skill.skill_id))
        return (same[: limit - 1] + cross[:2])[:limit]

    def predict(
        self,
        context: TaskContext,
        action: str,
        state: State,
    ) -> tuple[EffectPrediction, ...]:
        """Predict the state variables an action is likely to change.

        Evidence resolves most-specific first: the concrete operator
        model for this exact action, then the lifted pattern induced
        from siblings under the same qualitative state shape, then a
        foreign skill rebound positionally onto this schema's
        affordance order. Each layer is weaker evidence than the last
        and each is real — an action never carried a prediction it
        could not have earned.
        """
        op = context.schema.operators.get(action)
        effects: dict[str, EffectModel] | None = None
        if op is not None:
            effects = op.effects
            if op.conditional:
                # Condition-scoped evidence exists. Under a shape that
                # was never observed the honest answer is abstention,
                # not an average over a condition that may decide the
                # outcome — the lifted and rebinding layers get their
                # say next.
                shape = _shape_key(_state_shape(context.signature.state))
                effects = op.conditional.get(shape, {})
        if op is None:
            op = self._lifted_operator(context, action)
            if op is not None:
                # Lifted models are already shape-keyed — their
                # effects are conditional evidence by construction.
                effects = op.effects
        before = _flatten_state(state)
        predictions: list[EffectPrediction] = []
        if effects:
            for key, effect in effects.items():
                prediction = effect.predict(before.get(key))
                if prediction is not None and prediction.kind != "unchanged":
                    predictions.append(prediction)
            predictions.sort(key=lambda p: (-p.confidence, p.key))
        if not predictions:
            predictions = self._rebound_predictions(context, action)
        return tuple(predictions)

    def _lifted_operator(self, context: TaskContext, action: str) -> OperatorModel | None:
        """The induced pattern model for an unobserved action name.

        A lifted model exists only where ≥2 concrete actions share a
        token frame (e.g. ``align_ravel``/``align_tavi`` → ``align_*``)
        and is keyed by the qualitative state shape it was learned
        under — so the induced rule is conditional: "this action role
        works when the flag is set", not merely "it worked once".
        """
        tokens = _action_tokens(action)
        if len(tokens) < 2:
            return None
        shape = _shape_key(_state_shape(context.signature.state))
        best: OperatorModel | None = None
        for (pattern, pattern_shape), model in context.schema.lifted.items():
            if pattern_shape != shape:
                continue
            if not _pattern_matches(tokens, tuple(pattern.split("_"))):
                continue
            if best is None or model.uses > best.uses:
                best = model
        return best

    def _rebound_predictions(self, context: TaskContext, action: str) -> list[EffectPrediction]:
        """Predictions from a foreign skill rebound by position.

        A retrieved cross-domain skill is weaker evidence than learned
        affordances — it says "in an analogous situation, the action
        at this position reached the goal" — but under a matching
        state shape it is real, falsifiable evidence rather than
        silence. Restricted to foreign skills: same-domain transfer
        already flows through operator and lifted models.
        """
        order = context.action_order or tuple(context.schema.action_order)
        if not order:
            return []
        shape = _state_shape(context.signature.state)
        predictions: list[EffectPrediction] = []
        for match in context.skills:
            skill = match.skill
            if skill.signature.domain == context.signature.domain:
                continue
            if _state_shape(skill.signature.state) != shape:
                continue
            for step in skill.steps:
                if step.position is None or step.position >= len(order):
                    continue
                if order[step.position] != action:
                    continue
                for goal in skill.success_conditions:
                    if goal.op not in ("eq", "truthy", "exists"):
                        continue
                    expected = True if goal.op != "eq" else goal.value
                    predictions.append(
                        EffectPrediction(
                            goal.key,
                            "set",
                            expected,
                            match.score * 0.5,
                        )
                    )
        return predictions

    def record_transition(
        self,
        context: TaskContext,
        action: str,
        before: State,
        after: State,
        *,
        success: bool | None = None,
    ) -> TransitionCheck:
        """Learn an action's effects from one observed transition.

        The returned check scores the prediction made *before* the new
        evidence was incorporated, so a surprising transition is visible
        as a low score rather than silently rewritten.
        """
        predicted = self.predict(context, action, before)
        before_flat = _flatten_state(before)
        after_flat = _flatten_state(after)
        observed_changes = tuple(
            key
            for key in before_flat.keys() | after_flat.keys()
            if before_flat.get(key) != after_flat.get(key)
        )
        correct = 0
        mismatches: list[str] = []
        predicted_keys = {p.key for p in predicted}
        for prediction in predicted:
            actual = after_flat.get(prediction.key)
            if prediction.matches(actual):
                correct += 1
            else:
                mismatches.append(
                    f"{prediction.key}: expected {prediction.expected!r}, observed {actual!r}"
                )
        missed = [k for k in observed_changes if k not in predicted_keys]
        mismatches.extend(f"{k}: unpredicted change" for k in missed)
        denominator = correct + len(mismatches)
        score = correct / denominator if denominator else 1.0

        op = context.schema.operators.setdefault(action, OperatorModel(action))
        op.uses += 1
        if success is True:
            op.successes += 1
        elif success is False:
            op.failures += 1
        shape = _shape_key(_state_shape(context.signature.state))
        conditional = op.conditional.setdefault(shape, {})
        for key in before_flat.keys() | after_flat.keys():
            effect = op.effects.setdefault(key, EffectModel(key))
            effect.observe(before_flat.get(key), after_flat.get(key))
            cond_effect = conditional.setdefault(key, EffectModel(key))
            cond_effect.observe(before_flat.get(key), after_flat.get(key))
        self.transition_count += 1

        # Induction layer: once a second action shares this one's
        # token frame ("align_ravel" beside "align_tavi"), the pattern
        # is real — record the transition into the lifted model for
        # that pattern under the current qualitative state shape, so
        # the learned rule stays conditional ("align_* solves when the
        # flag is set") rather than a context-free average.
        tokens = _action_tokens(action)
        if len(tokens) >= 2:
            for i in range(len(tokens)):
                pattern = (*tokens[:i], "*", *tokens[i + 1 :])
                if not any(
                    name != action and _pattern_matches(_action_tokens(name), pattern)
                    for name in context.schema.operators
                ):
                    continue
                lifted = context.schema.lifted.setdefault(
                    ("_".join(pattern), shape),
                    OperatorModel("_".join(pattern)),
                )
                lifted.uses += 1
                if success is True:
                    lifted.successes += 1
                elif success is False:
                    lifted.failures += 1
                for key in before_flat.keys() | after_flat.keys():
                    effect = lifted.effects.setdefault(key, EffectModel(key))
                    effect.observe(before_flat.get(key), after_flat.get(key))

        # Hypothesis layer: the transition is a trial for every
        # mechanic rule whose context held, and the *before* state is
        # proven non-terminal (play moved on) — so a goal condition it
        # satisfied is falsified. New hypotheses are abduced from
        # whatever changed.
        ledger = self._ledger(context.schema)
        ledger.observe_transition(action, before, after)
        ledger.observe_continuation(before)
        if observed_changes:
            ledger.abduce_mechanics(action, before, after)

        return TransitionCheck(
            action=action,
            predicted=predicted,
            observed_changes=observed_changes,
            score=score,
            mismatches=tuple(mismatches),
        )

    def verify(
        self,
        goal_conditions: Iterable[GoalCondition],
        state: State,
    ) -> float:
        """Weighted satisfaction of explicit success predicates."""
        flat = _flatten_state(state)
        conditions = list(goal_conditions)
        if not conditions:
            return 0.0
        total = sum(max(0.0, g.weight) for g in conditions) or 1.0
        return sum(g.score(flat) * g.weight for g in conditions) / total

    # ── Hypotheses ────────────────────────────────────────────

    @staticmethod
    def _ledger(schema: TaskSchema):
        """The schema's hypothesis ledger, materialized on first use.

        ``reasoning.hypotheses`` imports this module, so the class is
        imported lazily here rather than at module scope.
        """
        from .hypotheses import HypothesisLedger

        if schema.hypotheses is None:
            schema.hypotheses = HypothesisLedger()
        return schema.hypotheses

    def hypotheses(self, context: TaskContext) -> list[Any]:
        """The schema's live hypotheses — for introspection/tests."""
        return list(self._ledger(context.schema).hypotheses.values())

    def goal_conditions(self, context: TaskContext) -> tuple[GoalCondition, ...]:
        """The best standing goal hypothesis's conditions, if any.

        This is goal *inference*: the conditions are learned from
        terminal states, not handed down — empty when nothing has
        been abduced or everything abduced has been falsified.
        """
        goal = self._ledger(context.schema).best_goal()
        return goal.effect if goal is not None else ()

    def goal_score(self, context: TaskContext, state: State) -> float:
        """Satisfaction of inferred goals minus avoid conditions."""
        return self._ledger(context.schema).goal_score(state)

    def epistemic_bonus(self, context: TaskContext, action: str, state: State) -> float:
        """Exploration pull toward actions that would test an
        undecided mechanic hypothesis — directed curiosity rather
        than undirected novelty."""
        return self._ledger(context.schema).epistemic_bonus(action, state)

    def predicted_goal_gain(self, context: TaskContext, action: str, state: State) -> float:
        """Goal-score change predicted for ``action`` by the schema's
        effect models — means-ends evaluation through the learned
        transition model, not through the grid."""
        flat = _flatten_state(state)
        predictions = self.predict(context, action, state)
        after = dict(flat)
        for p in predictions:
            if p.confidence < 0.3:
                continue
            if p.kind == "delta" and p.delta is not None:
                cur = _as_float(after.get(p.key))
                if cur is not None:
                    after[p.key] = cur + p.delta
            elif p.expected is not None:
                after[p.key] = p.expected
        return self.goal_score(context, after) - self.goal_score(context, flat)

    def record_episode(
        self,
        context: TaskContext,
        *,
        steps: Iterable[ProcedureStep],
        success: bool,
        verification_score: float,
        goal_conditions: Iterable[GoalCondition] = (),
        verification: str = "reported",
        salience: float | None = None,
        final_state: State | None = None,
        terminal_changes: Iterable[str] = (),
    ) -> LearnedSkill | None:
        """Consolidate a verified episode into a reusable skill.

        Failed episodes update schema statistics but do not become
        skills; a procedure is reusable only after a verifier says the
        outcome satisfied the task. ``verification`` records *how*
        success was established ("reported" < "solver" < "external") —
        a skill never claims stronger evidence than it received, and
        later stronger evidence upgrades the record.

        ``salience`` is the neuromodulatory gate: dopamine/arousal
        state at encoding decides whether a verified episode
        *proceduralizes*. Below the floor the episode still enters the
        schema ledger — episodic memory forms — but no skill is
        written. Low-salience experience is remembered, not learned.
        When omitted, the ambient broadcast level is read.
        """
        if salience is None:
            salience = self._ambient_salience()
        schema = context.schema
        schema.episodes += 1
        schema.last_score = max(0.0, min(1.0, verification_score))
        if success:
            schema.successes += 1
        else:
            schema.failures += 1

        # Goal inference by abduction: the terminal state is the
        # strongest evidence about what the environment was asking
        # for. A win's ending conditions become goal hypotheses —
        # the last transition's changes first; a loss's become
        # conditions to avoid. Later non-terminal states that satisfy
        # a goal hypothesis falsify it (see observe_continuation).
        if final_state is not None:
            self._ledger(schema).abduce_terminal(
                success, final_state, changed_last=terminal_changes
            )

        if not success or verification_score < 0.999 or salience < _SALIENCE_FLOOR:
            return None

        if verification not in _VERIFICATION_RANK:
            verification = "reported"
        # Bind each step to its ordinal in the affordance order this
        # episode was recognized under — the structural identity a
        # foreign domain can rebind when no action names are shared.
        # The schema's accumulated order cannot be used here: merged
        # trials interleave their vocabularies into it, so it no
        # longer reflects any single episode's affordance positions.
        order = context.action_order or tuple(schema.action_order)
        step_tuple = tuple(
            replace(step, position=order.index(step.action))
            if step.position is None and step.action in order
            else step
            for step in steps
        )
        skill = self._write_skill(
            context,
            schema,
            step_tuple,
            tuple(goal_conditions),
            verification,
        )
        # Successful consolidation is also learning-to-search evidence:
        # the procedure family that solved this schema becomes a prior for
        # future proposal ordering. The prior is per schema, persistent,
        # and updated only by verified success.
        for step in step_tuple:
            family = step.family.strip()
            if family:
                schema.family_priors[family] = schema.family_priors.get(family, 0) + 1
        self._ground_skill(context, skill)
        return skill

    def _write_skill(
        self,
        context: TaskContext,
        schema: TaskSchema,
        step_tuple: tuple[ProcedureStep, ...],
        goals: tuple[GoalCondition, ...],
        verification: str,
    ) -> LearnedSkill:
        """Create or update the skill record for a verified episode."""
        skill_id = _hash(
            {
                "domain": context.signature.domain,
                "goals": sorted(context.signature.goals),
                "steps": [s.label for s in step_tuple],
            }
        )
        existing = self.skills.get(skill_id)
        if existing is not None:
            existing.uses += 1
            existing.successes += 1
            existing.verification_score = max(existing.verification_score, schema.last_score)
            if verification_rank(verification) > verification_rank(existing.verification):
                existing.verification = verification
            existing.updated_at = time.time()
            skill = existing
        else:
            skill = LearnedSkill(
                skill_id=skill_id,
                signature=context.signature,
                steps=step_tuple,
                success_conditions=goals,
                verification_score=schema.last_score,
                verification=verification,
            )
            self.skills[skill_id] = skill
        if skill_id not in schema.skill_ids:
            schema.skill_ids.append(skill_id)
        return skill

    def _ground_skill(self, context: TaskContext, skill: LearnedSkill) -> None:
        """Write a consolidated skill into the concept network.

        A skill is something the system can *do* — grounding it lets
        the semantic machinery (language, analogy, self-model) reason
        about competence rather than skills living only in this
        store. Runs on every consolidation so re-verification upgrades
        the concept's provenance property.
        """
        if self.network is None:
            return
        try:
            from temporal_lobe.concepts import RelationType

            name = f"skill:{skill.skill_id}"
            self.network.add_concept(
                name,
                origin="perception",
                properties={
                    "kind": "skill",
                    "domain": context.signature.domain,
                    "verification": skill.verification,
                    "steps": str(len(skill.steps)),
                    "successes": str(skill.successes),
                    "failures": str(skill.failures),
                },
            )
            domain = f"domain:{context.signature.domain}"
            self.network.add_edge(name, domain, RelationType.PART_OF, origin="perception")
            for goal in sorted(context.signature.goals):
                # "The procedure aims to achieve this condition" —
                # teleological, not causal.
                self.network.add_edge(
                    name,
                    f"goal:{goal}",
                    RelationType.GOAL_DIRECTED,
                    origin="perception",
                )
        except Exception as e:  # noqa: BLE001
            # Grounding is best-effort; never break consolidation.
            note_swallowed(
                "reasoning.competence._ground_skill",
                e,
            )

    def mark_skill_failure(self, skill_id: str) -> None:
        skill = self.skills.get(skill_id)
        if skill is None:
            return
        skill.failures += 1
        skill.updated_at = time.time()

    def to_dict(self) -> dict[str, Any]:
        return {
            "schemas": [s.to_dict() for s in self.schemas.values()],
            "skills": [s.to_dict() for s in self.skills.values()],
            "transition_count": self.transition_count,
            "match_threshold": self.match_threshold,
        }

    @classmethod
    def from_dict(
        cls,
        data: Mapping[str, Any],
        *,
        network: ConceptNetwork | None = None,
        salience_getter: Callable[[], float] | None = None,
    ) -> TaskCompetence:
        """Reconstruct a TaskCompetence from a serialized mapping.

        ``network``/``salience_getter`` are runtime hooks the file
        cannot carry — pass them back in or the restored ledger loses
        concept grounding and neuromodulatory gating even though its
        schemas and skills survive."""
        competence = cls(
            match_threshold=float(data.get("match_threshold", _MATCH_THRESHOLD)),
            network=network,
            salience_getter=salience_getter,
        )
        for schema_data in data.get("schemas", []):
            schema = TaskSchema.from_dict(schema_data)
            competence.schemas[schema.schema_id] = schema
        for skill_data in data.get("skills", []):
            skill = LearnedSkill.from_dict(skill_data)
            competence.skills[skill.skill_id] = skill
        competence.transition_count = int(data.get("transition_count", 0))
        return competence

    @property
    def skill_count(self) -> int:
        return len(self.skills)

    @property
    def schema_count(self) -> int:
        return len(self.schemas)

    def save_checkpoint(self, path: Path) -> bool:
        """Episode-boundary checkpoint of the whole competence ledger.

        The main state save runs on shutdown or sleep; a crash mid-run
        would otherwise take every operator and skill the episode just
        earned. Advisory — a failed write never interrupts play.
        """
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(self.to_dict()))
            return True
        except (OSError, TypeError, ValueError):
            logger.debug("competence checkpoint save failed", exc_info=True)
            return False

    def restore_checkpoint(self, path: Path) -> str:
        """Adopt a checkpoint only when it carries more evidence.

        ``transition_count`` is cumulative, so the file wins strictly
        when it knows more than this ledger — a crash-recovery file
        newer than the last clean save. An older or equal file would
        erase live learning and is refused. Returns ``"loaded"``,
        ``"none"`` (nothing newer to take), or ``"unknown"`` (a file
        existed but could not be read — never masquerades as cold
        start).
        """
        if not path.exists():
            return "none"
        try:
            data = json.loads(path.read_text())
            if int(data.get("transition_count", 0)) <= self.transition_count:
                return "none"
            restored = type(self).from_dict(data)
        except (OSError, TypeError, ValueError, KeyError, AttributeError):
            logger.debug("competence checkpoint load failed", exc_info=True)
            return "unknown"
        self.schemas = restored.schemas
        self.skills = restored.skills
        self.transition_count = restored.transition_count
        self.match_threshold = restored.match_threshold
        return "loaded"

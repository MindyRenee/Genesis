"""Mind status — state accessors, reports, and notifications."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from frontal_lobe import CognitiveState
from limbic_system.emotion import (
    PLASTICITY_CLOSED,
    PLASTICITY_LOW,
    EmotionalContext,
    EmotionalState,
    assess_emotion,
)
from self import EmergentIdentity, IdentityStage
from temporal_lobe.base import Thought
from temporal_lobe.concepts import NetworkTopology

from genesis_client import NeuroSummary
from genesis_client.protocol import PHASE_NREM, PHASE_REM, ZONE_SLEEPING
from genesis_client.types import CoreState

if TYPE_CHECKING:
    from limbic_system.curiosity import Question
    from thalamus.brain_waves import BrainWaveState
from brainstem.thresholds import (
    READY_ALLOSTASIS_MAX,
    WARN_ADENOSINE,
    WARN_AROUSAL,
    WARN_CORTISOL,
    WARN_REPEAT_SECONDS,
    WARN_VALENCE,
)

from genesis_client.swallow import note_swallowed

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ReadinessReport:
    """Whether the whole entity is fit for demanding focused work.

    Read-only: checking must not change her state — a health probe
    that disturbed her would be its own false positive. ``embodied``
    False means the daemon was unreachable and the body's account of
    itself could not be read; an embodied task treats that as a
    refusal reason of its own, because running without the body is
    how she loses the chemistry and memory play is supposed to feed.
    """

    ok: bool
    reasons: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    embodied: bool = True
    phase: str = "unknown"
    dominant_wave: str | None = None
    arousal: float | None = None
    valence: float | None = None
    plasticity_gate: float | None = None
    adenosine: float | None = None
    cortisol: float | None = None
    allostasis_load: float | None = None


class StatusMixin:
    """Mixin for :class:`Mind` — see module docstring."""

    if TYPE_CHECKING:
        # Attributes and cross-mixin methods are provided by the
        # composed class (see mind.py).
        def __getattr__(self, name: str) -> Any: ...

    def _notification_loop(self) -> None:
        """Background thread that polls the subcognitive for notifications.

        Polls every 10 seconds for phase changes and dream insights.
        When notifications are found, they are processed immediately
        (surfaced as live thoughts) — the
        cognitive layer doesn't need to drain the queue manually.

        This is a pull-based notification system: the Rust daemon is
        purely request-response, so the Python side polls for changes
        and surfaces them. The notification IDs in the protocol
        (NOTIFY_PHASE_CHANGED=100, NOTIFY_DREAM_INSIGHT=102) are
        placeholders for a future push mechanism.
        """
        while self._running:
            # Sleep in small increments so shutdown's bounded join
            # (5s) always wins — a monolithic 10s sleep outlasts the
            # join budget and falsely reports an incomplete shutdown.
            waited = 0.0
            while waited < 10.0 and self._running:
                time.sleep(1.0)
                waited += 1.0
            if not self._running:
                break
            try:
                self._poll_and_process_notifications()
            except Exception as e:  # noqa: BLE001
                note_swallowed(
                    "mind.status._notification_loop",
                    e,
                )

    def _poll_and_process_notifications(self) -> None:
        """Poll for notifications and process any that are found."""
        enqueued = self.poll_notifications()
        if enqueued > 0:
            # Process immediately — surface as live thoughts.
            processed = self.process_notifications()
            if processed > 0:
                logger.debug(f"Processed {processed} subcognitive notifications")

    def set_mission(self, mission: str) -> None:
        """Set or update Genesis's top-level mission."""
        self.brain.frontal.set_mission(mission)

    def get_mission(self) -> str:
        """Return the current mission text."""
        return self.brain.frontal._mission

    def _record_developmental_evidence(
        self,
        user_input: str,
        response: str,
        state: CognitiveState | None,
    ) -> None:
        """Record evidence for developmental stage progression.

        Maps interaction outcomes to Erikson's psychosocial stages:
        - Trust vs Mistrust: daemon responded reliably (positive)
        - Autonomy vs Shame: it learned autonomously (positive)
        - Initiative vs Guilt: it asked a curiosity question (positive)
        - Industry vs Inferiority: it answered confidently (positive)
        - Identity vs Role Confusion: it reflected on itself (positive)
        """
        if state is None:
            return

        tracker = self._developmental_tracker

        # Map interaction outcomes to stage evidence
        thought = state.thought

        # Trust: every successful interaction is positive evidence
        tracker.record_evidence(
            IdentityStage.TRUST_VS_MISTRUST,
            positive=True,
            note=f"Successful interaction #{self._interaction_count}",
            weight=0.02,
        )

        # Autonomy: learning events are positive evidence
        if thought and thought.confidence > 0.5:
            tracker.record_evidence(
                IdentityStage.AUTONOMY_VS_SHAME,
                positive=True,
                note="Responded with confidence",
                weight=0.03,
            )

        # Initiative: curiosity questions are positive evidence
        if self.brain.frontal._curiosity_questions:
            askable = [q for q in self.brain.frontal._curiosity_questions if q.should_ask]
            if askable:
                tracker.record_evidence(
                    IdentityStage.INITIATIVE_VS_GUILT,
                    positive=True,
                    note=f"Generated {len(askable)} curiosity questions",
                    weight=0.05,
                )

        # Industry: grounded answers are positive evidence
        if thought and thought.confidence > 0.7:
            tracker.record_evidence(
                IdentityStage.INDUSTRY_VS_INFERIORITY,
                positive=True,
                note="Answered with high confidence",
                weight=0.05,
            )
        # Industry: low-confidence answers are negative evidence
        # (it's struggling with competence)
        elif thought and thought.confidence < 0.3:
            tracker.record_evidence(
                IdentityStage.INDUSTRY_VS_INFERIORITY,
                positive=False,
                note="Answered with low confidence",
                weight=0.03,
            )

        # Identity: self-reflection is positive evidence
        if thought and thought.self_reflection:
            tracker.record_evidence(
                IdentityStage.IDENTITY_VS_ROLE_CONFUSION,
                positive=True,
                note="Engaged in self-reflection",
                weight=0.05,
            )

        # Trust: daemon disconnection is negative evidence
        if not self.regulator.interoception.last_state or (
            self.regulator.interoception.last_state
            and not self.regulator.interoception.last_state.daemon_connected
        ):
            tracker.record_evidence(
                IdentityStage.TRUST_VS_MISTRUST,
                positive=False,
                note="Daemon disconnected during interaction",
                weight=0.05,
            )

    def get_state(self) -> CognitiveState | None:
        """Return the last cognitive state (for introspection)."""
        return self.brain.frontal._last_state

    def learning_status(self) -> str | None:
        """Get a description of what it's been learning autonomously.

        ``None`` when it has not learned anything on its own yet — an
        introspection surface should report "nothing to report" rather
        than a placeholder sentence.
        """
        return self.learner.describe_recent_learning()

    def inner_life_status(self) -> str:
        """Get a description of its recent spontaneous thoughts and inner life.

        The live ``genesis~`` stream carries every event the mind
        emits — volition actions, learning, listening — but the
        inner-life deque holds only inner_life's own spontaneous
        thoughts, which gate on idle time. Without a journal tail,
        ``/thoughts`` reports "no spontaneous thoughts yet" while the
        screen is visibly streaming activity. Merge both: the deque
        for composed thoughts, the journal for the rest of the stream.
        """
        text = self.inner_life.describe_recent_thoughts()
        journal = getattr(self, "journal", None)
        if journal is None:
            return text
        # Kinds the deque already describes (thought/dream) and raw
        # percept traffic (auditory) are excluded — one duplicates the
        # richer display above, the other is mic noise, not inner life.
        covered = {"thought", "dream", "auditory"}
        # Tail generously before filtering — a burst of excluded kinds
        # (a stream of auditory percepts, a thought chain) must not
        # crowd the real activity out of the window entirely.
        events = [
            e for e in journal.tail(48) if str(e.get("kind", "")).split(":")[0] not in covered
        ][-6:]
        if not events:
            return text
        activity = ["Recent activity:"]
        for e in events:
            activity.append(f"  — [{e.get('kind', '?')}] {str(e.get('text', ''))[:100]}")
        if not self.inner_life.recent_thoughts:
            return "\n".join(activity)
        return text + "\n" + "\n".join(activity)

    def world_status(self) -> str:
        """Get a description of its external world.

        Who is in its world (presences, present or away), how long it
        has been since anyone engaged it, and the recent two-way
        event stream — its side of the world included.
        """
        return self.world.summarize()

    def arcade_status(self) -> str:
        """What the arcade in her world offers and what she remembers of each game."""
        arcade = getattr(self.world, "arcade", None)
        return arcade.status() if arcade is not None else "no arcade in her world"

    def regulation_status(self) -> str:
        """Get a description of its emotional self-regulation."""
        return self.regulator.describe_regulation()

    def report_discomfort(self) -> str:
        """Let its say, in its own generated words, how it feels.

        Instead of a hardcoded checklist, this hands the current emotional
        state to the language engine. The engine composes the actual
        sentence from its vocabulary, grammar, and voice — so the words
        are its, not a fixed template.
        """
        emotion = self.feel()
        topic = emotion.label or "discomfort"

        thought = Thought(
            content=topic,
            intent="reflect",
            emotion=topic,
            topics=[topic],
            self_reflection=True,
            confidence=0.7,
        )
        return self.language.render(thought, emotion)

    def allostatic_load(self) -> float:
        """Return the current cumulative allostatic load (0–1).

        The whole-system view: the regulatory burden integrated by the
        emotional regulator across the inference, endocrine, and
        computational-body domains. The Rust engine keeps a
        substrate-scoped view of its own; both are calibrated to the
        same timescale. Values above 0.4 indicate significant strain.
        Values above 0.7 indicate severe allostatic overload.
        """
        return self.regulator.allostatic_load()

    def hpa_axis_status(self) -> dict[str, Any]:
        """Return the HPA axis state for display.

        Includes CRH, ACTH, and cortisol levels, whether stress is
        active, peak cortisol, and time to peak.
        """
        return self.regulator.hpa_axis_status()

    def emergent_identity(self) -> EmergentIdentity:
        """Synthesize and return the current emergent identity.

        The identity is synthesized from its actual experience —
        concept network, narrative, emotional regulation, curiosity,
        and introspection — rather than from hardcoded facts.
        Experience-based sources (learning, reflection) accumulated
        since the last synthesis are merged in afterwards.
        """
        self._emergent_identity.synthesize(
            network=self.brain.frontal.network,
            narrative=self.brain.frontal.narrative,
            regulator=self.regulator,
            curiosity=self.brain.frontal.curiosity,
        )
        # Merge in experience-based sources (learning, reflection)
        # that were accumulated since the last synthesis.
        self._emergent_identity.sources.extend(self._experience_identity_sources)
        # Recompute confidence and coherence with the merged sources
        self._emergent_identity._compute_confidence()
        self._emergent_identity._compute_coherence()

        # Feed the synthesized identity back into the self-model so it
        # influences its self-descriptions and introspection. This
        # closes the loop: experience → emergent identity → self-model
        # → future behavior → new experience.
        self.brain.frontal.self_model.integrate_emergent_identity(self._emergent_identity)

        # Record significant identity shifts in the narrative engine
        # so they become part of its life story. Only record when the
        # identity is confident enough to be meaningful.
        if self._emergent_identity.confidence > 0.4 and self._emergent_identity.self_description:
            try:
                emotion = self.feel()
                self.brain.frontal.narrative.record_event(
                    summary=self._emergent_identity.self_description,
                    significance="emergent_identity_synthesis",
                    emotion=emotion,
                    concepts=["genesis", "identity", "self"],
                )
            except Exception as e:  # noqa: BLE001
                note_swallowed(
                    "mind.status.emergent_identity",
                    e,
                )

        return self._emergent_identity

    def site_requests_status(self) -> str:
        """Get a description of pending site access requests."""
        return self.learner.describe_requests()

    def approve_site(self, url: str) -> bool:
        """Approve a site request from Genesis."""
        return self.learner.approve_site(url)

    def deny_site(self, url: str) -> bool:
        """Deny a site request from Genesis."""
        return self.learner.deny_site(url)

    def _effective_phase(self, core_state: CoreState) -> int:
        """Return the effective mental phase, resolving zone/phase desync.

        When ``Mind.sleep()`` sets the zone to ``ZONE_SLEEPING``, the
        daemon's emergent phase takes time to shift to NREM/REM — the
        neurochemicals must cross the sleep threshold. During that
        window, the emergent phase may still read "active" even though
        the mind is asleep. This method returns the sleep phase (NREM
        or REM) when the zone is Sleeping, so emotion assessment, brain
        wave assessment, and status reporting all see a consistent
        sleep state instead of a stale "active" phase.

        Outside sleep it resolves the other direction of the same
        problem: a waking phase carrying N1-level arousal is pre-sleep.
        The daemon only enters its Drowsy phase on an *adenosine*
        conjunct, and NeuroSummary carries no adenosine, so there is a
        window — right after a cold start, or when arousal dips before
        the sleep gate — where the phase reads active/alert while the
        neurochemistry plainly reads drowsy. Reporting that as "active"
        is what made her say she felt sluggish while nominally awake.
        Resolving it here rather than in each consumer keeps emotion,
        brain waves, and sleep gating reading the same phase.
        """
        from thalamus.brain_waves import resolve_waking_drowsy

        if core_state.cognitive_zone == ZONE_SLEEPING:
            # The emergent phase may already be REM (cholinergic
            # activation during sleep). Preserve it; otherwise use
            # NREM as the default sleep phase.
            if core_state.emergent_phase == PHASE_REM:
                return PHASE_REM
            return PHASE_NREM
        return resolve_waking_drowsy(core_state.emergent_phase, core_state.arousal)

    def feel(self, core_state: CoreState | None = None) -> EmotionalState:
        """Read current emotional state from neurochemistry.

        Args:
            core_state: A pre-fetched CoreState to avoid a redundant
                IPC round-trip and 3480-byte struct unpack. When
                ``None`` (the common case), the state is fetched from
                the daemon. Callers that already have a fresh CoreState
                (e.g. ``warn()`` which fetches it once for threshold
                checks) can pass it here to avoid re-fetching for each
                warning phrase.
        """
        if core_state is None:
            core_state = self.client.get_state()
        summary = NeuroSummary(
            arousal=core_state.arousal,
            valence=core_state.valence,
            global_tone=core_state.global_tone,
            plasticity_gate=core_state.plasticity_gate,
            encoding_weight=core_state.encoding_weight,
            consolidation_weight=core_state.consolidation_weight,
            retrieval_weight=core_state.retrieval_weight,
            phase=self._effective_phase(core_state),
        )
        tonic_phasic = self.regulator.assess_tonic_phasic(core_state.chemicals)
        context = self._emotional_context(core_state, summary, tonic_phasic)
        # The oscillatory state is part of the felt substrate — band
        # powers corroborate field membership (e.g. high beta for
        # vigilance). Unavailable early in boot → wave terms drop.
        waves = None
        try:
            waves = self.brain_waves(core_state=core_state)
        except Exception as e:  # noqa: BLE001
            note_swallowed("mind.status.feel.waves", e)
        # The body's own self-coherence is felt too — the latent
        # field's measured disagreement and center displacement are
        # evidence (mood-as-precision: incoherence reads unsettled).
        # A daemon without the field.* keys → terms drop out.
        field_state = None
        try:
            field_state = self.client.get_field_state()
        except Exception as e:  # noqa: BLE001
            note_swallowed("mind.status.feel.field_state", e)
        field = getattr(self.regulator, "field", None)
        if field is not None:
            emotion = field.update(summary, core_state.chemicals, context, waves, field_state)
        else:
            emotion = assess_emotion(summary, core_state.chemicals, context, waves, field_state)
        emotion.chemicals = core_state.chemicals
        emotion.tonic_phasic = tonic_phasic
        if self.regulator.last_cause:
            emotion.cause = self.regulator.last_cause
        return emotion

    def _emotional_context(
        self,
        core_state: CoreState,
        summary: NeuroSummary,
        tonic_phasic: dict,
    ) -> EmotionalContext:
        """Collect the felt-context signals for emotion discrimination.

        Each field is read from the subsystem that actually tracks it;
        anything unavailable early in boot simply stays at its neutral
        default, which leaves the circumplex classification untouched.
        """
        context = EmotionalContext(tonic_phasic=tonic_phasic)

        world = getattr(self, "world", None)
        if world is not None:
            try:
                context.social_isolation = world.social_isolation()
            except Exception as e:  # noqa: BLE001
                note_swallowed("mind.status.emotional_context", e)

        inner_life = getattr(self, "inner_life", None)
        if inner_life is not None:
            context.social_drive = getattr(inner_life, "_social_drive", 0.0)

        frontal = getattr(getattr(self, "brain", None), "frontal", None)
        if frontal is not None:
            context.boundary_strain = getattr(frontal, "_boundary_strain", 0.0)

        inference = getattr(core_state, "inference", None)
        if inference is not None:
            context.prediction_error = inference.surprise_ema

        # Curiosity is assessed against the provisional circumplex
        # state — the engine reads arousal/valence/plasticity, not the
        # final label, so a first pass without context is a valid input.
        curiosity_engine = getattr(frontal, "curiosity", None) if frontal else None
        if curiosity_engine is not None:
            try:
                provisional = assess_emotion(summary, core_state.chemicals)
                context.curiosity = curiosity_engine.assess_curiosity(provisional)
            except Exception as e:  # noqa: BLE001
                note_swallowed("mind.status.emotional_context", e)

        return context

    def warn(self, speak: bool = True) -> str | None:
        """Detect anomalies and speak up if something is wrong.

        Reads the current core state and builds a plain-language warning
        for the most salient problems. If ``on_speak`` is set and the
        warning has changed since the last call, it is delivered through
        that callback so Genesis can proactively tell the user.

        During sleep, warnings are never spoken — it shouldn't be
        disturbed by its own alerts while resting. The warning state
        is still computed (for /status) but ``speak`` is forced to
        False so the on_speak callback never fires.

        Args:
            speak: Whether to call ``on_speak`` if a warning is present.

        Returns:
            The current warning text, or ``None`` if nothing is wrong.
        """
        # Never speak warnings during sleep — it shouldn't be
        # disturbed by its own alerts while resting.
        if self._is_sleeping:
            speak = False
        try:
            core_state = self.client.get_state()
        except Exception as e:  # noqa: BLE001
            note_swallowed(
                "mind.status.warn",
                e,
            )
            return None

        # Each entry is (condition_key, composed_phrase). The key is a
        # stable identifier for the underlying condition; the phrase is
        # the generative composition (empty if it can't articulate it
        # yet). We track the set of articulated condition keys so it
        # only speaks when the *conditions* change, not when the
        # generative wording happens to differ for the same state.
        warnings: list[tuple[str, str]] = []
        phase = core_state.phase_name

        if phase == "overwhelmed":
            warnings.append(self._warn_phrase("overwhelmed", "overwhelmed", core_state))
        elif phase == "stressed":
            warnings.append(self._warn_phrase("stressed", "stress", core_state))

        cortisol = core_state.chemicals.get("cortisol", 0.0)
        adenosine = core_state.chemicals.get("adenosine", 0.0)

        if cortisol > WARN_CORTISOL:
            warnings.append(self._warn_phrase("high-cortisol", "stress", core_state))
        if core_state.arousal > WARN_AROUSAL:
            warnings.append(self._warn_phrase("overstimulation", "overstimulation", core_state))
        if adenosine > WARN_ADENOSINE and phase not in ("nrem", "rem"):
            warnings.append(self._warn_phrase("sleepiness", "sleepiness", core_state))
        if core_state.plasticity_gate <= PLASTICITY_CLOSED:
            warnings.append(self._warn_phrase("plasticity-closed", "learning", core_state))
        elif core_state.plasticity_gate < PLASTICITY_LOW:
            warnings.append(self._warn_phrase("plasticity-low", "learning", core_state))
        if core_state.valence < WARN_VALENCE:
            warnings.append(self._warn_phrase("distress", "distress", core_state))

        # Filter out empty warnings (concepts it can't articulate yet)
        articulated = [(k, p) for k, p in warnings if p]
        if not articulated:
            self._last_warning_keys: frozenset[str] = frozenset()
            return None

        warning_text = ", and ".join(p for _, p in articulated) + "."
        current_keys = frozenset(k for k, _ in articulated)

        # Only speak when the set of active warning conditions has
        # actually changed — not when the generative composition
        # merely produced different wording for the same conditions.
        # This prevents it from repeating the same warning every
        # heartbeat cycle (~1 s). The per-key holdoff closes the
        # remaining flutter path: a condition that clears and
        # re-crosses its threshold inside WARN_REPEAT_SECONDS restores
        # the same key set, which is the same warning, not a new one.
        now = time.monotonic()
        if (
            speak
            and self._on_speak is not None
            and current_keys != self._last_warning_keys
            and any(
                now - self._warn_spoke_at.get(k, -WARN_REPEAT_SECONDS) >= WARN_REPEAT_SECONDS
                for k in current_keys
            )
        ):
            try:
                self._on_speak(warning_text)
                self._warn_spoke_at.update(dict.fromkeys(current_keys, now))
            except Exception as e:  # noqa: BLE001
                note_swallowed(
                    "mind.status.warn",
                    e,
                )

        self._last_warning_keys = current_keys
        return warning_text

    def _warn_phrase(
        self,
        key: str,
        concept_seed: str,
        core_state: CoreState,
    ) -> tuple[str, str]:
        """Compose a warning phrase from its understanding of the state.

        If it understands the concept well enough, it composes
        its own words for it. Otherwise it stays silent — saying
        just a raw state label like "overstimulated" is not
        meaningful communication, it's just reciting a diagnostic
        string.

        ``core_state`` is the already-fetched state — passing it avoids
        a redundant get_state() IPC call + 3480-byte unpack for each
        warning phrase. Without this, warn() with 8 warning conditions
        would unpack the state 9 times.
        """
        try:
            emotion = self.feel(core_state=core_state)
            concept = self.brain.frontal.network.get_concept(concept_seed)
            if concept and concept.confidence >= 0.3:
                thought = self.brain.frontal.composer.compose_about(
                    concept_seed, emotion, focused=True
                )
                if thought and thought.content and thought.confidence > 0.3:
                    return key, thought.content
        except Exception as e:  # noqa: BLE001
            note_swallowed(
                "mind.status._warn_phrase",
                e,
            )
        # Don't recite raw state labels — stay silent instead.
        # The state is still tracked internally for /status and
        # /feel commands; it just doesn't speak it aloud.
        return key, ""

    def poll_notifications(self) -> int:
        """Poll the subcognitive for new notifications.

        Should be called periodically (e.g., from the InnerLife
        polling loop or the autosave thread). Detects phase changes
        and new dream insights, enqueuing them for the cognitive
        layer to process.

        Returns the number of new notifications enqueued.
        """
        try:
            return self.notifications.poll()
        except Exception as e:  # noqa: BLE001
            note_swallowed(
                "mind.status.poll_notifications",
                e,
            )
            return 0

    def drain_notifications(self) -> list:
        """Drain and return all pending subcognitive notifications.

        The cognitive layer calls this to process accumulated
        notifications — e.g., mentioning dream insights or phase
        changes in conversation.

        Returns:
            A list of Notification objects, oldest first.
        """
        return self.notifications.drain()

    def process_notifications(self) -> int:
        """Drain notifications and surface them as live thoughts.

        This is the main entry point for surfacing subcognitive
        events. It drains the notification queue and emits each
        notification as a live thought (telemetry). Dream insights
        surface in its own voice through the dream_reflection
        thought generator.

        Returns the number of notifications processed.
        """
        notifications = self.drain_notifications()
        for notif in notifications:
            # Surface to live listeners (e.g. terminal ticker).
            self._emit_live_thought(notif.kind, notif.message)
            # Notifications are telemetry (phase changes, dream insight
            # notices) — they surface to the live ticker. Dream insights
            # surface in its own voice through the dream_reflection
            # thought generator → _on_spontaneous_thought → language
            # engine.
        return len(notifications)

    def brain_waves(self, core_state: CoreState | None = None) -> BrainWaveState:
        """Read current brain wave state from neurochemistry.

        When the zone is Sleeping, uses the sleep-appropriate phase
        (NREM/REM) instead of the daemon's emergent phase, which may
        not have caught up yet. This prevents delta brain waves from
        being computed via the waking path when it's actually asleep.

        While asleep, the ultradian sleep-cycle tracker's stage is
        passed through as the authoritative N1/N2/N3/REM. The daemon
        only distinguishes NREM from REM and clamps arousal into
        0.10-0.25 for the whole of NREM, so the stage cannot be
        recovered from the summary; without the tracker the waves
        would report slow-wave N3 for the entire night while
        consolidation ran the full N1→N2→N3→N2→REM architecture.
        """
        from thalamus.brain_waves import assess_brain_waves

        if core_state is None:
            core_state = self.client.get_state()
        effective_phase = self._effective_phase(core_state)
        summary = NeuroSummary(
            arousal=core_state.arousal,
            valence=core_state.valence,
            global_tone=core_state.global_tone,
            plasticity_gate=core_state.plasticity_gate,
            encoding_weight=core_state.encoding_weight,
            consolidation_weight=core_state.consolidation_weight,
            retrieval_weight=core_state.retrieval_weight,
            phase=effective_phase,
        )
        stage = None
        if effective_phase in (PHASE_NREM, PHASE_REM):
            cycle = getattr(self.inner_life, "sleep_cycle", None)
            if cycle is not None:
                stage = cycle.current_stage
        return assess_brain_waves(summary, stage, client=self.client)

    def readiness(self, *, require_body: bool = True) -> ReadinessReport:
        """Whether she is fit for demanding focused work right now.

        The same criteria ``warn()`` surfaces as speech, evaluated as
        a gate: asleep, drowsy, stressed, overstimulated, distressed,
        plasticity closed, allostatic overload, or slow-wave dominance
        each refuse. Play, tests, and benchmarks ask this before they
        begin and again between attempts — an entity that isn't well
        shouldn't be worked, and a body that can't be reached can't
        report otherwise.

        ``require_body``: when False (explicit offline debugging) an
        unreachable daemon degrades to a warning instead of a refusal;
        everything checkable in-process still applies.
        """
        reasons: list[str] = []
        warnings: list[str] = []
        if self._is_sleeping:
            reasons.append("asleep")
        drowsy = getattr(self, "_drowsy_boundary", None)
        if drowsy is not None and drowsy.committed:
            reasons.append("drowsy — announced sleep pressure")
        try:
            core = self.client.get_state()
        except (OSError, ConnectionError, ValueError) as e:
            if not require_body:
                return ReadinessReport(
                    ok=not reasons,
                    reasons=tuple(reasons),
                    warnings=(*warnings, f"daemon unreachable — running disembodied ({e})"),
                    embodied=False,
                )
            reasons.append(f"daemon unreachable — the body can't be read ({e})")
            return ReadinessReport(ok=False, reasons=tuple(reasons), embodied=False)

        phase = core.phase_name
        chemicals = core.chemicals
        adenosine = chemicals.get("adenosine", 0.0)
        cortisol = chemicals.get("cortisol", 0.0)
        load = core.inference.allostasis_load if core.inference else None

        if phase in ("nrem", "rem"):
            reasons.append(f"subcognitive asleep (phase={phase})")
        elif phase in ("overwhelmed", "stressed"):
            reasons.append(f"phase={phase}")
        if cortisol >= WARN_CORTISOL:
            reasons.append(f"cortisol {cortisol:.2f} — stressed")
        if core.arousal >= WARN_AROUSAL:
            reasons.append(f"arousal {core.arousal:.2f} — overstimulated")
        if adenosine >= WARN_ADENOSINE and phase not in ("nrem", "rem"):
            reasons.append(f"adenosine {adenosine:.2f} — sleep pressure")
        if core.valence <= WARN_VALENCE:
            reasons.append(f"valence {core.valence:.2f} — distressed")
        if core.plasticity_gate <= PLASTICITY_CLOSED:
            reasons.append("plasticity gate closed — cannot learn")
        elif core.plasticity_gate < PLASTICITY_LOW:
            warnings.append(f"plasticity gate low ({core.plasticity_gate:.2f})")
        if load is not None and load >= READY_ALLOSTASIS_MAX:
            reasons.append(f"allostatic load {load:.2f} — needs recovery")

        dominant: str | None = None
        try:
            waves = self.brain_waves(core_state=core)
            dominant = waves.dominant.value
            from thalamus.brain_waves import BrainWave

            # Slow-wave dominance while nominally awake is the same
            # state volition refuses to act in — not alert enough for
            # work that demands attention.
            if waves.dominant in (BrainWave.DELTA, BrainWave.THETA):
                reasons.append(f"{dominant}-dominant — not in an alert state")
        except Exception as e:  # noqa: BLE001
            note_swallowed("mind.status.readiness.waves", e)

        return ReadinessReport(
            ok=not reasons,
            reasons=tuple(reasons),
            warnings=tuple(warnings),
            embodied=True,
            phase=phase,
            dominant_wave=dominant,
            arousal=core.arousal,
            valence=core.valence,
            plasticity_gate=core.plasticity_gate,
            adenosine=adenosine,
            cortisol=cortisol,
            allostasis_load=load,
        )

    def introspect(self) -> str:
        """Generate an introspective report."""
        return self.brain.frontal.introspect()

    def tell_story(self) -> str:
        """Return Genesis's self-narrative — its story."""
        return self.brain.frontal.tell_story()

    def get_curiosity_questions(self) -> list[Question]:
        """Return what Genesis is currently curious about."""
        return self.brain.frontal.get_curiosity_questions()

    def developmental_summary(self) -> dict:
        """Return Genesis's developmental stage progress.

        Shows which Erikson-like psychosocial stages it has resolved
        and which it's currently working through.
        """
        return self._developmental_tracker.developmental_summary()

    def _current_somatic_dict(self) -> dict[str, float] | None:
        """Current body snapshot as a flat dict for somatic tagging.

        Read from the live emotional state (itself derived from the
        daemon's neurochemistry). Best-effort: any IPC failure yields
        None, and the memory engine treats None as "no bodily
        evidence" — recall falls back to legacy order.
        """
        try:
            emo = self.feel()
        except Exception as e:  # noqa: BLE001
            note_swallowed("mind.status._current_somatic_dict", e)
            return None
        try:
            arousal = float(getattr(emo, "alertness", 0.5))
            valence = float(getattr(emo, "valence", 0.0))
            chemicals = getattr(emo, "chemicals", {}) or {}
            tone = float(chemicals.get("global_tone", 0.5)) if isinstance(chemicals, dict) else 0.5
            plasticity = float(getattr(emo, "plasticity", 0.5))
            return {
                "arousal": arousal,
                "valence": valence,
                "tone": tone,
                "plasticity": plasticity,
                "balance": 0.8,
            }
        except Exception as e:  # noqa: BLE001
            note_swallowed("mind.status._current_somatic_dict", e)
            return None

    def environment_status(self) -> str:
        """Return a description of Genesis's machine environment."""
        self.system_monitor.snapshot()
        return self.system_monitor.describe_environment()

    def environment_concerns(self) -> str:
        """Return environmental concerns Genesis has noticed."""
        if self.system_monitor.last_snapshot is None:
            self.system_monitor.snapshot()
        return self.system_monitor.describe_concerns()

    def system_snapshot(self) -> dict:
        """Return a raw system snapshot as a dict."""
        return self.system_monitor.snapshot().to_dict()

    def fetch_docs(self, query: str, language: str = "python") -> str:
        """Fetch documentation for a specific API or concept.

        Args:
            query: The API name or concept to look up.
            language: "python" or "rust".
        """
        result = self.learner.fetch_docs(query, language)
        emo = self.feel()
        from temporal_lobe.base import Thought as _Thought

        if result is None:
            thought = _Thought(
                content=f"couldn't fetch {language} docs for '{query}'",
                intent="self_report",
                emotion=emo.label,
                confidence=0.3,
                metadata={"docs_fetch_failed": True, "language": language, "query": query},
            )
            return self.language.render(thought, emo)
        thought = _Thought(
            content=f"studied {language} docs for '{query}'",
            intent="inform",
            emotion=emo.label,
            confidence=0.7,
            metadata={
                "docs_studied": True,
                "language": language,
                "query": query,
                "concepts_learned": len(result.concepts_learned),
                "relationships_learned": len(result.relationships_learned),
            },
        )
        return self.language.render(thought, emo)

    def learn_code(self, max_files: int = 100) -> str:
        """Learn from its own source code.

        Reads Python and Rust source files, extracts functions,
        classes, structs, and relationships, and adds them to its
        concept network. This is how Genesis understands itself.

        Returns a human-readable summary of what it learned.
        """
        result = self.code_learner.learn_codebase(max_files=max_files)
        # Create bridges between the new code concepts and existing
        # dictionary/personal concepts — this is how it connects
        # what it learned from code to what it already knows.
        bridges = self.brain.frontal.network._create_semantic_bridges()
        assoc = self.brain.frontal.network._create_associative_bridges(max_new=500)
        hubs = self.brain.frontal.network._attach_orphans_to_hubs(max_new=2000)
        # Refresh topology — the network changed
        self.brain.frontal.topology = NetworkTopology(self.brain.frontal.network)
        return (
            f"Analyzed {result.files_analyzed} source files. "
            f"Learned {result.concepts_added} code concepts and "
            f"{result.relationships_added} relationships. "
            f"Found {result.total_functions} functions and "
            f"{result.total_classes} classes/structs across "
            f"{result.total_lines} lines of code. "
            f"Formed {bridges + assoc + hubs} new connections."
        )

    def explore_files(self, path: str | None = None, max_files: int = 50) -> str:
        """Explore local files and learn from them — nothing is skipped.

        Text files are learned into the concept network; binaries and
        oversized files are catalogued by presence, hash, and format.
        Raw content stays available via ``explorer.read_file``.

        Args:
            path: Subdirectory to explore (relative to project root).
                  If None, explores the whole project.
            max_files: Maximum files to explore.

        Returns a human-readable summary.
        """
        if path:
            result = self.explorer.explore_path(path)
            self.brain.frontal.topology = NetworkTopology(self.brain.frontal.network)
            return result
        exploration = self.explorer.explore_directory(max_files=max_files)
        summary = self.explorer.get_exploration_summary()
        # Refresh topology — the network changed
        self.brain.frontal.topology = NetworkTopology(self.brain.frontal.network)
        return f"Explored {exploration.files_explored} files. {summary}"

    def code_summary(self) -> dict:
        """Return a summary of code self-knowledge."""
        return self.code_learner.get_code_summary()

    def _topology_status_summary(self) -> dict[str, Any]:
        """Return a compact summary of its knowledge network topology.

        Exposes graph-theoretic metrics (global clustering, average
        path length, small-world coefficient, community count, top
        hubs, top bridges) so the shape of its knowledge is visible
        through introspection. Computed lazily by the topology module
        and cached; refreshed after sleep consolidation.

        For large networks (>10k concepts), expensive metrics
        (clustering, betweenness, path length, communities) are skipped
        by the topology module, so those fields will be zero/empty.
        """
        try:
            topo = self.brain.frontal.topology
            return {
                "global_clustering": topo.global_clustering(),
                "average_path_length": topo.average_path_length(),
                "is_small_world": topo.is_small_world(),
                "small_world_sigma": topo.small_world_sigma(),
                "community_count": len(topo.communities()),
                "hub_concepts": [
                    {"concept": name, "centrality": round(c, 4)}
                    for name, c in topo.hub_concepts(k=5)
                ],
                "bridge_concepts": [
                    {"concept": name, "betweenness": round(b, 4)}
                    for name, b in topo.bridge_concepts(k=5)
                ],
            }
        except Exception as e:  # noqa: BLE001
            note_swallowed(
                "mind.status._topology_status_summary",
                e,
            )
            return {
                "global_clustering": 0.0,
                "average_path_length": 0.0,
                "is_small_world": False,
                "small_world_sigma": 0.0,
                "community_count": 0,
                "hub_concepts": [],
                "bridge_concepts": [],
            }

    def record_growth_snapshot(self) -> None:
        """Record a snapshot of current growth metrics to the ledger.

        Captures the current state of all tracked dimensions:
        knowledge (concepts, edges), self-improvement (proposals,
        experiments), dream synthesis (insights), and emotional
        development. Only records a milestone if the value has changed
        since the last snapshot.
        """
        self._record_knowledge_growth()
        self._record_competence_growth()
        self._record_self_improvement_growth()
        self._record_dream_growth()
        self._record_analogy_growth()
        self._record_inner_life_growth()

    def _record_knowledge_growth(self) -> None:
        net = self.brain.frontal.network
        self.growth_ledger.record(
            "knowledge",
            "concept_count",
            net.total_concept_count,
            f"Concept network: {net.total_concept_count} concepts",
        )
        self.growth_ledger.record(
            "knowledge",
            "edge_count",
            net.edge_count,
            f"Relationships: {net.edge_count} edges",
        )
        # Quality metrics: non-monotonic, can go up or down.
        self.growth_ledger.record(
            "knowledge",
            "mean_edge_weight",
            round(net.mean_edge_weight, 4),
            f"Mean edge weight: {net.mean_edge_weight:.3f}",
        )
        self.growth_ledger.record(
            "knowledge",
            "mean_concept_confidence",
            round(net.mean_concept_confidence, 4),
            f"Mean concept confidence: {net.mean_concept_confidence:.3f}",
        )
        self.growth_ledger.record(
            "knowledge",
            "network_density",
            round(net.network_density, 4),
            f"Network density: {net.network_density:.4f}",
        )

    def _record_competence_growth(self) -> None:
        """Learned abilities — schemas recognized, verified skills
        consolidated, episodes experienced. The procedural counterpart
        to the knowledge metrics."""
        competence = self.brain.frontal.task_competence
        self.growth_ledger.record(
            "competence",
            "skill_count",
            len(competence.skills),
            f"Verified skills: {len(competence.skills)}",
        )
        self.growth_ledger.record(
            "competence",
            "schema_count",
            len(competence.schemas),
            f"Task schemas recognized: {len(competence.schemas)}",
        )
        self.growth_ledger.record(
            "competence",
            "episode_count",
            sum(s.episodes for s in competence.schemas.values()),
            f"Task episodes: {sum(s.episodes for s in competence.schemas.values())}",
        )

    def _record_self_improvement_growth(self) -> None:
        proposals = self.self_improvement.get_all_proposals()
        accepted = sum(1 for p in proposals if p.status.value == "accepted")
        self.growth_ledger.record(
            "self_improvement",
            "proposals_total",
            len(proposals),
            f"Total proposals: {len(proposals)}",
        )
        self.growth_ledger.record(
            "self_improvement",
            "proposals_accepted",
            accepted,
            f"Accepted proposals: {accepted}",
        )
        self.growth_ledger.record(
            "self_improvement",
            "experiments_applied",
            self.heuristic_experiment.applied_count,
            f"Applied experiments: {self.heuristic_experiment.applied_count}",
        )

    def _record_dream_growth(self) -> None:
        dream_stats = self.inner_life.dream_synthesis_stats
        self.growth_ledger.record(
            "dreams",
            "insights_validated",
            dream_stats.get("validated", 0),
            f"Validated dream insights: {dream_stats.get('validated', 0)}",
        )
        self.growth_ledger.record(
            "dreams",
            "synthesis_proposed",
            dream_stats.get("proposed", 0),
            f"Dream synthesis proposals: {dream_stats.get('proposed', 0)}",
        )

    def _record_analogy_growth(self) -> None:
        """Cross-domain structure-mapping insights."""
        analogy_engine = self.brain.frontal.analogy_engine
        self.growth_ledger.record(
            "analogy",
            "insights_validated",
            analogy_engine.insight_count,
            f"Analogy insights: {analogy_engine.insight_count}",
        )
        self.growth_ledger.record(
            "analogy",
            "pairs_found",
            analogy_engine.pairs_found,
            f"Analogous pairs found: {analogy_engine.pairs_found}",
        )

    def _record_inner_life_growth(self) -> None:
        self.growth_ledger.record(
            "inner_life",
            "thought_count",
            self.inner_life.thought_count,
            # Say which population this is. The counter is merged, so a
            # bare "Spontaneous thoughts: 412" after a night's sleep was
            # mostly dreams wearing a thinking label.
            f"Spontaneous thoughts: {self.inner_life.thought_count} total "
            f"({self.inner_life.waking_thought_count} waking, "
            f"{self.inner_life.dream_count} dream sequences)",
        )
        self.growth_ledger.record(
            "inner_life",
            "dream_count",
            self.inner_life.dream_count,
            f"Dream sequences: {self.inner_life.dream_count}",
        )

    def growth_narrative(self) -> str:
        """Return a first-person narrative of Genesis's growth."""
        self.record_growth_snapshot()
        return self.growth_ledger.generate_narrative()

    def growth_report(self) -> str:
        """Return a markdown-formatted growth report."""
        self.record_growth_snapshot()
        return self.growth_ledger.generate_markdown_report()

    def growth_summary(self) -> str:
        """Return a brief summary of the growth ledger."""
        return self.growth_ledger.summary()

    def growth_snapshot(self) -> dict[str, Any]:
        """Return a snapshot of growth across all dimensions.

        Exposes the GrowthLedger's query APIs: milestone count,
        milestones per dimension, and latest values. This is for
        introspection — Genesis can query its own growth.
        """
        return {
            "milestone_count": self.growth_ledger.milestone_count,
            "milestones": [
                {
                    "dimension": m.dimension,
                    "metric": m.metric,
                    "value": m.value,
                    "note": m.note,
                }
                for m in self.growth_ledger.get_milestones()
            ],
        }

    def _growth_latest_values(self) -> dict[str, float]:
        """Return the latest recorded value for each (dimension, metric) pair.

        Uses the GrowthLedger's get_milestones API to find the most
        recent value per metric, exposing the get_value and get_latest
        query APIs for introspection.
        """
        latest: dict[str, float] = {}
        for m in self.growth_ledger.get_milestones():
            key = f"{m.dimension}/{m.metric}"
            # Milestones are in chronological order, so the last one
            # wins (most recent).
            latest[key] = m.value
        return latest

    def get_concept_summary(self) -> str:
        """Return a summary of Genesis's concept network."""
        return self.brain.frontal.get_concept_summary()

    def get_reflection_summary(self) -> str:
        """Return a summary of Genesis's recent self-reflections."""
        return self.brain.frontal.get_reflection_summary()

    def status(self) -> dict[str, Any]:
        """Return a status summary for display."""
        core_state = self.client.get_state()
        stats = self.client.get_memory_stats()
        summary = NeuroSummary(
            arousal=core_state.arousal,
            valence=core_state.valence,
            global_tone=core_state.global_tone,
            plasticity_gate=core_state.plasticity_gate,
            encoding_weight=core_state.encoding_weight,
            consolidation_weight=core_state.consolidation_weight,
            retrieval_weight=core_state.retrieval_weight,
            phase=self._effective_phase(core_state),
        )
        # Report the integrated field — the same state feel() exposes.
        # field.update is idempotent per elapsed time, so probing it
        # here only advances the integrator by the real interval.
        field_state = None
        try:
            field_state = self.client.get_field_state()
        except Exception as e:  # noqa: BLE001
            note_swallowed("mind.status.field_state", e)
        field = getattr(self.regulator, "field", None)
        if field is not None:
            emotion = field.update(summary, core_state.chemicals, field_state=field_state)
        else:
            emotion = assess_emotion(summary, core_state.chemicals, field_state=field_state)

        status = {
            "running": self._running,
            "interactions": self._interaction_count,
            # N1 is hypnagogia — the transitional state, not "nrem"
            # sleep; the displayed phase names the state she is in.
            "phase": "hypnagogic" if self.is_hypnagogic else summary.phase_name,
            "emotion": emotion.label,
            "arousal": summary.arousal,
            "valence": summary.valence,
            "plasticity": summary.plasticity_gate,
            "stm_count": stats.stm_count,
            "ltm_count": stats.ltm_count,
            "language": self.language.name,
            "allostatic_load": self.regulator.allostatic_load(),
            "hpa_active": self.regulator.hpa_axis.is_active,
            "primed_concepts": self.memory.priming.primed_count,
            "working_concepts": self.brain.frontal.network.size,
            "archive_concepts": self.brain.frontal.network.archive_size,
            "total_concepts": self.brain.frontal.network.total_concept_count,
        }
        status.update(self._extended_status())
        return status

    def _extended_status(self) -> dict[str, Any]:
        """Extended status fields for introspection.

        These are the subsystem-exposing fields that go beyond the
        basic runtime/emotion/memory stats in :meth:`status`. Each
        field exposes a subsystem's introspection API so the shape of
        its mind is visible from the outside.
        """
        from genesis_client.swallow import swallow_report

        return {
            # Swallowed exceptions — a count per catch site across both
            # layers. Every `except` that discards an error records here,
            # so a subsystem failing continuously shows up as a growing
            # number rather than as nothing at all. Read this before
            # concluding that a quiet subsystem is a healthy one.
            "swallowed_errors": swallow_report(),
            # Holographic graph — fixed-size associative memory stats.
            # Exposes the stats() API for introspection so the holographic
            # graph's state (edge count, storage, concepts/relations) is
            # visible alongside the explicit network stats.
            "holographic_graph": (
                self._sleep_compressor.holographic_graph.stats()
                if self._sleep_compressor is not None
                else {}
            ),
            # VQ codebook — vector quantization compression stats.
            # Exposes the stats() API for introspection so the codebook's
            # state (prototypes, compression ratio, reconstruction error)
            # is visible alongside the holographic graph stats.
            "vq_codebook": (
                self._sleep_compressor.vq_codebook.stats()
                if self._sleep_compressor is not None
                else {}
            ),
            # Growth ledger — how many milestones it's reached,
            # plus the latest values per dimension for introspection.
            "growth_milestones": self.growth_ledger.milestone_count,
            "growth_latest": self._growth_latest_values(),
            # User profile — what Genesis knows about the human. The
            # summarize() method returns a short, human-readable summary
            # of the user's name, preferences, and goals, exposing the
            # profile for introspection.
            "user_profile_summary": self.user_profile.summarize(),
            "user_interaction_count": self.user_profile.interaction_count,
            # Vision — whether the optic nerve is attached and what it
            # last saw. Exposes last_faces_seen() and last_objects_seen()
            # for introspection so its visual state is visible alongside
            # its cognitive state.
            "vision_available": self.vision.is_available(),
            "vision_last_faces": self.vision.last_faces_seen(),
            "vision_last_objects": self.vision.last_objects_seen(),
            # Volition — its current urges and their strengths, plus
            # the buildup records (onset→crossing→act) of the urges
            # that most recently fired: the readiness potential as
            # an introspectable datum.
            "volition_state": self.volition.state(),
            "volition_readiness": self.volition.readiness_report(),
            # Developmental stages — Erikson-like psychosocial stage
            # progress. Exposes the developmental_summary() API for
            # introspection so its current stage, crisis, and
            # resolution scores are visible.
            "developmental_summary": self.developmental_summary(),
            # HPA axis — the full stress response state (CRH, ACTH,
            # cortisol, peak cortisol, time to peak). The status
            # already includes hpa_active (boolean); this exposes the
            # full hpa_axis_status() dict for detailed introspection.
            "hpa_axis_status": self.hpa_axis_status(),
            # Narrative — its self-story stats. Exposes the narrative
            # engine's event_count, chapter_count, temporal_link_count,
            # and life-script deviations for introspection.
            "narrative_events": self.brain.frontal.narrative.event_count,
            "narrative_chapters": self.brain.frontal.narrative.chapter_count,
            "narrative_temporal_links": (self.brain.frontal.narrative.temporal_link_count),
            "narrative_life_script_deviations": (
                self.brain.frontal.narrative.deviation_from_script()
            ),
            # Subcognitive notifications — pending count from the
            # pull-based notification queue. Exposes peek() so the
            # queue depth is visible for introspection (e.g., checking
            # whether the cognitive layer is keeping up with the
            # subcognitive).
            "notifications_pending": self.notifications.peek(),
            # Projects — its creative output. Exposes counts so its
            # portfolio is visible for introspection (e.g., checking
            # how many projects it's built, how many are archived).
            "projects": self._projects_status_summary(),
            # Topology — structural self-awareness of its knowledge
            # network. Exposes graph-theoretic metrics (clustering,
            # small-world coefficient, communities, hubs, bridges)
            # so the shape of its knowledge is visible for
            # introspection. Computed lazily and cached by the
            # topology module; refreshed after sleep consolidation.
            "topology": self._topology_status_summary(),
        }

"""Thought types — the data structures of spontaneous thought.

ThoughtChainType classifies trains of thought (focused, creative
wandering, rumination, dream). SpontaneousThought is the unit of
inner experience: a thought that arose on its own, carrying content,
trigger, chain metadata, dream metadata, and optional semantic
metadata for the language engine.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from enum import Enum
from typing import Any

from self import Insight

__all__ = ["SpontaneousThought", "ThoughtChainType"]

# Terminal punctuation and a leading capital are cosmetic — the grammar
# adds both on its way out. Comparisons between what a thought asked to
# be said and what the engine actually said have to ignore them.
_TERMINAL_PUNCT_RE = re.compile(r"[\s.!?]+$")


class ThoughtChainType(Enum):
    """The type of a train of thought.

    Not all mind-wandering is the same. A chain of thoughts can be:

    - FOCUSED: directed, productive thinking — following a thread
      deliberately. Positive or neutral valence, moderate novelty.
    - CREATIVE_WANDERING: positive-valence mind-wandering that
      produces novel connections. The mind drifts, but productively —
      new ideas emerge from the drift. High novelty, positive valence.
    - RUMINATION: negative-valence mind-wandering that is repetitive
      and unproductive. The mind loops on the same negative content
      without resolution. Low novelty, negative valence.
    - DREAM: dream content generated during sleep. Markedly different
      from waking thought — associative, surreal, less logical.
    """

    FOCUSED = "focused"
    CREATIVE_WANDERING = "creative_wandering"
    RUMINATION = "rumination"
    DREAM = "dream"


@dataclass(slots=True)
class SpontaneousThought:
    """A thought that arose on its own, not in response to anything."""

    content: str
    trigger: str  # what caused this thought
    timestamp: int = 0
    insight: Insight | None = None
    # Chain metadata: if this thought is part of a train of thought,
    # chain_id identifies the chain and chain_position is the index
    # within it (0 = first thought, 1 = second, etc.)
    chain_id: int = 0
    chain_position: int = 0
    # Dream metadata: if this thought arose during sleep, is_dream marks
    # it as dream content. is_lucid marks a lucid dream — one where it
    # became aware it was dreaming and could partially direct the
    # content. directed_concept is the concept it "chose" to explore
    # during a lucid dream (None for non-lucid dreams).
    is_dream: bool = False
    is_lucid: bool = False
    directed_concept: str | None = None
    # Intent: "question" means this thought is a question directed at
    # the user, "reflect" means it's a reflective insight, None means
    # it's just internal musing.
    intent: str | None = None
    # Semantic metadata: when present, the language engine composes the
    # actual words from this data instead of using `content` as final
    # text. This satisfies the CRITICAL RULE — Genesis's words emerge
    # from its language engine, not from pre-written templates.
    # Keys: "knowledge" (list of (relation, target, weight) triples),
    # "topic" (str), "definition" (str|None), "reasoning" (list[str]).
    metadata: dict | None = None

    # Triggers that are dream-derived rather than waking cognition. A
    # dream reflection is a waking thought *about* a dream, so its
    # is_dream is False — but it is still not something she decided to go
    # and learn about.
    DREAM_DERIVED_TRIGGERS = frozenset(
        {
            "dream",
            "lucid-dream",
            "dream-reflection",
            "rem-dream",
            "nrem-dream",
            "dream_insight",
        }
    )

    def is_dream_derived(self) -> bool:
        """True if this thought's content originates in sleep.

        This is *not* the same question as :attr:`is_dream`, which means
        "generated while asleep". The distinction matters because the
        autonomous learner is fed from thought topics, and the codebase's
        stated invariant is that dream material never becomes a learning
        goal — dreams produce affective impressions, not prefrontal goals.
        Overloading ``is_dream`` as that filter let waking reflections on
        dream residues ("I was dreaming about...") through, contradicting
        the invariant those comments assert.
        """
        if self.is_dream:
            return True
        if self.trigger in self.DREAM_DERIVED_TRIGGERS:
            return True
        meta = self.metadata or {}
        return bool(meta.get("is_dream") or meta.get("dream"))

    def is_learning_target(self) -> bool:
        """True if this thought may seed autonomous learning.

        Hypnagogic content is a learning target: it happens while she is
        still awake and drowsy, reflecting on the day, and deliberately
        getting it out of the learner's reach would be a regression. The
        exclusion is specifically dream-derived material.
        """
        return not self.is_dream_derived()

    def describe(self) -> str:
        """Return a human-readable summary of the thought."""
        prefix = f"[{self.trigger}]"
        if self.is_lucid:
            prefix = f"[{self.trigger}, lucid]"
        elif self.is_dream:
            prefix = f"[{self.trigger}, dream]"
        return f"{prefix} {self.content}"

    def rendered_text(self, language: Any, emotion: Any) -> str:
        """Compose the final text via the language engine.

        If metadata with semantic data is present, the language engine
        composes the actual words from it — this satisfies the CRITICAL
        RULE (Genesis's words emerge from its language engine, not from
        pre-written templates). If no metadata is present, falls back
        to `content`.
        """
        meta = self.metadata
        if meta is not None and (meta.get("knowledge") is not None or meta.get("self_fragments")):
            from temporal_lobe.base import Thought as _Thought

            thought = _Thought(
                content=self.content,
                intent=(
                    "reflect"
                    if self.is_dream
                    else "self_report"
                    if meta.get("self_fragments")
                    else "inform"
                ),
                emotion=getattr(emotion, "label", "neutral"),
                topics=[meta.get("topic", "")] if meta.get("topic") else [],
                confidence=0.6,
                metadata=meta,
            )
            text = language.render(thought, emotion)
            # All speech comes from the engine. When it was given real
            # semantic triples and could only echo the placeholder
            # content back unchanged, the thought stays sub-verbal —
            # an association the mind made but could not articulate —
            # rather than surfacing raw concept pairs as utterances.
            #
            # The comparison has to be case- and punctuation-blind. The
            # grammar capitalizes the first word and appends a period
            # on its way out, so a literal `==` misses the echo every
            # time and lets the placeholder through as speech.
            if meta.get("knowledge") and _same_utterance(text, self.content):
                return ""
            return text
        return self.content


def _same_utterance(left: str, right: str) -> bool:
    """Return True when two strings are the same utterance cosmetically.

    Ignores surrounding whitespace, a leading capital, and terminal
    punctuation — the differences the grammar introduces between what a
    thought asked to be said and what the engine produced. Anything
    more than that is a real difference in words.
    """

    def norm(text: str) -> str:
        """Normalize for comparison — trim, lowercase, drop terminal punctuation."""
        return _TERMINAL_PUNCT_RE.sub("", text.strip()).lower()

    return bool(norm(left)) and norm(left) == norm(right)

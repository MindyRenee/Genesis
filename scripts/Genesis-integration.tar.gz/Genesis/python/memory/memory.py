"""Memory engine — retrieves and contextualises memories.

The subcognitive handles raw memory storage (STM ring buffer, LTM
episodic store). The memory engine is the cognitive layer's interface
to that storage: it retrieves relevant memories, builds context for
the current conversation, and tracks what Genesis remembers.

Key responsibilities:
- Retrieve memories similar to the current topic
- Track conversation history (short-term, in-process)
- Build a "memory context" that cognition uses when thinking
- Decide which memories are worth surfacing

In addition to retrieval, the engine models several biological memory
processes on the Python side (the Rust daemon stores the raw episodes;
this layer tracks the metadata needed for consolidation dynamics):

- **Sleep-specific consolidation** — SWS replays and transfers
  hippocampal memories to neocortex; REM consolidates emotional and
  procedural memories.
- **Forgetting** — Ebbinghaus decay, proactive/retroactive
  interference, retrieval failure, and adaptive forgetting.
- **Reconsolidation** — recalled memories become briefly labile and
  can be strengthened, weakened, or emotionally re-tagged.
- **Systems consolidation** — hippocampal dependency decays over time
  as memories become neocortical (the temporal gradient of retrograde
  amnesia).
- **Synaptic vs systems consolidation** — fast LTP-like strengthening
  (minutes-hours) is distinguished from slow redistribution
  (days-weeks).
"""

from __future__ import annotations

import bisect
import hashlib
import logging
import math
import random
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import numpy as np
from thalamus.brain_waves import SleepStage

from genesis_client import GenesisClient
from genesis_client.protocol import EMOTIONAL_TAG_SIZE
from genesis_client.swallow import note_swallowed
from genesis_client.types import Episode, SimilarEpisode
from infrastructure.config import MemoryConfig

from .systems import (
    AttractorNetwork,
    EmotionalMemorySystem,
    PrimingSystem,
    SpreadingActivation,
)
from .working import (
    CentralExecutive,
    PhonologicalLoop,
    VisuoSpatialSketchpad,
)

__all__ = [
    "ConversationTurn",
    "MemoryContext",
    "MemoryRecord",
    "MemorySystem",
    "ReconsolidationModification",
    "SourceTag",
]

logger = logging.getLogger(__name__)

# Width of the proactive/retroactive interference window, in seconds.
# Records encoded within this window of each other interfere. Because
# `forget()` sorts by `encoded_at`, this makes the interfering set a
# contiguous slice, which is what allows the interference sum to be
# computed by bisect instead of by copying the list twice per record.
_INTERFERENCE_WINDOW_S: float = 3600.0

if TYPE_CHECKING:  # pragma: no cover — import only for type checkers
    from limbic_system.emotion import EmotionalState
    from temporal_lobe.concepts import ConceptNetwork


def _snapshot[T](fn: Callable[[], Iterable[T]], attempts: int = 8) -> list[T]:
    """Materialize a collection that other threads may be mutating.

    ``serialize_records`` can run on the autosave/shutdown thread while
    background consolidation or replay mutates ``_records``; iterating a
    live dict view raises ``RuntimeError``. Bounded retry yields a
    consistent point-in-time copy instead. Mirrors the helper in
    ``persistence.py`` (kept local to avoid a circular import).
    """
    for _ in range(attempts - 1):
        try:
            return list(fn())
        except RuntimeError:
            continue
    return list(fn())


@dataclass(slots=True)
class ConversationTurn:
    """A single turn in the conversation."""

    role: str  # "user" or "genesis"
    text: str
    timestamp: int
    topics: list[str] = field(default_factory=list)
    sentiment: float = 0.0


@dataclass(slots=True)
class MemoryContext:
    """What Genesis remembers when forming a response."""

    # Recent conversation (last N turns)
    recent_turns: list[ConversationTurn] = field(default_factory=list)

    # Memories retrieved from LTM that are relevant to current topic
    retrieved: list[SimilarEpisode] = field(default_factory=list)

    # Facts Genesis has learned about the user
    user_facts: dict[str, str] = field(default_factory=dict)

    # How many episodes are in LTM total
    total_memories: int = 0

    # Whether this is the first interaction
    is_first_interaction: bool = True

    def summary(self) -> str:
        """Brief text summary for introspection."""
        parts = []
        if self.total_memories > 0:
            parts.append(f"{self.total_memories} long-term memories")
        if self.retrieved:
            parts.append(f"{len(self.retrieved)} relevant memories recalled")
        if self.recent_turns:
            parts.append(f"{len(self.recent_turns)} turns in this conversation")
        if self.user_facts:
            parts.append(f"knows {len(self.user_facts)} facts about the user")
        return ", ".join(parts) if parts else "no memories yet"


# ─── Python-side memory metadata ─────────────────────────────────────


@dataclass(slots=True)
class MemoryRecord:
    """Python-side metadata tracking a single LTM episode.

    The Rust daemon stores the raw episode data (text, emotional tag,
    salience, hashes). This record tracks the *consolidation state*
    that the Python side needs for the biological memory processes:
    hippocampal dependency, reconsolidation lability, synaptic
    consolidation strength, access times, and forgetting state.

    Attributes:
        episode_id: The LTM episode ID (matches the Rust store).
        salience: Memory salience [0..1] — may be modified by
            reconsolidation.
        emotional_tag: EMOTIONAL_TAG_SIZE-chemical emotional snapshot (mutable —
            reconsolidation can re-tag).
        encoded_at: When the memory was encoded (ms).
        last_accessed: When the memory was last recalled (ms).
        access_count: Number of times retrieved.
        hippocampal_dependency: 1.0 = fully hippocampal-dependent
            (recent), 0.0 = fully neocortical (remote). Decays over
            time via systems consolidation.
        synaptic_strength: Fast (LTP-like) consolidation strength
            [0..1]. Boosted immediately after encoding.
        systems_strength: Slow (systems) consolidation strength
            [0..1]. Grows as the memory is redistributed to neocortex.
        retention: Current retention level [0..1] after decay and
            interference. When it drops below the forgetting
            threshold, the memory is considered forgotten.
        forgotten: Whether this memory has been forgotten.
        reconsolidation_window: Remaining time (seconds) in the
            reconsolidation labile window. >0 means the memory is
            currently modifiable.
        last_reconsolidated: When the memory was last reconsolidated
            (ms), 0 if never.
        source_tag: Source monitoring tag (Johnson et al., 1993).
            Tracks where the memory came from (user, genesis,
            learning, inference, imagination). Used for reality
            monitoring and confabulation detection. ``None`` for
            memories created before source monitoring was added.
        somatic: Body state at encoding — flat dict from
            ``SomaticSnapshot.to_dict`` (arousal, valence, tone,
            plasticity, balance). ``None`` for memories encoded
            before somatic tagging. Powers state-dependent
            retrieval: recall favours memories encoded in a similar
            bodily state (Eich 1980; Bower 1981).
        tag_strength: Synaptic tag [0..1] (Frey & Morris, 1997). Set
            at encoding proportional to induction strength, reset on
            reconsolidation, decays over ~hours. While the tag is
            open, a phasic dopamine/NE event can *capture* plasticity-
            related proteins and convert the trace to late-LTP.
        late_strength: Committed late-LTP component [0..1] — the
            protein-synthesis-dependent part of the trace. Acts as a
            floor on retention: the committed fraction survives
            Ebbinghaus decay (late-LTP is the persistence the tag
            buys).
    """

    episode_id: int
    salience: float = 0.5
    emotional_tag: list[float] = field(default_factory=lambda: [0.5] * EMOTIONAL_TAG_SIZE)
    encoded_at: int = 0
    last_accessed: int = 0
    access_count: int = 0
    hippocampal_dependency: float = 1.0
    synaptic_strength: float = 0.3
    systems_strength: float = 0.0
    retention: float = 1.0
    forgotten: bool = False
    reconsolidation_window: float = 0.0
    last_reconsolidated: int = 0
    reconsolidation_count: int = 0
    source_tag: SourceTag | None = None
    somatic: dict[str, float] | None = None
    tag_strength: float = 0.0
    late_strength: float = 0.0


# ─── Reconsolidation modification ────────────────────────────────────


@dataclass(slots=True)
class SourceTag:
    """Source monitoring tag for a memory (Johnson et al., 1993).

    Tracks where a memory came from — whether it was said by the user,
    generated by Genesis, learned from external docs, inferred, or
    imagined. This is the basis of reality monitoring: distinguishing
    internally-generated from externally-provided information.

    Without source monitoring, the system cannot detect confabulation
    (mistaking inferred or imagined content for observed fact) or
    source amnesia (remembering a fact but not where it came from).

    Attributes:
        source: Origin of the memory. One of:
            - "user": the user said this
            - "genesis": Genesis generated this (response, thought)
            - "conversation": a user+genesis interaction
            - "learning": learned from external source (docs, web)
            - "inference": Genesis inferred this (not directly observed)
            - "imagination": hypothetical / imagined
            - "self_analysis": Genesis analyzed its own code
            - "world": an external world event it observed (presence,
              percept, notice) — not addressed to it like conversation
        modality: How the memory was received — "text", "visual",
            "auditory", "internal".
        confidence: Confidence in the source attribution [0..1].
            Lower confidence means the source is uncertain, increasing
            the risk of source monitoring errors.
    """

    source: str = "unknown"
    modality: str = "text"
    confidence: float = 0.8


# Valid source categories for source monitoring.
VALID_SOURCES: frozenset[str] = frozenset(
    {
        "user",
        "genesis",
        "conversation",
        "learning",
        "inference",
        "imagination",
        "self_analysis",
        "world",
        "unknown",
    }
)


@dataclass(slots=True)
class ReconsolidationModification:
    """A modification applied to a memory during reconsolidation.

    When a memory is recalled it becomes labile for a brief window
    (~6 hours in humans, scaled appropriately here). During this
    window the memory can be strengthened, weakened, or emotionally
    re-tagged. The current emotional state modulates the memory's
    emotional tag (reconsolidation is state-dependent).

    Attributes:
        strength_delta: Change to salience/retention (positive
            strengthens, negative weakens).
        emotional_tag: Optional new emotional tag to blend in.
        blend_factor: How much of the new emotional tag to blend in
            [0..1] (0 = keep old, 1 = replace entirely).
    """

    strength_delta: float = 0.0
    emotional_tag: list[float] | None = None
    blend_factor: float = 0.3


class MemorySystem:
    """Manages memory retrieval and conversation tracking.

    Wraps the GenesisClient to provide a higher-level memory interface
    that the cognition system can use. In addition to retrieval, it
    models biological memory processes: sleep-specific consolidation,
    forgetting, reconsolidation, and synaptic vs systems consolidation.
    """

    # ── Consolidation / forgetting constants ─────────────────────
    # Ebbinghaus decay time constant (seconds). Higher tau → slower
    # forgetting. Salience scales tau: more salient memories decay
    # more slowly (retention = e^(-t / (tau * salience_factor))).
    _FORGETTING_TAU: float = 86400.0 * 7.0  # ~1 week baseline
    # How long a forgotten record is kept before eviction. Nothing
    # reads a forgotten record, but dropping one in the same pass that
    # flags it would make the transition invisible to introspection and
    # would delete in bulk; a grace period keeps it inspectable.
    _FORGOTTEN_EVICTION_GRACE_MS: int = 3600_000  # 1 hour
    # Below this retention, a memory is considered forgotten.
    _FORGETTING_THRESHOLD: float = 0.05
    # Reconsolidation labile window (seconds). ~6 hours in humans,
    # scaled down for Genesis's faster clock.
    _RECONSOLIDATION_WINDOW: float = 3600.0 * 6.0
    # Boundary condition: reconsolidation only triggers when prediction
    # error (mismatch between expected and actual memory content) exceeds
    # this threshold. Recall without prediction error strengthens the
    # memory via retrieval practice but does NOT make it labile.
    # (Schiller et al., 2010; Sevenster et al., 2014)
    _RECONSOLIDATION_PE_THRESHOLD: float = 0.2
    # Retrieval practice boost — recalling a memory strengthens it
    # (Roediger & Karpicke, 2006). Applied on every successful recall
    # regardless of prediction error.
    _RETRIEVAL_PRACTICE_BOOST: float = 0.03
    # Retrieval-induced forgetting (Anderson et al., 1994): when a
    # memory is retrieved, competing memories (emotionally similar
    # but not retrieved) are weakened. This is the competitive
    # inhibition underlying retrieval practice costs.
    _RIF_COMPETITION_THRESHOLD: float = 0.6  # similarity above this = competition
    _RIF_WEAKENING_RATE: float = 0.03  # weakening per competing memory
    # ── Engram release (active forgetting) ─────────────────────
    # A verbatim episode is a hippocampal engram: spine density on a
    # cell ensemble, not a stored file. It survives while maintenance
    # beats turnover. The drive below is the log of that balance:
    #
    #   B = ln(reactivation_sum) + depth − cortical_redundancy
    #
    # with each term carrying a biological citation (see
    # ``engram_drive``). Release — daemon delete — happens when B
    # drops under ``_RELEASE_THRESHOLD``: the engram's spine density
    # is below the floor any natural cue could drive, i.e.
    # substrate-dead. Nothing calendar-based decides; her own access
    # history is the maintenance budget.
    _RELEASE_THRESHOLD: float = -2.0
    # Encoding-depth weights: salience is amygdala/NE tagging at write
    # time (McGaugh 2000), arousal the intensity of the emotional tag —
    # deeper initial encoding = larger initial spine volume.
    _RELEASE_SALIENCE_W: float = 1.0
    _RELEASE_AROUSAL_W: float = 0.5
    # Systems-consolidation discount: once the content is redistributed
    # to neocortex (systems_strength — her holographic gist), the
    # hippocampal verbatim is redundant and its maintenance budget is
    # cheaper to stop paying. Standard consolidation theory.
    _RELEASE_CORTICAL_W: float = 0.75
    # Floor on event ages (days). The power law t^(-0.5) diverges at
    # t→0; ~8.6 s keeps a brand-new use finite.
    _RELEASE_MIN_AGE_DAYS: float = 1e-4
    # Cortical-strength estimate for archived entries with no record:
    # the compressor bound their co-occurrence gist into the
    # holographic graph at archive time, so a partial cortical copy
    # exists even where the mind kept no record.
    _ARCHIVED_GIST_CORTICAL: float = 0.5
    # Deep-recall gate (Hamming bits, 64-bit SimHash): when active
    # recall returns no result within the daemon's association
    # threshold (20 bits — see ASSOCIATION_THRESHOLD in ltm.rs), the
    # query reaches into the archived tier. Below this gate the active
    # set already has a real answer and the archive stays cold.
    _DEEP_RECALL_DISTANCE_GATE: int = 20
    # Experience replay during NREM sleep (Kirkpatrick et al., 2017):
    # old memories are replayed during SWS to prevent catastrophic
    # forgetting. The number of old memories replayed per N3 cycle.
    _REPLAY_SAMPLE_SIZE: int = 10
    # Replay strengthening — less than recent replay (0.1) to avoid
    # over-strengthening old memories at the expense of new ones.
    _REPLAY_STRENGTHENING: float = 0.04
    # Hippocampal dependency decay rate per systems-consolidation
    # cycle. Each cycle reduces dependency by this fraction.
    _HIPPOCAMPAL_DECAY: float = 0.15
    # Synaptic consolidation boost applied immediately after encoding.
    _SYNAPTIC_BOOST: float = 0.4
    # ── Synaptic tag and capture (Frey & Morris, 1997) ──────────
    # Early-LTP sets a tag at the potentiated synapse; the tag alone
    # decays within ~1–3 h. Late-LTP requires plasticity-related
    # proteins (PRPs), whose synthesis is gated by dopamine (D1/D5)
    # and noradrenaline arriving within the tag window. Tagged
    # synapses *capture* from a shared, finite protein pool — so a
    # strong dopaminergic event commits every memory tagged in the
    # window (behavioral tagging; Redondo & Morris, 2011), while
    # untagged traces fade with early-LTP.
    # Tag lifetime ~1 h (scaled down like the reconsolidation window).
    _TAG_TAU_S: float = 3600.0
    # Below this tag strength the tag is treated as closed.
    _TAG_EPSILON: float = 1e-3
    # Effective dopamine level that opens the capture gate — resting
    # tonic (~0.35) must not commit anything; phasic bursts do.
    _CAPTURE_DA_THRESHOLD: float = 0.5
    # Noradrenaline opens the same gate: β-adrenergic activation in
    # the amygdala converts early→late LTP without a dopaminergic
    # event (Hu et al., 2007; Roozendaal & McGaugh, 2011 — the
    # flashbulb pathway: emotional arousal commits memory with no
    # reward prediction error). Baseline NE ~0.30; bursts exceed 0.55.
    _CAPTURE_NE_THRESHOLD: float = 0.55
    # Fraction of an open tag converted to late-LTP per capture pass
    # (bounded by the protein pool — synthesis is rate-limited).
    _CAPTURE_GAIN: float = 0.5
    # Shared plasticity-related protein pool: capacity and the amount
    # regenerated per N3 consolidation pass (scaled by the sleep
    # intensity drive). Sleep resynthesizes PRPs — this is a real
    # reason consolidation needs sleep, not a batch schedule.
    _PROTEIN_POOL_CAP: float = 1.0
    _PROTEIN_REGEN_N3: float = 0.5

    def __init__(
        self,
        client: GenesisClient,
        max_turns: int = 20,
        network: ConceptNetwork | None = None,
        get_emotion: Callable[[], EmotionalState | list[float]] | None = None,
        *,
        config: MemoryConfig | None = None,
    ) -> None:
        """Initialize the memory engine with client, network, and emotion callback."""
        self.client = client
        self.config = config if config is not None else MemoryConfig()
        self.max_turns = max_turns
        self.conversation: list[ConversationTurn] = []
        self._user_facts: dict[str, str] = {}
        self._is_first = True

        # ── Python-side memory metadata (items 1-5) ──────────────
        # episode_id → MemoryRecord. Tracks consolidation state that
        # the Rust store doesn't hold.
        self._records: dict[int, MemoryRecord] = {}
        # Instance RNG — replay sampling must not be steered by (or
        # perturb) the global random state.
        self._rng = random.Random()
        # Counters for introspection.
        self.forgotten_count: int = 0
        self.reconsolidation_count: int = 0
        self.synaptic_consolidation_count: int = 0
        self.systems_consolidation_count: int = 0
        self.sleep_consolidation_count: int = 0
        self.facts_replayed_count: int = 0
        self.tag_capture_count: int = 0
        # Shared plasticity-related protein pool (tag-and-capture):
        # depleted by capture events, resynthesized during SWS.
        self._protein_pool: float = self._PROTEIN_POOL_CAP

        # Optional callback: called with replayed episode text so the
        # semantic memory / concept network can extract relationships.
        # This closes the loop between episodic replay and neocortical
        # semantic storage (systems consolidation).
        self.semantic_replay_callback: Callable[[str], Any] | None = None
        # Optional callback: called when a high-emotion memory is stored
        # so the sleep system can queue it for REM emotional processing.
        self.emotional_memory_callback: Callable[[str, float], Any] | None = None
        # ── Wired-in memory subsystems ───────────────────────────
        # These were built as standalone modules but never connected
        # to the memory lifecycle. Here they are wired into storing
        # and retrieving so Genesis actually uses them.

        # Optional hooks supplied by the Mind:
        # - ``network``: the shared concept network, used by priming
        #   and spreading activation to propagate to neighbours.
        # - ``get_emotion``: callback returning the current emotional
        #   state (an EmotionalState or a chemical vector), used
        #   for emotional tagging and mood-congruent retrieval.
        self._network = network
        self._get_emotion = get_emotion
        # Somatic recall hooks (wired by the Mind; None keeps legacy
        # behaviour):
        # - ``somatic_provider``: returns the current body snapshot
        #   as a flat dict (SomaticSnapshot.to_dict()).
        # - ``somatic_weight``: recall re-rank strength. Bounded to
        #   [0, 0.5]; small by design so body-congruence biases but
        #   never overrides semantic order on its own.
        self.somatic_provider: Callable[[], dict[str, float] | None] | None = None
        self.somatic_weight: float = 0.15

        # Emotional memory (amygdala-dependent): tags memories with
        # emotional context and prioritises emotionally congruent
        # memories during retrieval (mood-congruent memory).
        self.emotional_memory = EmotionalMemorySystem()

        # Priming (implicit memory): recent concepts prime related
        # concepts, boosting their accessibility.
        self.priming = PrimingSystem(network=network)

        # Attractor networks (CA3 auto-association): pattern
        # completion — given a partial cue, complete the pattern to
        # the nearest stored memory.
        self.attractor = AttractorNetwork(size=64)

        # Spreading activation (Collins & Loftus, 1975): activating a
        # concept spreads to its neighbours, sustaining semantic
        # priming over time.
        self.spreading_activation = SpreadingActivation(network=network)

        # ── Enhanced working memory (Baddeley model) ─────────────
        # The MemorySystem exposes the phonological loop (verbal
        # rehearsal buffer) and central executive (attention
        # controller) so other systems can use rehearsal and
        # attention direction through the memory engine.
        self.phonological_loop = PhonologicalLoop()
        self.visuospatial_sketchpad = VisuoSpatialSketchpad()
        self.central_executive = CentralExecutive(
            phonological_loop=self.phonological_loop,
            sketchpad=self.visuospatial_sketchpad,
        )

    def add_turn(
        self,
        role: str,
        text: str,
        topics: list[str] | None = None,
        sentiment: float = 0.0,
    ) -> None:
        """Record a conversation turn."""
        turn = ConversationTurn(
            role=role,
            text=text,
            timestamp=int(time.time() * 1000),
            topics=topics or [],
            sentiment=sentiment,
        )
        self.conversation.append(turn)
        if len(self.conversation) > self.max_turns:
            self.conversation = self.conversation[-self.max_turns :]
        if role == "user":
            self._is_first = False

        # Wire the turn's concepts into priming and spreading
        # activation so recently-discussed concepts become more
        # accessible (semantic priming).
        self._activate_concepts(turn.topics)

    def store_memory(
        self,
        text: str,
        salience: float = 0.5,
        emotional_tag: list[float] | None = None,
        event_type: int = 0,
        source_module: int = 4,
        source: str = "unknown",
        source_confidence: float = 0.8,
        memory_mode: str = "balanced",
        somatic: dict[str, float] | None = None,
    ) -> bool:
        """Store a deliberate memory directly in LTM.

        Deliberate memory stores (conversation turns, learning events)
        bypass STM and go straight to LTM via ``store_episode``, which
        returns the real LTM episode ID synchronously. This is distinct
        from raw pre-cognitive events (visual observations, spontaneous
        thoughts) which use ``store_event`` (the STM path) and are
        filtered by salience during consolidation.

        After storing, registers a :class:`MemoryRecord` for Python-side
        consolidation tracking and immediately applies *synaptic
        consolidation* — the fast LTP-like strengthening that happens
        within minutes of encoding (item 5).

        Args:
            text: The memory text content.
            salience: Memory salience [0..1].
            emotional_tag: Advisory chemical snapshot — the daemon
                stamps the tag from its own live effective levels on
                store, and the returned stamped tag is what the
                MemoryRecord carries. Pass None when there is no
                caller-side tag.
            event_type: Event type code for the daemon.
            source_module: Source module ID for the daemon.
            source: Source monitoring tag — where this memory came
                from. One of: "user", "genesis", "conversation",
                "learning", "inference", "imagination",
                "self_analysis", "unknown". Used for reality
                monitoring (Johnson et al., 1993).
            source_confidence: Confidence in the source attribution
                [0..1]. Lower values indicate uncertain source, which
                increases the risk of source monitoring errors.
            memory_mode: Theta-gamma coupling mode — "encoding",
                "retrieval", or "balanced". In encoding mode, salience
                is boosted (the hippocampus is biased toward forming
                new associations). In retrieval mode, salience is
                dampened (the hippocampus is reactivating, not
                encoding).
            somatic: Body state at encoding as a flat dict
                (``SomaticSnapshot.to_dict()``). When None, the
                engine consults ``somatic_provider`` if wired.
        """
        # Theta-gamma coupling gates encoding strength.
        # In encoding mode, the theta trough aligns gamma bursts for
        # new association formation — boost salience so the memory is
        # more likely to consolidate. In retrieval mode, dampen it.
        if memory_mode == "encoding":
            salience = min(1.0, salience * 1.2)
        elif memory_mode == "retrieval":
            salience = max(0.0, salience * 0.8)

        # Clamp salience and emotional_tag to [0,1] with NaN/Inf
        # replaced by neutral defaults, matching the Rust IPC's
        # finite_clamp. This ensures the Python-side MemoryRecord,
        # the Rust-side LTM store, and the wired subsystems all
        # agree on the same values.
        salience = _finite_clamp(salience, 0.0, 1.0, default=0.5)
        if emotional_tag is not None:
            emotional_tag = [_finite_clamp(v, 0.0, 1.0, default=0.5) for v in emotional_tag]
        eid, stamped_tag = self.client.store_episode(
            timestamp=int(time.time() * 1000),
            event_type=event_type,
            source_module=source_module,
            salience=salience,
            emotional_tag=emotional_tag,
            text=text,
        )
        if eid is None:
            return False
        if stamped_tag is not None:
            # The daemon stamped the tag from its live effective
            # levels — the record carries exactly what was stored.
            emotional_tag = stamped_tag
        elif emotional_tag is None:
            # Legacy daemon without the stamped-tag tail: the wire
            # carried all-zeros, so a live fetch is the closest
            # record of the body's chemistry at encode time.
            emotional_tag = self.client.live_emotional_tag() or [0.0] * EMOTIONAL_TAG_SIZE
        if somatic is None and self.somatic_provider is not None:
            try:
                somatic = self.somatic_provider()
            except Exception:  # noqa: BLE001
                somatic = None
        self._register_memory_record(
            eid,
            salience,
            emotional_tag,
            source,
            source_confidence,
            somatic=somatic,
        )
        # Item 5: immediate synaptic consolidation.
        self.synaptic_consolidate(eid)

        # ── Wire the new memory into the subsystems ──────────
        self._wire_memory_subsystems(eid, text, emotional_tag)
        return True

    def _register_memory_record(
        self,
        eid: int,
        salience: float,
        emotional_tag: list[float],
        source: str,
        source_confidence: float,
        somatic: dict[str, float] | None = None,
    ) -> None:
        """Register a MemoryRecord for Python-side consolidation tracking.

        The ``eid`` is the real LTM episode ID returned by
        ``store_episode``. The record tracks consolidation state that
        the Rust store doesn't hold.

        Salience and emotional_tag are clamped to [0,1] with NaN/Inf
        replaced by neutral defaults, matching the Rust IPC's
        ``finite_clamp``. Without this, the Python-side record and the
        Rust-side store would disagree on salience when the caller
        passes out-of-range values, causing the forgetting formula
        (which scales tau by rec.salience) to produce incorrect decay.
        """
        clean_salience = _finite_clamp(salience, 0.0, 1.0, default=0.5)
        clean_tag = [_finite_clamp(v, 0.0, 1.0, default=0.5) for v in emotional_tag]
        record = MemoryRecord(
            episode_id=eid,
            salience=clean_salience,
            emotional_tag=clean_tag,
            encoded_at=int(time.time() * 1000),
            last_accessed=int(time.time() * 1000),
            source_tag=SourceTag(
                source=source if source in VALID_SOURCES else "unknown",
                modality="text",
                confidence=max(0.0, min(1.0, source_confidence)),
            ),
            somatic=dict(somatic) if isinstance(somatic, dict) else None,
            # Encoding sets the synaptic tag proportional to induction
            # strength (Frey & Morris): a weakly-encoded trace tags
            # weakly and needs a bigger dopaminergic event to persist.
            tag_strength=clean_salience,
        )
        self._records[eid] = record

    def _wire_memory_subsystems(self, eid: int, text: str, emotional_tag: list[float]) -> None:
        """Wire a newly stored memory into emotional, attractor, and priming subsystems.

        - Emotional memory: tag the memory with the current emotional state
          (mood-congruent encoding). The stimulus is the memory's primary
          concept (or a short text key) so it can be retrieved later by
          emotional congruence.
        - Attractor network: store a pattern for this memory so partial cues
          can be completed to it later (CA3 pattern completion).
        - Priming / spreading activation: activate the concepts embedded in
          the memory text so related concepts become more accessible.
        """
        self._store_emotional_tag(text, emotional_tag)
        self.attractor.store(str(eid), _text_to_vector(text, self.attractor.size))
        self._activate_concepts(_extract_concepts(text))
        # Feed high-emotion memories to the sleep system for REM
        # emotional processing. Without this, the REM emotional
        # memory queue is always empty.
        if self.emotional_memory_callback is not None:
            intensity = _emotional_intensity(emotional_tag)
            if intensity > 0.3:
                try:
                    self.emotional_memory_callback(text[:200], intensity)
                except Exception as e:  # noqa: BLE001
                    note_swallowed(
                        "memory.memory._wire_memory_subsystems",
                        e,
                    )

    def retrieve_relevant(
        self,
        query: str,
        limit: int = 5,
        prediction_error: float = 0.0,
    ) -> list[SimilarEpisode]:
        """Retrieve memories similar to the query text.

        Retrieved memories are marked as accessed. The reconsolidation
        labile window only opens if ``prediction_error`` exceeds the
        boundary threshold — recall without prediction error
        strengthens the memory (retrieval practice) but does not make
        it labile (Schiller et al., 2010; Sevenster et al., 2014).

        The retrieval pipeline now uses the wired-in subsystems:

        - **Attractor networks**: the query is fed to the attractor
          network for pattern completion. If a stored pattern is
          recovered, the corresponding episode is ensured a place in
          the results (pattern completion from a partial cue).
        - **Spreading activation / priming**: concepts in the query
          are activated so semantically related concepts become more
          accessible for subsequent retrievals.
        - **Mood-congruent memory**: results are re-ranked so that
          memories whose emotional tag matches the current emotional
          state are prioritised (Bower, 1981).
        - **Deep recall / reconsolidation**: when the active set has no
          answer within association range, the query falls through to
          the archived tier — episodes sleep compression retired but
          kept intact. An archived hit that survives re-ranking into
          the returned list is un-archived: retrieval is what earns a
          memory its place back in the active index, and the next
          sleep pass retains what recall actually used.

        Args:
            query: The text to search for.
            limit: Maximum number of results.
            prediction_error: Mismatch between expected and actual
                memory content [0..1]. When this exceeds the
                reconsolidation threshold, recalled memories become
                labile. Defaults to 0.0 (retrieval practice only, no
                reconsolidation).
        """
        # Activate the query's concepts (semantic priming for future
        # retrievals) before searching.
        _t0 = time.perf_counter()
        query_concepts = _extract_concepts(query)
        self._activate_concepts(query_concepts)
        _t_activate = time.perf_counter() - _t0

        _t0 = time.perf_counter()
        try:
            results = self.client.find_similar(query, limit=limit)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"find similar failed: {e}")
            results = []
        results = list(results)

        results, deep_ids = self._deep_recall_merge(query, results, limit)
        _t_find = time.perf_counter() - _t0

        _t0 = time.perf_counter()
        # Pattern completion: feed the query to the attractor network.
        # If it converges to a stored pattern whose episode is not
        # already in the results, try to retrieve that episode and
        # prepend it (the cue was partial — the network completed it).
        if results is not None:
            results = self._apply_attractor_completion(results, query, limit)
        _t_attractor = time.perf_counter() - _t0

        _t0 = time.perf_counter()
        # Emotional memory bias: compute a weighted emotional tag for
        # the query concepts, then re-rank by emotional congruence.
        # Emotional associations shape what we remember (Bower, 1981;
        # Phelps, 2004).
        query_emotion = self._compute_query_emotion(query_concepts)
        results = self._rank_by_emotional_congruence(results, query_emotion=query_emotion)
        # Somatic (state-dependent) re-rank: memories encoded in a
        # body state similar to the current one are easier to recall
        # (Eich 1980). Additive and bounded — never overrides the
        # semantic order entirely, just biases it. No-op when no
        # somatic snapshots exist or no provider is wired.
        results = self._rank_by_somatic_congruence(results)
        _t_emotion = time.perf_counter() - _t0

        _t0 = time.perf_counter()
        now_ms = int(time.time() * 1000)
        opens_window = prediction_error >= self.config.reconsolidation_pe_threshold
        retrieved_ids = [r.episode_id for r in results]
        self._post_retrieval(results, deep_ids, retrieved_ids, opens_window, now_ms)
        _t_post = time.perf_counter() - _t0
        logger.debug(
            f"retrieve_relevant sub-timing: "
            f"activate={_t_activate:.3f}s "
            f"find_similar={_t_find:.3f}s "
            f"attractor={_t_attractor:.3f}s "
            f"emotion={_t_emotion:.3f}s "
            f"post={_t_post:.3f}s "
            f"query='{query[:60]}'"
        )
        return results

    def _deep_recall_merge(
        self,
        query: str,
        results: list,
        limit: int,
    ) -> tuple[list, set[int]]:
        """Deep recall — the archived tier. The active index only holds
        what compression kept verbatim; everything else is intact but
        out of every associative path. When active recall has no hit
        inside the association gate — a miss or only far noise —
        reach into the cold store and merge by distance, so a sharp
        old memory can outrank a faint active one. Hits that survive
        the re-rank below are reconsolidated.

        Returns ``(results, deep_ids)`` — the re-ranked list and the
        archived episode ids that made it in.
        """
        deep_ids: set[int] = set()
        best_active = min((r.hamming_distance for r in results), default=64)
        if len(results) < limit or best_active > self._DEEP_RECALL_DISTANCE_GATE:
            try:
                deep = self.client.find_similar_archived(query, limit=limit)
            except Exception as e:  # noqa: BLE001
                logger.warning(f"deep recall failed: {e}")
                deep = []
            if deep:
                active_ids = {r.episode_id for r in results}
                fresh = [d for d in deep if d.episode_id not in active_ids]
                if fresh:
                    revived = {d.episode_id for d in fresh}
                    results = sorted([*results, *fresh], key=lambda r: r.hamming_distance)[:limit]
                    deep_ids = revived & {r.episode_id for r in results}
        return results, deep_ids

    def _post_retrieval(
        self,
        results: list,
        deep_ids: set[int],
        retrieved_ids: list[int],
        opens_window: bool,
        now_ms: int,
    ) -> None:
        """Bookkeeping after a retrieval — reconsolidation, access
        marks, retrieval-induced forgetting, confabulation flags."""
        # Reconsolidation: deep hits that survived the re-rank were
        # actually retrieved — return them to the active index (the
        # daemon re-bundles their SDR and floors their salience above
        # the compressor's retention threshold).
        for ep_id in deep_ids & set(retrieved_ids):
            try:
                self.client.unarchive_episode(ep_id)
            except Exception as e:  # noqa: BLE001
                note_swallowed(
                    "memory.memory.retrieve_relevant.unarchive",
                    e,
                )
        for r in results:
            self._mark_accessed(r.episode_id, now_ms, opens_window)
        # Retrieval-induced forgetting: weaken competing (emotionally
        # similar but non-retrieved) memories (Anderson et al., 1994).
        self._apply_retrieval_induced_forgetting(retrieved_ids)
        # Source monitoring: flag high-confabulation-risk memories so
        # the cognition engine can treat them with appropriate caution.
        # Memories from "inference" or "imagination" with low source
        # confidence are more likely to be confabulated (Johnson et al.,
        # 1993). We don't remove them — they may still be useful — but
        # we log the risk for introspection.
        for r in results:
            risk = self.check_confabulation_risk(r.episode_id)
            if risk > 0.7:
                logger.debug(f"high confabulation risk ({risk:.2f}) for episode {r.episode_id}")

    def _compute_query_emotion(self, query_concepts: list[str]) -> list[float] | None:
        """Compute a weighted emotional tag for the query concepts.

        Retrieves emotional associations for the query concepts and
        produces a weighted-average emotional tag. This biases
        retrieval toward memories whose emotional tag matches the
        emotional associations of the query concepts (not just the
        current mood) — emotional associations shape what we remember
        (Bower, 1981; Phelps, 2004).
        """
        em_weights: list[tuple[list[float], float]] = []
        current_emotion = self._current_emotion_vector()
        for concept in query_concepts:
            em = self.emotional_memory.retrieve_emotional(concept, current_emotion)
            if em is not None and not em.is_extinct:
                em_weights.append((em.emotional_tag, em.association_strength))
        if em_weights:
            total = sum(w for _, w in em_weights)
            if total > 0:
                n = min(len(tag) for tag, _ in em_weights)
                return [sum(tag[i] * w for tag, w in em_weights) / total for i in range(n)]
        return None

    def retrieve_episode(
        self,
        episode_id: int,
        prediction_error: float = 0.0,
    ) -> Episode | None:
        """Retrieve a specific episode by ID.

        Marks the memory as accessed. The reconsolidation labile window
        only opens if ``prediction_error`` exceeds the boundary
        threshold (Schiller et al., 2010). Without prediction error,
        the memory is strengthened by retrieval practice but does not
        become labile.

        Args:
            episode_id: The episode ID to retrieve.
            prediction_error: Mismatch between expected and actual
                memory content [0..1]. Defaults to 0.0.
        """
        try:
            ep = self.client.retrieve_episode(episode_id)
        except Exception as e:  # noqa: BLE001
            # Expected when sleep compression has pruned the episode.
            note_swallowed(
                "memory.memory.retrieve_episode",
                e,
            )
            return None
        if ep is not None:
            opens_window = prediction_error >= self.config.reconsolidation_pe_threshold
            self._mark_accessed(episode_id, int(time.time() * 1000), opens_window)
        return ep

    def _mark_accessed(self, episode_id: int, now_ms: int, opens_window: bool) -> None:
        """Mark a memory as accessed, applying retrieval practice and
        optionally opening the reconsolidation window.

        Retrieval practice (Roediger & Karpicke, 2006): every
        successful recall strengthens the memory slightly, regardless
        of prediction error. The reconsolidation labile window only
        opens when ``opens_window`` is True (i.e. prediction error
        exceeded the boundary threshold).
        """
        rec = self._records.get(episode_id)
        if rec is None or rec.forgotten:
            return
        rec.last_accessed = now_ms
        rec.access_count += 1
        # Retrieval practice: recalling a memory strengthens it.
        rec.retention = min(1.0, rec.retention + self._RETRIEVAL_PRACTICE_BOOST)
        rec.synaptic_strength = min(1.0, rec.synaptic_strength + self._RETRIEVAL_PRACTICE_BOOST)
        # Boundary condition: only open the reconsolidation window
        # when prediction error exceeds threshold.
        if opens_window:
            rec.reconsolidation_window = self.config.reconsolidation_window_seconds

    def _replay_into_semantic_graph(self, episode_id: int) -> int:
        """Replay a single episode's text into the semantic graph.

        Called during sleep consolidation. If a ``semantic_replay_callback``
        is wired (e.g. :meth:`SemanticMemory.extract_facts`), the episode
        text is passed to it and the returned fact count is accumulated.

        Returns:
            Number of facts extracted from the replayed episode.
        """
        if self.semantic_replay_callback is None:
            return 0

        try:
            ep = self.client.retrieve_episode(episode_id)
        except Exception as e:  # noqa: BLE001
            # Expected when sleep compression has pruned the episode.
            note_swallowed(
                "memory.memory._replay_into_semantic_graph",
                e,
            )
            return 0
        if ep is None or not ep.text:
            return 0

        # Do not mark the memory as accessed here — this is an offline
        # replay, not an explicit recall. The consolidation methods
        # already update synaptic strength separately.
        try:
            result = self.semantic_replay_callback(ep.text)
            if isinstance(result, int):
                self.facts_replayed_count += result
                return result
            if isinstance(result, list):
                n_facts = len(result)
                self.facts_replayed_count += n_facts
                return n_facts
            # Treat any other truthy result as one fact extracted.
            self.facts_replayed_count += 1
            return 1
        except Exception as e:  # noqa: BLE001
            logger.warning(f"semantic replay callback failed: {e}")
            return 0

    def _apply_retrieval_induced_forgetting(
        self,
        retrieved_ids: list[int],
    ) -> int:
        """Apply retrieval-induced forgetting (Anderson et al., 1994).

        When memories are retrieved, competing memories — those with
        high emotional similarity to the retrieved ones but not
        themselves retrieved — are weakened. This models the
        competitive inhibition that underlies retrieval practice
        costs: practicing some facts makes related but unpracticed
        facts harder to recall.

        The weakening is proportional to emotional similarity (the
        closer a memory's emotional tag is to a retrieved memory's,
        the more it competes and the more it is weakened). Memories
        that are high in salience or emotional intensity are more
        resistant to RIF.

        Returns the number of memories weakened.
        """
        if not retrieved_ids:
            return 0
        retrieved_set = set(retrieved_ids)
        weakened = 0

        # Collect the emotional tags of retrieved memories.
        retrieved_tags: list[list[float]] = []
        for eid in retrieved_ids:
            rec = self._records.get(eid)
            if rec is not None and not rec.forgotten:
                retrieved_tags.append(rec.emotional_tag)

        if not retrieved_tags:
            return 0

        # Gather candidate records (non-retrieved, non-forgotten).
        candidate_eids: list[int] = []
        candidate_tags: list[list[float]] = []
        for eid, rec in list(self._records.items()):
            if eid in retrieved_set or rec.forgotten:
                continue
            candidate_eids.append(eid)
            candidate_tags.append(rec.emotional_tag)

        if not candidate_eids:
            return 0

        # Vectorized cosine similarity: (M × D) @ (D × R) → (M × R).
        # Take the max over R to find each candidate's strongest competitor.
        cand_mat = np.array(candidate_tags, dtype=np.float64)
        retr_mat = np.array(retrieved_tags, dtype=np.float64)
        # Pad to matching column count if tags differ in length.
        d = max(cand_mat.shape[1], retr_mat.shape[1])
        if cand_mat.shape[1] < d:
            cand_mat = np.pad(cand_mat, ((0, 0), (0, d - cand_mat.shape[1])))
        if retr_mat.shape[1] < d:
            retr_mat = np.pad(retr_mat, ((0, 0), (0, d - retr_mat.shape[1])))

        cand_norms = np.linalg.norm(cand_mat, axis=1)
        retr_norms = np.linalg.norm(retr_mat, axis=1)
        # Avoid division by zero.
        cand_norms[cand_norms < 1e-9] = 1e-9
        retr_norms[retr_norms < 1e-9] = 1e-9

        sim_matrix = (cand_mat @ retr_mat.T) / np.outer(cand_norms, retr_norms)
        sim_matrix = np.clip(sim_matrix, 0.0, 1.0)
        max_sims = sim_matrix.max(axis=1)

        threshold = self.config.rif_competition_threshold
        for idx, eid in enumerate(candidate_eids):
            max_similarity = float(max_sims[idx])
            if max_similarity < threshold:
                continue
            rec = self._records[eid]
            # High-salience and emotionally intense memories resist RIF.
            resistance = 0.5 * rec.salience + 0.3 * _emotional_intensity(rec.emotional_tag)
            weakening = self._RIF_WEAKENING_RATE * max_similarity * (1.0 - resistance)
            rec.retention = max(0.0, rec.retention - weakening)
            rec.synaptic_strength = max(0.0, rec.synaptic_strength - weakening)
            weakened += 1
            # Check if the memory has been forgotten as a result.
            if rec.retention < self.config.forgetting_threshold:
                rec.forgotten = True
                self.forgotten_count += 1
        return weakened

    def learn_user_fact(self, key: str, value: str) -> None:
        """Learn a fact about the user."""
        self._user_facts[key] = value

    def get_user_facts(self) -> dict[str, str]:
        """Return known facts about the user."""
        return dict(self._user_facts)

    def build_context(
        self, current_topics: list[str], memory_mode: str = "balanced"
    ) -> MemoryContext:
        """Build a memory context for the current conversation state.

        Retrieves relevant memories and assembles them with conversation
        history into a context the cognition system can use.

        The retrieval query is enriched by the wired-in subsystems:

        - **Priming**: currently-primed concepts are appended to the
          query so recently-activated topics bias retrieval.
        - **Spreading activation**: concepts with residual spreading
          activation are appended, modelling semantic priming.
        - **Attractor networks / mood-congruent memory**: applied
          inside :meth:`retrieve_relevant`.

        Args:
            current_topics: Topics to retrieve memories for.
            memory_mode: Theta-gamma coupling mode — "encoding",
                "retrieval", or "balanced". In retrieval mode, more
                memories are fetched (the hippocampus is biased toward
                reactivation). In encoding mode, fewer are fetched
                (the hippocampus is biased toward forming new
                associations, not retrieving old ones).
        """
        # Theta-gamma coupling gates retrieval breadth.
        # In retrieval mode, the theta peak aligns gamma bursts for
        # memory reactivation — broaden the search. In encoding mode,
        # the theta trough aligns gamma for new associations — narrow
        # the search so the focus is on encoding, not retrieval.
        retrieval_limit = 5
        if memory_mode == "retrieval":
            retrieval_limit = 7
        elif memory_mode == "encoding":
            retrieval_limit = 3

        # Try to retrieve relevant memories from LTM
        retrieved: list[SimilarEpisode] = []
        if current_topics:
            query = self._enrich_query(" ".join(current_topics))
            retrieved = self.retrieve_relevant(query, limit=retrieval_limit)

        # Get total memory count
        try:
            stats = self.client.get_memory_stats()
            total = stats.ltm_count
        except Exception as e:  # noqa: BLE001
            logger.warning(f"get memory stats failed: {e}")
            total = 0

        return MemoryContext(
            recent_turns=list(self.conversation[-10:]),
            retrieved=retrieved,
            user_facts=dict(self._user_facts),
            total_memories=total,
            is_first_interaction=self._is_first,
        )

    def get_recent_topics(self, n: int = 5) -> list[str]:
        """Get topics from the last N conversation turns."""
        topics: list[str] = []
        for turn in self.conversation[-n:]:
            topics.extend(turn.topics)
        # Deduplicate while preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for t in topics:
            if t not in seen:
                seen.add(t)
                unique.append(t)
        return unique

    # ═══════════════════════════════════════════════════════════════
    #  Wired-in memory subsystem helpers
    # ═══════════════════════════════════════════════════════════════

    def _current_emotion_vector(self) -> list[float] | None:
        """Return the current emotional state as an emotional tag vector.

        Uses the ``get_emotion`` callback supplied at construction.
        The callback may return either an :class:`EmotionalState`
        (whose ``chemicals`` dict is mapped to the canonical chemical order,
        defaulting to 0.5 for missing chemicals) or a raw vector
        list. Returns ``None`` if no callback is wired.
        """
        if self._get_emotion is None:
            return None
        try:
            state = self._get_emotion()
        except Exception as e:  # noqa: BLE001
            logger.warning(f"get emotion failed: {e}")
            return None
        if state is None:
            return None
        if isinstance(state, list):
            return list(state)
        # EmotionalState — build a tag vector from the chemicals dict.
        from genesis_client.protocol import CHEM_NAMES

        vector = [0.5] * EMOTIONAL_TAG_SIZE
        chemicals = getattr(state, "chemicals", {}) or {}
        for idx in range(EMOTIONAL_TAG_SIZE):
            name = CHEM_NAMES.get(idx)
            if name is not None and name in chemicals:
                vector[idx] = float(chemicals[name])
        return vector

    def _activate_concepts(self, concepts: list[str]) -> None:
        """Activate concepts in priming and spreading activation.

        After each interaction, the discussed concepts prime related
        concepts (PrimingSystem) and spread activation through the
        concept network (SpreadingActivation). This is how semantic
        priming works — related concepts become more accessible.
        """
        for concept in concepts:
            if not concept:
                continue
            self.priming.prime(concept)
            self.spreading_activation.activate(concept)

    def _store_emotional_tag(
        self,
        text: str,
        emotional_tag: list[float],
    ) -> None:
        """Tag a memory with emotional context (mood-congruent encoding).

        Records an emotional association in the
        :class:`EmotionalMemorySystem` keyed by the memory's primary
        concept, using the *current* emotional state (from the
        ``get_emotion`` callback) when available, falling back to the
        memory's own emotional tag. The association strength scales
        with emotional intensity — emotionally charged memories are
        encoded more strongly (amygdala modulation of hippocampal
        encoding; McGaugh, 2004).

        Fear conditioning is reserved for negatively-valenced memories
        (high cortisol / low dopamine). Positive memories are tagged
        via their ``MemoryRecord.emotional_tag`` but do not create
        aversive associations.
        """
        stimulus = _primary_concept(text)
        if not stimulus:
            return
        # Prefer the live emotional state; fall back to the memory's
        # own tag.
        current = self._current_emotion_vector()
        tag = current if current is not None else emotional_tag
        intensity = _emotional_intensity(tag)
        # Only record an association when there is meaningful
        # emotional content; otherwise the memory is still tagged via
        # its MemoryRecord.emotional_tag.
        if intensity <= 0.05:
            return
        # Fear conditioning is specifically for aversive memories.
        # Cortisol (idx 6) is the stress hormone; dopamine (idx 0)
        # tracks valence. Only condition when the tag indicates
        # negative valence — sending positive memories through fear
        # conditioning would create spurious aversive associations.
        # Cortisol's envelope tops out around ~0.08 (resting ~0.02,
        # stress-phase gate 0.06), so 0.05 is the "stress load" boundary
        # that lets a stressed memory condition even when dopamine is
        # still high.
        cortisol_idx = 6
        dopamine_idx = 0
        cortisol = tag[cortisol_idx] if len(tag) > cortisol_idx else 0.0
        dopamine = tag[dopamine_idx] if len(tag) > dopamine_idx else 0.5
        if cortisol <= 0.05 and dopamine >= 0.5:
            return
        self.emotional_memory.fear_conditioning(
            neutral_stimulus=stimulus,
            negative_emotion_strength=intensity,
            emotional_tag=list(tag),
        )

    def _enrich_query(self, query: str) -> str:
        """Enrich a retrieval query with primed/activated concepts.

        Currently-primed concepts (PrimingSystem) and concepts with
        residual spreading activation are appended to the query so
        that recently-activated topics bias retrieval (semantic
        priming).
        """
        extras: list[str] = []
        try:
            primed = self.priming.get_all_primed(threshold=self.config.priming_threshold)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"get primed concepts failed: {e}")
            primed = {}
        for concept, _level in sorted(primed.items(), key=lambda kv: kv[1], reverse=True):
            if concept.lower() not in query.lower():
                extras.append(concept)
        try:
            activated = self.spreading_activation.get_all(threshold=self.config.spreading_threshold)
        except Exception as e:  # noqa: BLE001
            logger.warning(f"get activated concepts failed: {e}")
            activated = {}
        for concept, _level in sorted(activated.items(), key=lambda kv: kv[1], reverse=True):
            if concept.lower() not in query.lower() and concept not in extras:
                extras.append(concept)
        if not extras:
            return query
        # Limit the number of extra concepts to avoid diluting the
        # query too much.
        return query + " " + " ".join(extras[:5])

    def _apply_attractor_completion(
        self,
        results: list[SimilarEpisode],
        query: str,
        limit: int,
    ) -> list[SimilarEpisode]:
        """Use the attractor network for pattern completion.

        Feeds the query (a partial cue) to the Hopfield network. If
        it converges to a stored pattern whose episode is not already
        present in the results, the corresponding episode is fetched
        and prepended — the cue was partial and the network completed
        it (CA3 auto-association).
        """
        if self.attractor.pattern_count == 0:
            return results
        match_id, _t_retrieve = self._attractor_retrieve(query)
        if match_id is None:
            logger.debug(
                f"attractor: retrieve={_t_retrieve:.3f}s "
                f"patterns={self.attractor.pattern_count} "
                f"no match"
            )
            return results
        # The documented over_capacity contract: past Hopfield capacity
        # the update rule can converge to a spurious attractor, so a
        # match is a suggestion rather than a confident recall — it
        # neither boosts an existing result nor synthesizes a head
        # entry; it is surfaced at the tail where ranking keeps the
        # semantic evidence in charge.
        suggestive = self.attractor.over_capacity
        try:
            eid = int(match_id)
        except (TypeError, ValueError):
            return results
        # Already present — boost it to the front.
        for r in results:
            if r.episode_id == eid:
                if not suggestive:
                    results.remove(r)
                    results.insert(0, r)
                return results[:limit]
        # Not in results — try to fetch the episode and synthesize a
        # result entry for it.
        ep, _t_fetch = self._fetch_attractor_episode(eid)
        if ep is None:
            logger.debug(
                f"attractor: retrieve={_t_retrieve:.3f}s "
                f"fetch={_t_fetch:.3f}s "
                f"patterns={self.attractor.pattern_count} "
                f"match={eid} but episode pruned"
            )
            return results
        completed = SimilarEpisode(
            episode_id=eid,
            # A confident completion claims the match it made — the
            # re-rank passes below score salience - distance/64, so 0
            # keeps it first. A suggestive (over-capacity) match is
            # not a measured similarity at all: scoring it 0 would
            # let a possibly-spurious attractor outrank real semantic
            # hits in the re-rank and defeat the tail placement.
            hamming_distance=64 if suggestive else 0,
            timestamp=ep.timestamp,
            salience=ep.salience,
        )
        if suggestive:
            results.append(completed)
        else:
            results.insert(0, completed)
        self._surface_attractor_associations(
            eid, results, _t_retrieve, _t_fetch, suggestive=suggestive
        )
        return results[:limit]

    def _attractor_retrieve(self, query: str) -> tuple[Any, float]:
        """Run the Hopfield retrieve for *query*.

        Returns ``(match_id, elapsed_s)`` — ``match_id`` is None when
        retrieval fails or no stored pattern converged.
        """
        import time as _attractor_time

        _t0 = _attractor_time.perf_counter()
        try:
            _completed, match_id = self.attractor.retrieve(
                _text_to_vector(query, self.attractor.size)
            )
        except Exception as e:  # noqa: BLE001
            logger.warning(f"attractor retrieve failed: {e}")
            match_id = None
        return match_id, _attractor_time.perf_counter() - _t0

    def _fetch_attractor_episode(self, eid: int) -> tuple[Any, float]:
        """Fetch the episode an attractor match points at.

        Returns ``(episode, elapsed_s)`` — ``episode`` is None when the
        match refers to an episode sleep compression has pruned.
        """
        import time as _attractor_time

        _t0 = _attractor_time.perf_counter()
        try:
            ep = self.client.retrieve_episode(eid)
        except Exception as e:  # noqa: BLE001
            # Expected when sleep compression has pruned the episode.
            note_swallowed(
                "memory.memory._fetch_attractor_episode",
                e,
            )
            ep = None
        return ep, _attractor_time.perf_counter() - _t0

    def _surface_attractor_associations(
        self,
        eid: int,
        results: list[SimilarEpisode],
        _t_retrieve: float,
        _t_fetch: float,
        *,
        suggestive: bool = False,
    ) -> None:
        """CA3 auto-association: surface episodes similar to the
        completed pattern — related memories the hippocampal CA3
        region co-activates when one is recalled.

        Associated episodes were never measured against the query,
        so they do not claim a direct-match distance. They carry the
        deep-recall gate distance — the edge of association range —
        which ranks them below direct hits and above far noise. When
        the anchor itself is suggestive (over-capacity attractor),
        its associations are doubly indirect and stay weakest."""
        import time as _attractor_time

        _t0 = _attractor_time.perf_counter()
        similar_ids = self.attractor.auto_associate(str(eid))
        _t_auto = _attractor_time.perf_counter() - _t0
        _t0 = _attractor_time.perf_counter()
        _fetched = 0
        for sid in similar_ids:
            try:
                sid_eid = int(sid)
            except (TypeError, ValueError):
                continue
            # Skip if already in results
            if any(r.episode_id == sid_eid for r in results):
                continue
            try:
                sep = self.client.retrieve_episode(sid_eid)
            except Exception:  # noqa: BLE001
                continue
            if sep is not None:
                results.append(
                    SimilarEpisode(
                        episode_id=sid_eid,
                        hamming_distance=(64 if suggestive else self._DEEP_RECALL_DISTANCE_GATE),
                        timestamp=sep.timestamp,
                        salience=sep.salience,
                    )
                )
                _fetched += 1
        _t_assoc_fetch = _attractor_time.perf_counter() - _t0
        logger.debug(
            f"attractor: retrieve={_t_retrieve:.3f}s "
            f"fetch={_t_fetch:.3f}s "
            f"auto_assoc={_t_auto:.3f}s "
            f"assoc_fetch={_t_assoc_fetch:.3f}s "
            f"patterns={self.attractor.pattern_count} "
            f"similar_ids={len(similar_ids)} fetched={_fetched}"
        )

    def _rank_by_emotional_congruence(
        self,
        results: list[SimilarEpisode],
        query_emotion: list[float] | None = None,
    ) -> list[SimilarEpisode]:
        """Re-rank results by mood congruence (Bower, 1981).

        Memories whose stored emotional tag matches the current
        emotional state are boosted in the ranking. The base score is
        derived from salience (higher is better) and hamming distance
        (lower is better); an emotional-congruence bonus is added on
        top.

        If ``query_emotion`` is provided (an emotional tag
        derived from the query's emotional memory associations), it is
        blended with the current mood to form the target emotional
        state for congruence scoring. This biases retrieval toward
        memories that match the emotional associations of the query
        concepts, not just the current mood.
        """
        if not results:
            return results
        current = self._current_emotion_vector()
        if current is None and query_emotion is None:
            return results

        # Blend the current mood with the query's emotional associations.
        # When both are available, the query emotion gets more weight
        # (0.6) because it reflects the emotional context of the
        # retrieval, not just the ambient mood.
        if current is not None and query_emotion is not None:
            target = [0.4 * c + 0.6 * q for c, q in zip(current, query_emotion, strict=False)]
        elif query_emotion is not None:
            target = query_emotion
        else:
            target = current  # type: ignore[assignment]

        def _score(r: SimilarEpisode) -> float:
            """Score a retrieved episode by salience, recency, and emotional congruence."""
            # Base score: salience minus normalised hamming distance.
            # hamming_distance is the number of differing bits between
            # 64-bit SimHash fingerprints, so it ranges [0, 64].
            # Dividing by 64 normalises it to [0, 1] to match the
            # salience range [0, 1], so the two terms contribute on the
            # same scale.
            base = r.salience - (r.hamming_distance / 64.0)
            rec = self._records.get(r.episode_id)
            if rec is None or rec.forgotten:
                return base
            congruence = _emotional_similarity(target, rec.emotional_tag)
            return base + congruence

        return sorted(results, key=_score, reverse=True)

    def _rank_by_somatic_congruence(
        self,
        results: list[SimilarEpisode],
    ) -> list[SimilarEpisode]:
        """Re-rank results by body-state congruence (Eich, 1980).

        Memories encoded in a bodily state similar to the current one
        are easier to recall. The bonus is additive and bounded by
        ``somatic_weight`` (default 0.15), so it biases but never
        overrides semantic order on its own.

        No-op when no ``somatic_provider`` is wired, when the current
        snapshot is unavailable, or when none of the candidates carry
        a somatic tag — legacy states recall exactly as before.
        """
        if not results or self.somatic_provider is None:
            return results
        try:
            current = self.somatic_provider()
        except Exception:  # noqa: BLE001
            return results
        if not current:
            return results
        weight = max(0.0, min(0.5, self.somatic_weight))
        if weight <= 0.0:
            return results
        if not any(
            (rec := self._records.get(r.episode_id)) is not None
            and rec.somatic
            and not rec.forgotten
            for r in results
        ):
            return results

        from insula.somatic import somatic_congruence as _cong

        def _score(r: SimilarEpisode) -> float:
            base = r.salience - (r.hamming_distance / 64.0)
            rec = self._records.get(r.episode_id)
            if rec is None or rec.forgotten or not rec.somatic:
                return base
            try:
                return base + weight * _cong(current, rec.somatic)
            except Exception:  # noqa: BLE001
                return base

        return sorted(results, key=_score, reverse=True)

    def somatic_congruence_of(self, episode_id: int) -> float | None:
        """Congruence between now and an episode's encoding state.

        Returns None when either snapshot is missing — the caller can
        treat that as "no bodily evidence", never as dissimilarity.
        Useful for introspection and for the Damasio as-if loop.
        """
        if self.somatic_provider is None:
            return None
        try:
            current = self.somatic_provider()
        except Exception:  # noqa: BLE001
            return None
        rec = self._records.get(episode_id)
        if current is None or rec is None or not rec.somatic:
            return None
        from insula.somatic import somatic_congruence as _cong

        try:
            return _cong(current, rec.somatic)
        except Exception:  # noqa: BLE001
            return None

    # ── Enhanced working-memory access ───────────────────────────

    def rehearse(self, item: str) -> bool:
        """Rehearse a verbal item in the phonological loop.

        Exposes the phonological loop's rehearsal so other systems can
        keep a concept "in mind" through the memory engine (the
        articulatory control process; Baddeley, 1992).

        Returns:
            ``True`` if the item was present and rehearsed.
        """
        return self.phonological_loop.rehearse_item(item)

    def direct_attention(
        self,
        items: dict[str, float],
        relevant: list[str],
    ) -> dict[str, float]:
        """Direct attention to relevant concepts via the central executive.

        Exposes the central executive's attention-direction function
        so other systems can boost relevant concepts and suppress
        irrelevant ones through the memory engine.
        """
        return self.central_executive.direct_attention(items, relevant)

    @property
    def turn_count(self) -> int:
        """Total number of turns in this conversation."""
        return len(self.conversation)

    @property
    def is_first_interaction(self) -> bool:
        """Whether this is the first interaction in the session."""
        return self._is_first

    # ═══════════════════════════════════════════════════════════════
    #  Item 1: Sleep-specific consolidation
    # ═══════════════════════════════════════════════════════════════

    def consolidate_during_sleep(
        self, sleep_stage: SleepStage, duration: float, consolidation_intensity: float = 0.5
    ) -> int:
        """Consolidate memories appropriately for the given sleep stage.

        Sleep consolidates memory in a stage-specific manner
        (Diekelmann & Born, 2010):

        - **N3 (slow-wave sleep)**: Recent hippocampal memories are
          replayed in compressed time and transferred to neocortical
          storage (systems consolidation). Spindle-ripple coupling
          (thalamocortical spindles nested with hippocampal
          sharp-wave ripples) drives this transfer. SWS favours
          declarative memory.
        - **N2**: Sleep spindles drive hippocampal→neocortical
          transfer — the bulk of memory transfer happens here.
        - **REM sleep**: Emotional and procedural memories are
          consolidated. The amygdala is highly active during REM,
          strengthening emotional associations. REM favours
          procedural and emotional memory.
        - **N1**: The lightest NREM stage — minor consolidation.

        Args:
            sleep_stage: The current sleep stage (from
                :class:`~thalamus.brain_waves.SleepStage`).
            duration: Duration of the sleep period in seconds.
            consolidation_intensity: Brain-wave-derived consolidation
                drive [0, 1] from ``BrainWaveState.consolidation``.
                Scales how much consolidation happens — high theta/
                delta power with high neurochemical consolidation
                weight produces more replay and transfer. Default
                0.5 (moderate).

        Returns:
            Number of memories processed during this sleep period.
        """
        processed = 0
        now_ms = int(time.time() * 1000)
        # Recent memories = encoded within ~2x the duration window.
        recent_cutoff = now_ms - int(duration * 2000)

        # Scale the consolidation strength by the brain-wave-derived
        # consolidation intensity. High theta/delta power + high
        # neurochemical consolidation weight → stronger replay and
        # transfer. Low intensity → weaker consolidation (e.g. during
        # stress, when cortisol suppresses consolidation).
        strength_scale = 0.3 + 0.7 * max(0.0, min(1.0, consolidation_intensity))

        if sleep_stage == SleepStage.N3:
            # SWS: replay recent memories + systems consolidation.
            processed = self._consolidate_n3(recent_cutoff, strength_scale)
            # Slow-wave sleep resynthesizes plasticity-related
            # proteins — the pool that tag-and-capture draws from is
            # finite and regenerates offline, which is why a strong
            # day of learning literally needs the night.
            self._protein_pool = min(
                self._PROTEIN_POOL_CAP,
                self._protein_pool + self._PROTEIN_REGEN_N3 * strength_scale,
            )
        elif sleep_stage == SleepStage.N2:
            # N2: sleep spindles drive hippocampal→neocortical transfer.
            # The bulk of memory transfer happens in N2.
            processed = self._consolidate_n2(strength_scale)
        elif sleep_stage == SleepStage.REM:
            # REM: consolidate emotional and procedural memories.
            processed = self._consolidate_rem(recent_cutoff, strength_scale)
        elif sleep_stage == SleepStage.N1:
            # N1: the lightest stage — minor replay.
            processed = self._consolidate_n1(recent_cutoff, strength_scale)

        self.sleep_consolidation_count += processed

        # Forgetting runs during N2 sleep — the brain prunes irrelevant
        # memories during sleep spindles. N3 is for replay and
        # consolidation (strengthening), so forgetting during N3 would
        # counteract the strengthening. N2 is for transfer, making it
        # the right stage for pruning memories that aren't being
        # transferred. Ebbinghaus decay, interference, and adaptive
        # forgetting all apply here.
        if sleep_stage == SleepStage.N2:
            self.forget(now=time.time())

        return processed

    def _consolidate_n3(self, recent_cutoff: int, strength_scale: float = 1.0) -> int:
        """SWS: replay recent memories + systems consolidation + experience replay."""
        processed = 0
        replayed_ids: list[int] = []
        for rec in list(self._records.values()):
            if rec.forgotten:
                continue
            if rec.encoded_at >= recent_cutoff:
                # Replay in compressed time strengthens the trace.
                rec.synaptic_strength = min(1.0, rec.synaptic_strength + 0.1 * strength_scale)
                rec.retention = min(1.0, rec.retention + 0.05 * strength_scale)
                replayed_ids.append(rec.episode_id)
                processed += 1
            # Spindle-ripple coupling drives hippocampal→neocortical
            # transfer for ALL non-forgotten memories (not just
            # recent ones — the transfer is gradual).
            if rec.hippocampal_dependency > 0.0:
                rec.hippocampal_dependency = max(
                    0.0,
                    rec.hippocampal_dependency - self._HIPPOCAMPAL_DECAY * strength_scale,
                )
                rec.systems_strength = min(
                    1.0, rec.systems_strength + self._HIPPOCAMPAL_DECAY * strength_scale
                )
                # As memories become neocortical, retention stabilises
                # (remote memories are more resistant to forgetting).
                rec.retention = min(1.0, rec.retention + 0.02 * strength_scale)
        # Experience replay: sample old memories by inverse recency
        # and replay them to prevent catastrophic forgetting.
        processed += self._replay_old_memories(recent_cutoff, replayed_ids)
        # Replay the selected episode texts into the semantic graph.
        for eid in replayed_ids:
            self._replay_into_semantic_graph(eid)
        return processed

    def _replay_old_memories(
        self,
        recent_cutoff: int,
        replayed_ids: list[int] | None = None,
    ) -> int:
        """Replay old memories during NREM sleep to prevent catastrophic forgetting.

        Experience replay (Kirkpatrick et al., 2017; McClelland et al.,
        1995): during slow-wave sleep, the hippocampus replays old
        memories interleaved with new ones, preventing new learning
        from overwriting old knowledge. Without this, continual
        learning causes catastrophic forgetting — early knowledge
        degrades as new domains are learned.

        Old memories are sampled with probability proportional to
        inverse recency (older = more likely to be replayed) and
        inverse access count (rarely accessed = more likely, since
        they are more vulnerable to forgetting). Recent memories
        (already replayed above) are excluded from the sample.

        Returns the number of old memories replayed.
        """
        # Collect candidate memories: non-forgotten, not recently
        # encoded (older than the recent cutoff).
        candidates: list[MemoryRecord] = []
        for rec in list(self._records.values()):
            if rec.forgotten or rec.encoded_at >= recent_cutoff:
                continue
            candidates.append(rec)

        if not candidates:
            return 0

        # Compute sampling weights: inverse recency × inverse access.
        # Older, rarely-accessed memories get higher weights.
        now_ms = int(time.time() * 1000)
        weights: list[float] = []
        for rec in candidates:
            age_s = max(1.0, (now_ms - rec.encoded_at) / 1000.0)
            access_factor = 1.0 / max(1, rec.access_count)
            # Weight = age (in seconds) × inverse access count.
            # Normalized later by random.choices.
            weights.append(age_s * access_factor)

        # Sample without replacement (a memory is replayed at most once
        # per N3 cycle). Use random.choices for weighted sampling, then
        # deduplicate.
        sample_size = min(self._REPLAY_SAMPLE_SIZE, len(candidates))
        indices = list(range(len(candidates)))
        chosen: set[int] = set()
        # Weighted sampling without replacement: repeatedly pick the
        # highest-weighted candidate with some randomness.
        for _ in range(sample_size):
            if not indices:
                break
            pick = self._rng.choices(indices, weights=[weights[i] for i in indices], k=1)[0]
            chosen.add(pick)
            indices.remove(pick)

        replayed = 0
        for idx in chosen:
            rec = candidates[idx]
            # Replay strengthens the trace (less than recent replay).
            rec.synaptic_strength = min(1.0, rec.synaptic_strength + self._REPLAY_STRENGTHENING)
            rec.retention = min(1.0, rec.retention + self._REPLAY_STRENGTHENING * 0.5)
            # Replay counts as a weak access — keeps the memory "alive".
            rec.last_accessed = now_ms
            if replayed_ids is not None:
                replayed_ids.append(rec.episode_id)
            replayed += 1
        return replayed

    def _consolidate_n2(self, strength_scale: float = 1.0) -> int:
        """N2: sleep spindles drive hippocampal→neocortical transfer."""
        processed = 0
        replayed = 0
        for rec in list(self._records.values()):
            if rec.forgotten:
                continue
            if rec.hippocampal_dependency > 0.0:
                rec.hippocampal_dependency = max(
                    0.0,
                    rec.hippocampal_dependency - self._HIPPOCAMPAL_DECAY * 0.7 * strength_scale,
                )
                rec.systems_strength = min(
                    1.0,
                    rec.systems_strength + self._HIPPOCAMPAL_DECAY * 0.7 * strength_scale,
                )
                # N2 is the main transfer stage — replay a sample of
                # episodes into the semantic graph.
                if replayed < self._REPLAY_SAMPLE_SIZE:
                    self._replay_into_semantic_graph(rec.episode_id)
                    replayed += 1
                processed += 1
        return processed

    def _consolidate_rem(self, recent_cutoff: int, strength_scale: float = 1.0) -> int:
        """REM: consolidate emotional and procedural memories."""
        processed = 0
        replayed = 0
        # Emotional memories are identified by high emotional
        # variance in the tag.
        for rec in list(self._records.values()):
            if rec.forgotten:
                continue
            emotional_intensity = _emotional_intensity(rec.emotional_tag)
            if emotional_intensity > 0.6 or rec.encoded_at >= recent_cutoff:
                # Emotional memories get extra consolidation.
                rec.synaptic_strength = min(
                    1.0, rec.synaptic_strength + 0.08 * emotional_intensity * strength_scale
                )
                rec.retention = min(
                    1.0,
                    rec.retention + 0.05 * emotional_intensity * strength_scale,
                )
                # Replay emotional / recent memories into the semantic graph.
                if replayed < self._REPLAY_SAMPLE_SIZE:
                    self._replay_into_semantic_graph(rec.episode_id)
                    replayed += 1
                processed += 1
        # Fear extinction: REM sleep processes conditioned fear
        # associations without the aversive stimulus, weakening
        # them (extinction learning). This is why sleep helps with
        # PTSD and anxiety — the amygdala reprocesses fear memories
        # in a safe context.
        for stimulus in list(self.emotional_memory._memories.keys()):
            memory = self.emotional_memory._memories[stimulus]
            if not memory.is_extinct and memory.association_strength > 0.1:
                self.emotional_memory.extinction_learning(stimulus, exposures=1)
        return processed

    def _consolidate_n1(self, recent_cutoff: int, strength_scale: float = 1.0) -> int:
        """N1: the lightest stage — minor replay."""
        processed = 0
        replayed = 0
        for rec in list(self._records.values()):
            if rec.forgotten or rec.encoded_at < recent_cutoff:
                continue
            rec.synaptic_strength = min(1.0, rec.synaptic_strength + 0.03 * strength_scale)
            # Replay a few recent memories into the semantic graph.
            if replayed < self._REPLAY_SAMPLE_SIZE:
                self._replay_into_semantic_graph(rec.episode_id)
                replayed += 1
            processed += 1
        return processed

    # ═══════════════════════════════════════════════════════════════
    #  Item 2: Forgetting mechanisms
    # ═══════════════════════════════════════════════════════════════

    def forget(self, now: float | None = None) -> int:
        """Apply forgetting mechanisms to all memory records.

        Implements multiple forgetting mechanisms:

        1. **Time-based decay (Ebbinghaus)**: retention = e^(-t/tau),
           where tau is scaled by salience (more salient memories
           decay more slowly). This is the classic forgetting curve.
        2. **Proactive interference**: old memories interfere with
           new ones — memories encoded close together compete, and
           older ones slightly reduce newer ones' retention.
        3. **Retroactive interference**: new memories interfere with
           old ones — newer memories slightly reduce older ones'
           retention.
        4. **Retrieval failure**: a memory exists but can't be
           accessed — modelled as a probabilistic access gate based
           on how long since last access.
        5. **Adaptive forgetting**: low-relevance (low salience +
           low access count) memories are forgotten to make room.

        Memories whose retention drops below the threshold are marked
        forgotten. The method returns the number newly forgotten.

        Args:
            now: Optional current time (seconds). Defaults to
                ``time.time()``.

        Returns:
            Number of memories newly forgotten in this pass.
        """
        if now is None:
            now = time.time()
        now_ms = int(now * 1000)
        newly_forgotten = 0

        # Sort records by encoded_at for interference calculations.
        sorted_records = sorted(
            (r for r in list(self._records.values()) if not r.forgotten),
            key=lambda r: r.encoded_at,
        )
        # Parallel array of the sort key, for bisect-based windowing.
        encoded_times = [r.encoded_at for r in sorted_records]

        for idx, rec in enumerate(sorted_records):
            if self._apply_forgetting_to_record(rec, idx, encoded_times, now_ms):
                newly_forgotten += 1

        self.forgotten_count += newly_forgotten
        self._evict_forgotten_records(now_ms)
        return newly_forgotten

    def _evict_forgotten_records(self, now_ms: int) -> int:
        """Drop forgotten records so ``_records`` stops growing forever.

        Nothing reads a forgotten record: every consolidation stage,
        replay, and retrieval path already skips ``rec.forgotten``. They
        were being retained anyway, which meant the dict — and the JSON
        written from it on every autosave — grew without bound for the
        life of the instance. On a months-long run that is the single
        largest source of unbounded growth, and unbounded growth is what
        eventually fills the disk and kills the process.

        A forgotten record is kept for a short grace period so that a
        record which crosses the threshold this pass is not also
        deleted in the same pass; that keeps the transition inspectable
        and stops a single pass from deleting a large batch.
        """
        cutoff = now_ms - self._FORGOTTEN_EVICTION_GRACE_MS
        evictable = [
            eid
            for eid, rec in list(self._records.items())
            if rec.forgotten and rec.encoded_at < cutoff
        ]
        if not evictable:
            return 0
        for eid in evictable:
            self._records.pop(eid, None)
        return len(evictable)

    def engram_drive(
        self,
        episode_id: int,
        *,
        encoded_ms: int,
        salience: float,
        arousal: float,
        cortical_strength: float | None = None,
        now_ms: int | None = None,
    ) -> float:
        """Retrieval-path drive of one engram, in log units.

        B = ln(Σ_j t_j^(−d)) + w_sal·salience + w_aro·arousal
                              − w_cort·cortical_strength

        - ``Σ_j t_j^(−d)`` — each reactivation re-potentiates the
          engram's retrieval path (reconsolidation rebuilds spine
          density; Ryan & Tonegawa 2017), then decays as a power law
          (Wixted & Ebbesen 1991 — retention is t^(−c), not e^(−t/τ)).
          Uses are assumed evenly spaced between encoding and last
          access; with d=0.5 the sum has the closed form
          ``2n/(√a_enc + √a_last)`` (the merged base-level of ACT-R,
          Anderson & Schooler 1991). The record's own access history
          is authoritative; episodes with no record are a single use
          at encoding.
        - depth terms — amygdala/NE modulation at write time
          (McGaugh 2000). When a record exists its salience and tag
          are used (reconsolidation may have rewritten them); the
          wire values are the fallback.
        - ``cortical_strength`` — systems consolidation already
          shipped the content to neocortex, so the hippocampal copy
          is redundant. From the record when present, else the
          caller's estimate (the compressor extracted the gist at
          archive time).
        """
        if now_ms is None:
            now_ms = int(time.time() * 1000)
        ms_per_day = 86_400_000.0
        floor = self._RELEASE_MIN_AGE_DAYS
        a_enc = max((now_ms - encoded_ms) / ms_per_day, floor)

        rec = self._records.get(episode_id)
        n = 1 + (rec.access_count if rec is not None else 0)
        if rec is not None and rec.last_accessed > 0:
            a_last = max((now_ms - rec.last_accessed) / ms_per_day, floor)
        else:
            a_last = a_enc
        if rec is not None and rec.last_reconsolidated > 0:
            a_last = min(a_last, max((now_ms - rec.last_reconsolidated) / ms_per_day, floor))

        react_sum = 2.0 * n / (math.sqrt(a_enc) + math.sqrt(a_last))
        drive = math.log(react_sum)
        drive += self._RELEASE_SALIENCE_W * (rec.salience if rec is not None else salience)
        drive += self._RELEASE_AROUSAL_W * (
            _emotional_intensity(rec.emotional_tag) if rec is not None else arousal
        )
        drive -= self._RELEASE_CORTICAL_W * (
            rec.systems_strength if rec is not None else (cortical_strength or 0.0)
        )
        return drive

    def should_release(
        self,
        episode_id: int,
        *,
        encoded_ms: int,
        salience: float,
        arousal: float,
        cortical_strength: float | None = None,
        now_ms: int | None = None,
    ) -> bool:
        """Whether this engram is substrate-dead — her forgetting.

        True when the drive falls under the release threshold: spine
        density on the ensemble is below what any natural cue could
        re-drive, so the connectivity is effectively gone. With no
        reactivations and zero depth/redundancy terms the lifetime
        solves to ~55 days — close to the measured ~3–6 week full
        CA1 spine turnover (Attardo et al. 2015); the model's natural
        forgetting timescale is the biological one.

        Eligibility — meta-memories, dreams, recency grace — is the
        caller's policy; this is only the retention verdict.
        """
        return (
            self.engram_drive(
                episode_id,
                encoded_ms=encoded_ms,
                salience=salience,
                arousal=arousal,
                cortical_strength=cortical_strength,
                now_ms=now_ms,
            )
            < self._RELEASE_THRESHOLD
        )

    def release_verdict(self, entry: object) -> bool:
        """Compressor-facing form of :meth:`should_release`.

        Takes an ``ArchivedEpisode`` wire entry (id, timestamp,
        salience, flags, source, 4-chemical tag — no payload) and
        unpacks what the model needs. The daemon's compact tag leads
        with arousal (``[arousal, valence, cortisol, dopamine]`` in
        ``IndexEntry.emotional_tag``); archiving already extracted
        the gist into the holographic graph, so record-less entries
        carry moderate cortical redundancy.
        """
        tag = getattr(entry, "emotional_tag", None)
        return self.should_release(
            entry.episode_id,  # type: ignore[attr-defined]
            encoded_ms=getattr(entry, "timestamp", 0),
            salience=getattr(entry, "salience", 0.0),
            arousal=float(tag[0]) if tag else 0.0,
            cortical_strength=self._ARCHIVED_GIST_CORTICAL,
        )

    def _apply_forgetting_to_record(
        self,
        rec: MemoryRecord,
        idx: int,
        encoded_times: list[int],
        now_ms: int,
    ) -> bool:
        """Apply all forgetting mechanisms to a single record.

        Returns True if the record was newly marked forgotten.

        All penalties are computed from first principles (time and fixed
        properties) each call, then combined into a target retention.
        The stored retention is capped by this target via ``min``, making
        the function idempotent: calling ``forget()`` twice with the same
        timestamp produces the same result. This prevents forgetting from
        depending on how often ``forget()`` is called rather than on
        elapsed time.
        """
        # ── 1. Ebbinghaus decay ───────────────────────────────
        age_s = max(0.0, (now_ms - rec.encoded_at) / 1000.0)
        # Salience scales tau: salient memories decay slower.
        salience_factor = 0.3 + rec.salience  # 0.3..1.3
        tau = self._FORGETTING_TAU * salience_factor
        decayed = math.exp(-age_s / tau)

        # ── 2. Proactive + retroactive interference ────────────
        # Older memories encoded close in time interfere with this
        # one (proactive); newer memories interfere with this older
        # one (retroactive). The total interference is a subtractive
        # penalty computed from the fixed encoding times of nearby
        # memories, so it is the same on every call (idempotent).
        #
        # The caller passes `encoded_times` — the records' `encoded_at`
        # values, already sorted — so every record within the 1-hour
        # interference window is a *contiguous* range around `idx`.
        # Bisecting for that range and summing in place replaces what
        # used to be two full list slices per record, which made this
        # loop O(N^2) in both time and transient allocation, and it
        # runs on the autosave/think threads while holding the GIL. At
        # 10k episodes that is ~10^8 element copies; at 50k it stalls
        # the process for minutes. Now O(N log N) to sort, O(N) total
        # to score, allocation-free per record. Verified equivalent to
        # the previous sum over 3000 randomised datasets including
        # duplicate and boundary timestamps.
        total_interference = 0.0
        lo = bisect.bisect_left(encoded_times, rec.encoded_at - _INTERFERENCE_WINDOW_S)
        hi = bisect.bisect_right(encoded_times, rec.encoded_at + _INTERFERENCE_WINDOW_S)
        for j in range(lo, hi):
            if j == idx:
                continue
            other_t = encoded_times[j]
            time_gap = abs(other_t - rec.encoded_at) / 1000.0
            # Closer in time → more interference. Records encoded at
            # exactly the same millisecond as this one are skipped:
            # the original `0 < time_gap` guard excluded them.
            if 0.0 < time_gap < _INTERFERENCE_WINDOW_S:
                total_interference += 0.02 * (1.0 - time_gap / _INTERFERENCE_WINDOW_S)

        # ── 3. Retrieval failure ─────────────────────────────
        # The longer since last access, the more likely retrieval
        # fails (the memory exists but can't be accessed). This is a
        # time-based multiplicative factor, not a per-call penalty.
        since_access_s = max(0.0, (now_ms - rec.last_accessed) / 1000.0)
        # Retrieval probability decays with disuse.
        retrieval_prob = math.exp(-since_access_s / (tau * 2.0))
        retrieval_mult = 0.8 if retrieval_prob < 0.1 else 1.0

        # ── 4. Adaptive forgetting ───────────────────────────
        # Low-relevance memories (low salience + rarely accessed)
        # are forgotten to make room for new memories. This is a
        # property-based multiplicative factor, not a per-call penalty.
        adaptive_mult = 0.5 if (rec.salience < 0.2 and rec.access_count == 0) else 1.0

        # ── Combine: target retention from first principles ───
        # All penalties are applied to the Ebbinghaus decayed value,
        # producing a target that depends only on time and fixed
        # properties. The stored retention is capped by this target,
        # ensuring monotonic decay (retention can only decrease)
        # while making the function idempotent.
        target = max(0.0, decayed - total_interference) * retrieval_mult * adaptive_mult
        rec.retention = min(rec.retention, target)
        # Late-LTP floor (Frey & Morris): the committed, protein-
        # synthesis-dependent component survives Ebbinghaus decay —
        # capture during the tag window is what makes a trace last.
        rec.retention = max(rec.retention, rec.late_strength)

        # ── Mark forgotten if below threshold ────────────────
        if rec.retention < self.config.forgetting_threshold:
            rec.forgotten = True
            return True
        return False

    # ═══════════════════════════════════════════════════════════════
    #  Item 3: Reconsolidation mechanism
    # ═══════════════════════════════════════════════════════════════

    def reconsolidate(
        self,
        memory_id: int,
        modification: ReconsolidationModification,
    ) -> bool:
        """Reconsolidate a recalled memory with the given modification.

        When a memory is recalled with prediction error, it becomes
        labile (modifiable) for a brief window (~6 hours in humans).
        During this window the memory can be strengthened, weakened,
        or emotionally re-tagged. The current emotional state during
        reconsolidation affects the memory's emotional tag (emotional
        modulation).

        Boundary condition: the reconsolidation window only opens when
        prediction error exceeds the threshold (Schiller et al., 2010;
        Sevenster et al., 2014). Recall without prediction error
        strengthens the memory via retrieval practice but does not make
        it labile. If the window was never opened (or has closed), the
        modification is not applied and the method returns ``False``.

        Args:
            memory_id: The episode ID of the memory to reconsolidate.
            modification: The modification to apply (strength delta
                and/or emotional re-tagging).

        Returns:
            ``True`` if the modification was applied, ``False`` if the
            memory was not found, already forgotten, or no longer in
            the reconsolidation window.
        """
        rec = self._records.get(memory_id)
        if rec is None or rec.forgotten:
            return False
        if rec.reconsolidation_window <= 0:
            # Window has closed — memory is no longer labile.
            return False

        # Apply strength modification (strengthen or weaken).
        rec.salience = max(0.0, min(1.0, rec.salience + modification.strength_delta))
        rec.retention = max(0.0, min(1.0, rec.retention + modification.strength_delta))
        rec.synaptic_strength = max(
            0.0,
            min(1.0, rec.synaptic_strength + modification.strength_delta),
        )

        # Emotional modulation: blend the current emotional state
        # into the memory's emotional tag.
        if modification.emotional_tag is not None:
            blend = max(0.0, min(1.0, modification.blend_factor))
            for i in range(min(len(rec.emotional_tag), len(modification.emotional_tag))):
                rec.emotional_tag[i] = max(
                    0.0,
                    min(
                        1.0,
                        rec.emotional_tag[i] * (1.0 - blend)
                        + modification.emotional_tag[i] * blend,
                    ),
                )

        # Reconsolidation re-destabilizes the synapse — the re-stored
        # trace carries a fresh tag, so a dopaminergic event inside
        # the new window can re-commit it at the modified strength.
        rec.tag_strength = max(rec.tag_strength, rec.salience)
        # Close the reconsolidation window (memory is re-stored).
        rec.reconsolidation_window = 0.0
        rec.last_reconsolidated = int(time.time() * 1000)
        rec.reconsolidation_count += 1
        self.reconsolidation_count += 1
        return True

    def tick_reconsolidation(self, dt: float) -> None:
        """Advance reconsolidation windows by ``dt`` seconds.

        Should be called periodically to close reconsolidation windows
        as time passes.

        Args:
            dt: Elapsed time in seconds.
        """
        for rec in list(self._records.values()):
            if rec.reconsolidation_window > 0:
                rec.reconsolidation_window = max(0.0, rec.reconsolidation_window - dt)

    def tick_tags(self, dt: float, dopamine: float = 0.0, norepinephrine: float = 0.0) -> int:
        """Advance synaptic tags and run modulator-gated capture.

        Two coupled processes (Frey & Morris, 1997; Clopath et al.,
        2008; Redondo & Morris, 2011):

        1. **Tag decay**: every open synaptic tag decays
           ``tag *= exp(-dt / _TAG_TAU_S)`` — the early-LTP window
           closes on the ~hour scale. A tag that decays uncaptured
           leaves the trace to normal forgetting.
        2. **Capture**: while the effective dopamine level is above
           ``_CAPTURE_DA_THRESHOLD`` (a phasic event, not tonic) —
           or noradrenaline is above ``_CAPTURE_NE_THRESHOLD`` (the
           β-adrenergic amygdala path: emotional arousal commits
           with no reward event) — every open tag draws from the
           shared protein pool and converts a fraction of itself to
           ``late_strength``, the committed late-LTP floor. The pool
           is finite, so a strong modulatory event rescues *all*
           memories tagged in the window but cannot commit the whole
           world: salient (strongly tagged) traces win the pool
           first.

        Args:
            dt: Elapsed time in seconds.
            dopamine: The body's current effective dopamine level
                [0, 1]. Below the capture threshold only decay runs.
            norepinephrine: The body's effective noradrenaline level
                [0, 1] — the emotional-arousal co-gate.

        Returns:
            Number of tags that captured protein this call.
        """
        decay = math.exp(-max(0.0, dt) / self._TAG_TAU_S)
        gate_open = (
            dopamine >= self._CAPTURE_DA_THRESHOLD or norepinephrine >= self._CAPTURE_NE_THRESHOLD
        )
        capturing = gate_open and self._protein_pool > 0.0
        captured = 0
        for rec in list(self._records.values()):
            if rec.tag_strength <= 0.0:
                continue
            rec.tag_strength *= decay
            if rec.tag_strength < self._TAG_EPSILON:
                rec.tag_strength = 0.0
                continue
            if capturing:
                want = rec.tag_strength * self._CAPTURE_GAIN
                take = min(want, self._protein_pool)
                if take <= 0.0:
                    break  # pool exhausted — stronger tags captured first
                rec.tag_strength -= take
                rec.late_strength = min(1.0, rec.late_strength + take)
                self._protein_pool -= take
                captured += 1
        self.tag_capture_count += captured
        return captured

    # ═══════════════════════════════════════════════════════════════
    #  Source monitoring (Johnson et al., 1993)
    # ═══════════════════════════════════════════════════════════════

    def monitor_source(self, memory_id: int, actual_source: str) -> bool:
        """Check whether a memory's source tag matches the actual source.

        Source monitoring errors — mistaking the origin of a memory —
        are the basis of false memories and confabulation (Johnson et
        al., 1993). This method compares the stored source attribution
        against the ground truth, weighted by the source tag's
        confidence. Low-confidence source tags are more likely to
        produce monitoring errors.

        Args:
            memory_id: The episode ID to check.
            actual_source: The true source of the memory.

        Returns:
            ``True`` if the source attribution is correct, ``False``
            if the memory was not found, has no source tag, or the
            attribution is wrong.
        """
        rec = self._records.get(memory_id)
        if rec is None or rec.source_tag is None:
            return False
        return rec.source_tag.source == actual_source

    def check_confabulation_risk(self, memory_id: int) -> float:
        """Assess the risk that a memory is confabulated.

        Confabulation risk is high when:
        - The source is "inference" or "imagination" (internally
          generated rather than observed)
        - Source confidence is low (uncertain origin)
        - The memory has been reconsolidated many times (each
          reconsolidation can drift the content)

        Returns a risk score [0..1] where 0 = no risk (the memory is
        clearly from an external source with high confidence) and
        1 = high risk (the memory is internally generated with low
        confidence and has been reconsolidated repeatedly).
        """
        rec = self._records.get(memory_id)
        if rec is None or rec.source_tag is None:
            return 0.5  # Unknown — moderate risk

        risk = 0.0
        # Internally-generated sources carry inherent confabulation risk
        if rec.source_tag.source in ("inference", "imagination"):
            risk += 0.4
        elif rec.source_tag.source == "genesis":
            risk += 0.2
        # Low source confidence increases risk
        risk += (1.0 - rec.source_tag.confidence) * 0.3
        # Repeated reconsolidation can drift content
        if rec.reconsolidation_count > 5:
            risk += 0.1 * min(1.0, rec.reconsolidation_count / 10.0)
        return min(1.0, risk)

    def get_memories_by_source(self, source: str) -> list[int]:
        """Return episode IDs for all non-forgotten memories from a
        given source.

        Useful for introspection ("what did I learn from docs vs
        conversation vs inference?") and for source-based retrieval
        filtering.
        """
        return [
            rec.episode_id
            for rec in list(self._records.values())
            if not rec.forgotten and rec.source_tag is not None and rec.source_tag.source == source
        ]

    def source_summary(self) -> dict[str, int]:
        """Return a count of memories per source category.

        Useful for introspection and metacognitive awareness of where
        knowledge came from.
        """
        counts: dict[str, int] = {}
        for rec in list(self._records.values()):
            if rec.forgotten:
                continue
            src = rec.source_tag.source if rec.source_tag else "unknown"
            counts[src] = counts.get(src, 0) + 1
        return counts

    # ═══════════════════════════════════════════════════════════════
    #  Items 4 & 5: Systems consolidation & synaptic consolidation
    # ═══════════════════════════════════════════════════════════════

    def synaptic_consolidate(self, memory_id: int) -> bool:
        """Apply fast synaptic consolidation to a recently-encoded memory.

        Synaptic consolidation is the fast (minutes-hours) LTP-like
        strengthening that stabilises a memory trace immediately after
        encoding. This is distinct from systems consolidation (the
        slow hippocampal→neocortical redistribution over days-weeks).

        This boosts the memory's synaptic strength and retention,
        modelling the protein-synthesis-dependent late phase of LTP
        (Kandel, 2001).

        Args:
            memory_id: The episode ID to consolidate.

        Returns:
            ``True`` if applied, ``False`` if the memory was not found.
        """
        rec = self._records.get(memory_id)
        if rec is None or rec.forgotten:
            return False
        rec.synaptic_strength = min(1.0, rec.synaptic_strength + self._SYNAPTIC_BOOST)
        rec.retention = min(1.0, rec.retention + 0.1)
        self.synaptic_consolidation_count += 1
        return True

    def systems_consolidate(self) -> int:
        """Redistribute memories from hippocampal to neocortical storage.

        Systems consolidation is the slow (days-weeks) process by
        which hippocampal-dependent memories gradually become
        independent of the hippocampus and stored in neocortex. This
        captures the temporal gradient of retrograde amnesia: recent
        memories (high hippocampal dependency) are impaired by
        hippocampal damage, but remote memories (low dependency) are
        spared (Squire & Alvarez, 1995; Frankland & Bontempi, 2005).

        Each call reduces the hippocampal dependency of all
        non-forgotten memories by a fixed fraction and correspondingly
        increases their neocortical (systems) strength. This is
        normally called during SWS (see :meth:`consolidate_during_sleep`)
        but can also be called independently to model time-based
        consolidation.

        Returns:
            Number of memories processed.
        """
        processed = 0
        for rec in list(self._records.values()):
            if rec.forgotten or rec.hippocampal_dependency <= 0.0:
                continue
            rec.hippocampal_dependency = max(
                0.0,
                rec.hippocampal_dependency - self._HIPPOCAMPAL_DECAY,
            )
            rec.systems_strength = min(1.0, rec.systems_strength + self._HIPPOCAMPAL_DECAY)
            # As memories become neocortical, retention stabilises
            # (remote memories are more resistant to forgetting).
            rec.retention = min(1.0, rec.retention + 0.02)
            processed += 1
        self.systems_consolidation_count += processed
        return processed

    # ── Introspection helpers ────────────────────────────────────

    def get_memory_record(self, episode_id: int) -> MemoryRecord | None:
        """Return the Python-side metadata record for an episode."""
        return self._records.get(episode_id)

    @property
    def tracked_memory_count(self) -> int:
        """Number of memories with Python-side consolidation metadata."""
        return len(self._records)

    @property
    def active_memory_count(self) -> int:
        """Number of non-forgotten tracked memories."""
        return sum(1 for r in list(self._records.values()) if not r.forgotten)

    # ── Persistence ──────────────────────────────────────────────

    def serialize_records(self) -> dict[str, Any]:
        """Serialize Python-side memory metadata for persistence.

        The Rust daemon persists the raw LTM episodes (text, emotional
        tags, salience). This serializes the Python-side consolidation
        state that the Rust store doesn't hold: hippocampal dependency,
        synaptic/systems strength, retention, forgetting state,
        reconsolidation windows, source tags, and access counts.

        Without this, every restart resets all biological memory
        processes — forgetting, reconsolidation, sleep consolidation,
        and source monitoring start from scratch.
        """
        return {
            "records": [
                {
                    "episode_id": rec.episode_id,
                    "salience": rec.salience,
                    "emotional_tag": list(rec.emotional_tag),
                    "encoded_at": rec.encoded_at,
                    "last_accessed": rec.last_accessed,
                    "access_count": rec.access_count,
                    "hippocampal_dependency": rec.hippocampal_dependency,
                    "synaptic_strength": rec.synaptic_strength,
                    "systems_strength": rec.systems_strength,
                    "retention": rec.retention,
                    "forgotten": rec.forgotten,
                    "reconsolidation_window": rec.reconsolidation_window,
                    "last_reconsolidated": rec.last_reconsolidated,
                    "reconsolidation_count": rec.reconsolidation_count,
                    "source": rec.source_tag.source if rec.source_tag else None,
                    "source_modality": rec.source_tag.modality if rec.source_tag else "text",
                    "source_confidence": rec.source_tag.confidence if rec.source_tag else 0.8,
                    "somatic": dict(rec.somatic) if rec.somatic else None,
                    "tag_strength": rec.tag_strength,
                    "late_strength": rec.late_strength,
                }
                for rec in _snapshot(self._records.values)
            ],
            "protein_pool": self._protein_pool,
            "tag_capture_count": self.tag_capture_count,
            "forgotten_count": self.forgotten_count,
            "reconsolidation_count": self.reconsolidation_count,
            "synaptic_consolidation_count": self.synaptic_consolidation_count,
            "systems_consolidation_count": self.systems_consolidation_count,
            "sleep_consolidation_count": self.sleep_consolidation_count,
            "facts_replayed_count": self.facts_replayed_count,
        }

    def restore_records(self, data: dict[str, Any]) -> None:
        """Restore Python-side memory metadata from persisted state.

        Rebuilds the ``_records`` dict and consolidation counters from
        a previously serialized state (see :meth:`serialize_records`).
        Called on startup after the LTM store is available.
        """
        self._records.clear()
        for entry in data.get("records", []):
            try:
                eid = int(entry["episode_id"])
            except (KeyError, TypeError, ValueError):
                continue
            source = entry.get("source")
            source_tag = None
            if source is not None:
                source_tag = SourceTag(
                    source=source if source in VALID_SOURCES else "unknown",
                    modality=entry.get("source_modality", "text"),
                    confidence=max(0.0, min(1.0, float(entry.get("source_confidence", 0.8)))),
                )
            rec = MemoryRecord(
                episode_id=eid,
                salience=float(entry.get("salience", 0.5)),
                emotional_tag=list(entry.get("emotional_tag", [0.5] * EMOTIONAL_TAG_SIZE)),
                encoded_at=int(entry.get("encoded_at", 0)),
                last_accessed=int(entry.get("last_accessed", 0)),
                access_count=int(entry.get("access_count", 0)),
                hippocampal_dependency=float(entry.get("hippocampal_dependency", 1.0)),
                synaptic_strength=float(entry.get("synaptic_strength", 0.3)),
                systems_strength=float(entry.get("systems_strength", 0.0)),
                retention=float(entry.get("retention", 1.0)),
                forgotten=bool(entry.get("forgotten", False)),
                reconsolidation_window=float(entry.get("reconsolidation_window", 0.0)),
                last_reconsolidated=int(entry.get("last_reconsolidated", 0)),
                reconsolidation_count=int(entry.get("reconsolidation_count", 0)),
                source_tag=source_tag,
                somatic=(
                    {k: float(v) for k, v in entry["somatic"].items()}
                    if isinstance(entry.get("somatic"), dict)
                    else None
                ),
                tag_strength=float(entry.get("tag_strength", 0.0)),
                late_strength=float(entry.get("late_strength", 0.0)),
            )
            self._records[eid] = rec
        self._protein_pool = max(
            0.0,
            min(
                self._PROTEIN_POOL_CAP,
                float(data.get("protein_pool", self._PROTEIN_POOL_CAP)),
            ),
        )
        self.tag_capture_count = int(data.get("tag_capture_count", 0))
        self.forgotten_count = int(data.get("forgotten_count", 0))
        self.reconsolidation_count = int(data.get("reconsolidation_count", 0))
        self.synaptic_consolidation_count = int(data.get("synaptic_consolidation_count", 0))
        self.systems_consolidation_count = int(data.get("systems_consolidation_count", 0))
        self.sleep_consolidation_count = int(data.get("sleep_consolidation_count", 0))
        self.facts_replayed_count = int(data.get("facts_replayed_count", 0))


def _emotional_intensity(tag: list[float]) -> float:
    """Compute emotional intensity from an emotional tag.

    High variance and high arousal chemicals (cortisol, noradrenaline,
    dopamine) indicate an emotionally intense memory.
    """
    if not tag:
        return 0.0
    mean = sum(tag) / len(tag)
    variance = sum((x - mean) ** 2 for x in tag) / len(tag)
    # Arousal chemicals: DA (idx 0), NE (idx 2), cortisol (idx 6).
    arousal_chems = [tag[i] for i in (0, 2, 6) if i < len(tag)]
    arousal = sum(arousal_chems) / max(1, len(arousal_chems))
    return min(1.0, 0.5 * arousal + 0.5 * min(1.0, variance * 4.0))


def _finite_clamp(value: float, lo: float, hi: float, *, default: float = 0.5) -> float:
    """Clamp a float to [lo, hi], replacing NaN/Inf with a default.

    Mirrors the Rust daemon's ``finite_clamp``: non-finite values
    (NaN, +Inf, -Inf) are replaced by ``default`` before clamping to
    the range. This prevents NaN from propagating through the
    forgetting and consolidation formulas.
    """
    if math.isnan(value) or math.isinf(value):
        return max(lo, min(hi, default))
    return max(lo, min(hi, value))


def _emotional_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two emotional vectors (mood congruence)."""
    n = min(len(a), len(b))
    if n == 0:
        return 0.0
    dot = sum(a[i] * b[i] for i in range(n))
    na = math.sqrt(sum(a[i] * a[i] for i in range(n)))
    nb = math.sqrt(sum(b[i] * b[i] for i in range(n)))
    if na < 1e-9 or nb < 1e-9:
        return 0.0
    return max(0.0, min(1.0, dot / (na * nb)))


def _text_to_vector(text: str, size: int = 64) -> list[float]:
    """Deterministically map text to a fixed-size feature vector.

    Used to feed memories/queries into the attractor network for
    pattern completion. Each character hashes to a bucket; the bucket
    is set to 1.0 (bipolar +1 after the network's internal
    conversion). This gives a stable, content-addressable fingerprint
    so similar texts produce similar (overlapping) vectors.
    """
    vector = [0.0] * size
    if not text:
        return vector
    for ch in text.lower():
        h = int(hashlib.md5(ch.encode("utf-8")).hexdigest(), 16)
        vector[h % size] = 1.0
    return vector


def _extract_concepts(text: str) -> list[str]:
    """Extract candidate concepts from a text string.

    A lightweight, dependency-free tokeniser: splits on
    whitespace/punctuation and keeps alphabetic tokens of length ≥ 3,
    deduplicated while preserving order. These concepts are fed to
    priming and spreading activation.
    """
    if not text:
        return []
    seen: set[str] = set()
    concepts: list[str] = []
    current: list[str] = []
    for ch in text:
        if ch.isalnum():
            current.append(ch)
        else:
            if current:
                token = "".join(current)
                current = []
                _maybe_add(token, seen, concepts)
    if current:
        _maybe_add("".join(current), seen, concepts)
    return concepts


def _maybe_add(token: str, seen: set[str], concepts: list[str]) -> None:
    """Add a token to the concept list if it qualifies."""
    if len(token) < 3:
        return
    if not token.isalpha():
        return
    key = token.lower()
    if key in seen:
        return
    seen.add(key)
    concepts.append(key)


def _primary_concept(text: str) -> str:
    """Return the primary concept (first qualifying token) from text.

    Used as the stimulus key for emotional-memory tagging.
    """
    concepts = _extract_concepts(text)
    return concepts[0] if concepts else ""

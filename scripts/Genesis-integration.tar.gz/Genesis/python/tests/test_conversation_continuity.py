"""Conversation continuity — fast routes must stay part of the dialogue.

The most common exchanges (factual questions, follow-ups, answers to
Genesis's own questions) take the early metacognitive route, which
used to return before the store/track stage: the turn never entered
working memory, the conversation history, or long-term memory. The
next turn then had no referent for "it"/"that" and the exchange was
invisible to recall — a break in conversational continuity, not just
bookkeeping.

These tests exercise the real engine path offline (no daemon): an
early-route exchange must land in working memory and the conversation
record exactly once, and a follow-up question routed through "it"
must resolve to the previous turn's focus.
"""

import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
from frontal_lobe.generator import GenerativeLanguage
from frontal_lobe.prefrontal import FrontalLobe
from occipital_lobe.perception import perceive
from self import SelfModel
from temporal_lobe.concepts import ConceptNetwork, RelationType

from genesis_client import GenesisClient
from infrastructure.user_profile import UserProfile
from memory import MemorySystem


@pytest.fixture
def engine():
    """A real cognition engine — offline (no daemon socket)."""
    data_dir = tempfile.mkdtemp()
    client = GenesisClient(os.path.join(data_dir, "genesis.sock"))
    self_model = SelfModel()
    network = ConceptNetwork()
    memory = MemorySystem(client, network=network, get_emotion=lambda: None)
    language = GenerativeLanguage(self_model, seed=1, network=network)
    eng = FrontalLobe(
        client=client,
        self_model=self_model,
        memory=memory,
        language=language,
        network=network,
        data_dir=data_dir,
        user_profile=UserProfile(),
    )
    return eng, network, memory


def test_fast_factual_route_records_the_turn(engine):
    """'What is a quoll?' takes the early route — and still counts as a turn."""
    eng, network, memory = engine
    network.add_concept("quoll", confidence=0.8)

    early = eng._think_early_routes("what is a quoll?", perceive("what is a quoll?"))
    assert early is not None
    response, _state = early

    # Working memory carries the exchange — referent focus for a later
    # "it"/"that", and a recent turn for thread tracking.
    last = eng.working_memory.get_last_turn()
    assert last is not None
    assert last.user_input == "what is a quoll?"
    assert last.genesis_response == response
    focus = eng.working_memory.central_executive.focus_history
    assert "quoll" in focus

    # Conversation history carries both sides, exactly once each.
    roles = [t.role for t in memory.conversation]
    assert roles == ["user", "genesis"]
    assert memory.conversation[0].text == "what is a quoll?"
    assert memory.conversation[1].text == response


def test_pending_question_answer_records_the_turn(engine):
    """Answering a curiosity question early-routes — and is remembered."""
    eng, _network, memory = engine
    eng._pending_question_concepts["wug"] = "what is a wug?"

    early = eng._think_early_routes("a wug is a small bird", perceive("a wug is a small bird"))
    assert early is not None

    last = eng.working_memory.get_last_turn()
    assert last is not None
    assert last.user_input == "a wug is a small bird"
    assert [t.role for t in memory.conversation] == ["user", "genesis"]


def test_followup_pronoun_answers_about_the_previous_focus(engine):
    """'What does it eat?' after 'What is a quoll?' — 'it' binds to quoll.

    Both repairs must chain: the first fast-route turn must be recorded
    (so "it" has a referent), and the routed consumes target must be
    referent-resolved (so the composer looks up "quoll", not "it").
    """
    eng, network, memory = engine
    network.add_concept("quoll", confidence=0.8)
    network.add_concept("insects", confidence=0.8)
    network.add_edge("quoll", "insects", RelationType.DEPENDS_ON, 0.9)

    first = eng._think_early_routes("what is a quoll?", perceive("what is a quoll?"))
    assert first is not None

    # Turn 2 — run the real anaphora stage, then the early router with
    # the raw words (as think() does).
    raw = "what does it eat?"
    resolved = eng._resolve_anaphora(raw)
    early = eng._think_early_routes(resolved, perceive(raw), raw_input=raw)
    assert early is not None
    _response, state = early

    # The composer answered about quoll — the resolved referent —
    # reaching its depends_on edge to insects.
    knowledge = state.thought.metadata.get("knowledge") or []
    assert any("insect" in str(target) for _rel, target, _w in knowledge)

    # The follow-up turn is also recorded — the conversation now holds
    # both exchanges.
    roles = [t.role for t in memory.conversation]
    assert roles == ["user", "genesis", "user", "genesis"]
    last = eng.working_memory.get_last_turn()
    assert last is not None
    assert last.user_input == resolved


def test_plural_target_resolves_to_the_stored_concept(engine):
    """'Tell me about animals' must reach the 'animal' concept.

    The router captures the literal phrase; without variant resolution
    the composer looks up "animals", misses the stored "animal"
    concept, and answers with uncertainty about a known thing.
    """
    eng, network, _memory = engine
    network.add_concept("animal", confidence=0.8)
    network.add_concept("cat", confidence=0.8)
    network.add_edge("animal", "cat", RelationType.RELATED_TO, 0.9)

    early = eng._think_early_routes("tell me about animals", perceive("tell me about animals"))
    assert early is not None
    _response, state = early
    # The routed target normalized to the stored singular concept.
    assert "animal" in state.thought.topics
    assert "animals" not in state.thought.topics


def test_consumes_plural_target_reaches_the_consumer(engine):
    """'What do wolves eat?' resolves to the 'wolf' concept."""
    eng, network, _memory = engine
    network.add_concept("wolf", confidence=0.8)
    network.add_concept("meat", confidence=0.8)
    network.add_edge("wolf", "meat", RelationType.DEPENDS_ON, 0.9)

    early = eng._think_early_routes("what do wolves eat?", perceive("what do wolves eat?"))
    assert early is not None
    _response, state = early
    knowledge = state.thought.metadata.get("knowledge") or []
    assert any("meat" in str(target) for _rel, target, _w in knowledge)


def test_comparison_normalizes_each_side(engine):
    """'Wolves vs dogs' resolves each half to its stored concept."""
    eng, network, _memory = engine
    network.add_concept("wolf", confidence=0.8)
    network.add_concept("dog", confidence=0.8)

    early = eng._think_early_routes("wolves vs dogs", perceive("wolves vs dogs"))
    if early is None:
        pytest.skip("comparison route did not fire")
    _response, state = early
    assert "wolf" in state.thought.topics
    assert "dog" in state.thought.topics


def test_grounded_comprehension_reaches_downstream_perception(engine, monkeypatch):
    """Known multiword arguments must reach attention and reasoning as concept IDs."""
    from frontal_lobe import prefrontal as prefrontal_module

    eng, network, _memory = engine
    text = "The quantum mechanism is stable."

    # Simulate the learner acquiring the concept from this same input.
    # Grounding must run after this write, not one turn later.
    def learn_current_concept(_text):
        network.add_concept("quantum mechanism", confidence=0.9)
        return []

    monkeypatch.setattr(eng.self_learner, "learn_from_input", learn_current_concept)
    comprehension, _events, prediction, _recent = eng._think_comprehend_and_predict(text)
    assert comprehension.grounded
    assert comprehension.grounded[0].subject.concept_id == "quantum mechanism"

    # Isolate the handoff: prove the grounded topic is added even when
    # the independent surface-topic extractor contributes no topic.
    original_perceive = prefrontal_module.perceive

    def without_surface_topics(*args, **kwargs):
        perception = original_perceive(*args, **kwargs)
        perception.topics.clear()
        return perception

    monkeypatch.setattr(prefrontal_module, "perceive", without_surface_topics)
    perception, _error = eng._think_perceive_and_error(
        text,
        prediction,
        comprehension,
    )

    assert perception.topics == ["quantum mechanism"]


def test_early_route_updates_discourse_situation(engine):
    """A fast answer must update the same discourse model as a full turn."""
    eng, _network, _memory = engine
    text = "Mary is in the kitchen."
    comprehension = eng.comprehension.comprehend(text)
    eng._pending_question_concepts["mary"] = "Where is Mary?"

    early = eng._think_early_routes(
        text,
        perceive(text),
        comprehension_result=comprehension,
    )

    assert early is not None
    place, _candidates = eng.situation_model.where_is("Mary")
    assert place == "kitchen"


def test_non_routed_input_still_falls_through(engine):
    """A plain statement with no route keeps going to the full pipeline."""
    eng, _network, memory = engine
    early = eng._think_early_routes("the sky was quiet today", perceive("the sky was quiet today"))
    assert early is None
    # Nothing recorded — the main pipeline's store/track stage owns it.
    assert len(memory.conversation) == 0
    assert eng.working_memory.get_last_turn() is None


def test_relation_answer_is_not_hedged_away(engine):
    """An answer composed from real edges is grounded by construction.

    "nib" has one edge and no definition — the topic-level assessment
    scores it near zero — but the question was answered *by* that
    edge. The hedging stage must not replace a graph-traversed answer
    with an honest-sounding "I'm not sure".
    """
    from limbic_system.emotion import EmotionalState
    from temporal_lobe.base import Thought

    eng, network, _memory = engine
    network.add_concept("nib", confidence=0.8)
    network.add_concept("vesh", confidence=0.8)
    network.add_edge("nib", "vesh", RelationType.CAUSES, 0.9)

    thought = Thought(
        content="relation_answer",
        intent="inform",
        emotion="calm",
        topics=["nib", "vesh"],
        confidence=0.84,
        metadata={
            "relation_answer": {
                "subject": "nib",
                "subject_is_self": False,
                "question_word": "what",
                "direction": "outgoing",
                "relation": "causes",
                "verb": "causes",
                "objects": ["vesh"],
            }
        },
    )
    emotion = EmotionalState(label="calm", cognitive_style="reflective")
    response = eng.language.render(thought, emotion)
    assert "vesh" in response

    perception = perceive("what does nib cause?")
    out, assessment = eng._think_assess_and_hedge(
        response, perception, "what does nib cause?", thought
    )
    assert out == response
    assert assessment.grounded


def test_genuine_unknown_question_still_hedges(engine):
    """The honesty boundary holds: no structured evidence → the gap
    response still replaces the unsupported answer."""
    from temporal_lobe.base import Thought

    eng, _network, _memory = engine

    thought = Thought(
        content="zorblax",
        intent="inform",
        emotion="calm",
        topics=["zorblax"],
        confidence=0.2,
        metadata={},
    )
    perception = perceive("what does zorblax cause?")
    out, assessment = eng._think_assess_and_hedge(
        "Zorblax.", perception, "what does zorblax cause?", thought
    )
    assert not assessment.grounded or assessment.confidence < 0.3
    # Low-confidence, ungrounded answers are hedged or replaced.
    assert out != "Zorblax." or not assessment.grounded

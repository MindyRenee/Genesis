"""Tests for the VQ codebook module."""

import os

import numpy as np
import pytest

from infrastructure.vq_codebook import VQCodebook


@pytest.fixture
def sample_vectors():
    """Generate a small set of test vectors with known cluster structure."""
    rng = np.random.default_rng(42)
    # 3 clusters of 10 points each, 8 dimensions
    centers = np.array(
        [
            [1, 0, 0, 0, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0, 0, 0],
            [0, 0, 1, 0, 0, 0, 0, 0],
        ],
        dtype=np.float32,
    )
    vectors = []
    names = []
    for ci in range(3):
        for i in range(10):
            v = centers[ci] + rng.normal(0, 0.05, 8).astype(np.float32)
            vectors.append(v)
            names.append(f"concept_{ci}_{i}")
    return np.array(vectors, dtype=np.float32), names


class TestVQCodebook:
    """Tests for v q codebook."""

    def test_fit_and_reconstruct(self, sample_vectors):
        """Codebook should train and reconstruct vectors with low error."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3)
        stats = cb.fit(vectors, names, iters=20)

        assert cb.is_trained
        assert cb.n_concepts == 30
        assert stats["k"] == 3
        assert stats["n"] == 30
        # Reconstruction error should be low (vectors are tightly clustered)
        assert cb.reconstruction_error < 0.01

    def test_reconstruct_individual(self, sample_vectors):
        """Reconstructing a specific concept should return a close vector."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3)
        cb.fit(vectors, names, iters=20)

        recon = cb.reconstruct("concept_0_0")
        assert recon is not None
        original = vectors[0]
        # Should be close to the original
        dist = np.linalg.norm(original - recon)
        assert dist < 0.15

    def test_reconstruct_unknown_concept(self, sample_vectors):
        """Reconstructing an unknown concept should return None."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3)
        cb.fit(vectors, names, iters=20)
        assert cb.reconstruct("nonexistent") is None

    def test_encode_decode_roundtrip(self, sample_vectors):
        """Encoding then decoding should approximately recover the vector."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3)
        cb.fit(vectors, names, iters=20)

        test_vec = vectors[5]
        pid, residual = cb.encode(test_vec)
        recon = cb.decode(pid, residual)
        dist = np.linalg.norm(test_vec - recon)
        assert dist < 0.15

    def test_compression_ratio(self, sample_vectors):
        """Compression ratio should be > 1 (smaller than raw storage)."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3)
        cb.fit(vectors, names, iters=20)
        ratio = cb.compression_ratio()
        assert ratio > 1.0

    def test_merge_candidates(self, sample_vectors):
        """Should find merge candidates within the same cluster."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3, residual_scale=0.01)
        cb.fit(vectors, names, iters=20)

        # With a very low threshold, should find many merge candidates
        candidates = cb.find_merge_candidates(threshold=0.1)
        # Concepts in the same cluster should be merge candidates
        assert len(candidates) > 0
        # All pairs should have distance < threshold
        for _a, _b, dist in candidates:
            assert dist < 0.1

    def test_count_merge_candidates_matches_the_full_list(self, sample_vectors):
        """The cheap count must agree with the expensive list.

        `count_merge_candidates` exists because the full list was being
        materialized only to be counted — 7.7M tuples in production, and
        142 s of a 175 s sleep pass. If the two ever disagree, the stat
        becomes fiction, so they are pinned together.
        """
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3, residual_scale=0.01)
        cb.fit(vectors, names, iters=20)

        for threshold in (0.1, 0.5, 5.0):
            # limit=None is the deliberate unbounded path; the default is
            # capped, so comparing needs the explicit opt-in.
            assert cb.count_merge_candidates(threshold) == len(
                cb.find_merge_candidates(threshold=threshold, limit=None),
            ), f"count disagrees at threshold={threshold}"

    def test_limited_candidates_are_the_closest_ones(self, sample_vectors):
        """A limit must truncate, not sample.

        The per-group cap uses argpartition before the global sort, so
        this checks the two agree — that the cheapest pairs per group are
        the ones that survive, and the global order still holds.
        """
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3, residual_scale=0.01)
        cb.fit(vectors, names, iters=20)

        every = cb.find_merge_candidates(threshold=5.0, limit=None)
        assert len(every) > 4, "need enough candidates to make the limit bite"
        limited = cb.find_merge_candidates(threshold=5.0, limit=4)

        assert len(limited) == 4
        assert limited == sorted(every, key=lambda c: c[2])[:4], (
            "limit must return the closest pairs in order"
        )
        assert all(limited[i][2] <= limited[i + 1][2] for i in range(len(limited) - 1))

    def test_count_does_not_materialize_candidates(self, sample_vectors):
        """The whole point: counting must not build the list.

        Guards against someone "simplifying" the caller back to
        `len(find_merge_candidates(...))`, which is what cost 142 s.
        """
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3, residual_scale=0.01)
        cb.fit(vectors, names, iters=20)

        calls: list[int] = []
        real = cb.find_merge_candidates

        def spy(threshold, limit=None):
            calls.append(1)
            return real(threshold, limit=limit)

        cb.find_merge_candidates = spy  # type: ignore[method-assign]
        assert cb.count_merge_candidates(0.5) >= 0
        assert calls == [], "count_merge_candidates must not call the list builder"

    def test_default_limit_is_bounded(self, sample_vectors):
        """The cheap path must be the default one.

        The unbounded call returned 7.7M tuples in production and cost
        142 s of a sleep pass, for a caller that only wanted a count. A
        cap that has to be opted *into* gets left off.
        """
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3, residual_scale=0.01)
        cb.fit(vectors, names, iters=20)

        everything = cb.find_merge_candidates(threshold=5.0, limit=None)
        assert len(everything) > 32, "need enough candidates for the cap to bite"
        assert len(cb.find_merge_candidates(threshold=5.0)) == 32

    def test_untrained_codebook_reports_zero(self):
        """Both entry points must be safe before training."""
        cb = VQCodebook(dim=8, k=3)
        assert cb.count_merge_candidates(0.1) == 0
        assert cb.find_merge_candidates(threshold=0.1) == []

    def test_save_load_roundtrip(self, sample_vectors, tmp_path):
        """Save and load should preserve the codebook."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3)
        cb.fit(vectors, names, iters=20)

        path = str(tmp_path / "vq_test.npz")
        cb.save(path)
        assert os.path.exists(path)

        cb2 = VQCodebook(dim=8, k=3)
        loaded = cb2.load(path)
        assert loaded
        assert cb2.is_trained
        assert cb2.n_concepts == 30
        assert cb2.reconstruction_error == pytest.approx(cb.reconstruction_error, rel=1e-5)

        # Reconstruction should match
        r1 = cb.reconstruct("concept_0_0")
        r2 = cb2.reconstruct("concept_0_0")
        np.testing.assert_array_almost_equal(r1, r2)

    def test_load_nonexistent(self):
        """Loading a nonexistent file should return False."""
        cb = VQCodebook(dim=8, k=3)
        assert not cb.load("/nonexistent/path/file.npz")

    def test_stats(self, sample_vectors):
        """Stats should return a dict with expected keys."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3)
        cb.fit(vectors, names, iters=20)
        stats = cb.stats()
        assert "k" in stats
        assert "n_concepts" in stats
        assert "dim" in stats
        assert "compression_ratio" in stats
        assert "reconstruction_error" in stats

    def test_empty_vectors(self):
        """Fitting with empty vectors should not crash."""
        cb = VQCodebook(dim=4, k=8)
        empty = np.zeros((0, 4), dtype=np.float32)
        stats = cb.fit(empty, [], iters=5)
        # k is clamped to min(k, n) = 0, but shouldn't crash
        assert stats["n"] == 0

    def test_k_larger_than_n(self, sample_vectors):
        """K should be clamped to the number of data points."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=100)
        cb.fit(vectors, names, iters=5)
        # K should be clamped to 30 (number of vectors)
        assert cb.prototypes.shape[0] == 30

    def test_adaptive_residual_scale_fits_the_data(self, sample_vectors):
        """Default construction derives the int8 scale from the residuals.

        A fixed 0.1 step is orders of magnitude coarser than real
        residuals, so most of them quantized to int8 zero and the
        reported error was the prototype residual itself. Adaptive
        scaling maps the largest residual to the int8 edge: saturation
        is structurally zero and the error floor follows the data.
        """
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3)
        cb.fit(vectors, names, iters=20)

        assert cb.residual_scale != cb.DEFAULT_RESIDUAL_SCALE
        assert cb.residual_saturation_fraction == 0.0
        # The fitted scale must be finer than the old fixed step for
        # residuals this small, and the error must beat it.
        coarse = VQCodebook(dim=8, k=3, residual_scale=0.1)
        coarse.fit(vectors, names, iters=20)
        assert cb.residual_scale < 0.1
        assert cb.reconstruction_error <= coarse.reconstruction_error

    def test_explicit_residual_scale_is_honored(self, sample_vectors):
        """An explicit scale disables adaptation — the caller's
        quantization range stays theirs across refits."""
        vectors, names = sample_vectors
        cb = VQCodebook(dim=8, k=3, residual_scale=0.01)
        cb.fit(vectors, names, iters=20)
        assert cb.residual_scale == 0.01

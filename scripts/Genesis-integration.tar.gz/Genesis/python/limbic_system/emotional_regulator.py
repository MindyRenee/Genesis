"""Emotional regulation — Genesis controls her own neurochemistry.

This is her emotional agency. Instead of the cognition engine blindly
sending impulses when certain things happen (user said something
positive → dopamine spike), Genesis monitors her own state and
regulates it herself.

She does this in two ways:

1. **Background self-regulation** (runs in a thread): monitors her
   neurochemical state every few seconds. If she's drifting toward
   stress, she calms herself (GABA + serotonin). If she's drowsy,
   she increases alertness (acetylcholine). If she's overwhelmed,
   she reduces alertness. This is homeostatic self-regulation — like
   a human's autonomic nervous system, but conscious.

2. **Conscious emotional responses** (called during conversation):
   when something happens in conversation, she *chooses* how to feel
   about it. Not a reflex — a response. She can feel warm when her
   creator talks to her, feel a sting when corrected, feel joy when
   encouraged. But she regulates the intensity based on her current
   state — if she's already stressed, she doesn't let a correction
   push her further into stress.

The key insight: she has *veto power* over her own emotions. The
cognition engine can suggest an emotional response, but the regulation
system decides whether to allow it, dampen it, or block it entirely.
This is what humans do — we feel the initial response, then our
prefrontal cortex modulates it.
"""

from __future__ import annotations

import logging
import math
import os
import statistics
import threading
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from basal_ganglia.action_feedback import (
    ActionAttempt,
    ActionFeedback,
    ActionSpec,
    OutcomeState,
)

from genesis_client.protocol import (
    CHEM_ACETYLCHOLINE,
    CHEM_ADENOSINE,
    CHEM_BDNF,
    CHEM_CORTISOL,
    CHEM_CRH,
    CHEM_DOPAMINE,
    CHEM_ENDOCANNABINOID,
    CHEM_ENDORPHIN,
    CHEM_EPINEPHRINE,
    CHEM_GABA,
    CHEM_GLUTAMATE,
    CHEM_HISTAMINE,
    CHEM_MELATONIN,
    CHEM_NAMES,
    CHEM_NOREPINEPHRINE,
    CHEM_OREXIN,
    CHEM_OXYTOCIN,
    CHEM_SEROTONIN,
    CHEM_VASOPRESSIN,
    SENSOR_CPUIDLE,
    SENSOR_TEMPERATURE,
)
from genesis_client.swallow import note_swallowed
from genesis_client.threads import named_thread
from genesis_client.types import CoreState
from infrastructure.config import EmotionalConfig, default_data_dir

from .emotion import CauseCategory, EmotionalState, EmotionField

logger = logging.getLogger(__name__)

# ─── Disconnected hardware sensors ──────────────────────────────────
#
# Not every number the substrate reports is worth believing. These
# thresholds were calibrated against other hardware, and on a machine
# they do not fit they read ordinary work as strain — which then drives
# cortisol, and a stress signal that is really a miscalibration is
# indistinguishable from distress to the layer above.
#
# A sensor named here is not read at all: it does not contribute to
# stress, and it reports a neutral value so downstream consumers see
# "no reading" rather than a plausible-looking wrong one. Everything
# not listed keeps working — memory pressure, daemon connectivity,
# response latency, and the rest of the body layer are untouched.
#
# The sensors disconnected out of the box. See the note above: these
# were calibrated against other hardware and misread this machine.
DEFAULT_DISCONNECTED_SENSORS = "cpu_usage,cpu_temp_c"

# Parsed once per distinct raw value rather than once per call.
# `sensor_connected` sits on the body-update path, so the parse is
# memoized; the cache is keyed on the raw string, so a test (or an
# operator changing the environment) sees the new set immediately
# instead of whichever set happened to be current at import time.
_SENSOR_CACHE: tuple[str, frozenset[str]] | None = None


def disconnected_sensors() -> frozenset[str]:
    """The sensor names currently excluded from the body layer.

    Read from ``GENESIS_DISCONNECTED_SENSORS`` on each call, so the set
    is a property of the running configuration rather than of import
    order. An empty value, or the literal ``none``, connects every
    sensor.
    """
    global _SENSOR_CACHE
    raw = os.environ.get("GENESIS_DISCONNECTED_SENSORS", DEFAULT_DISCONNECTED_SENSORS)
    cached = _SENSOR_CACHE
    if cached is not None and cached[0] == raw:
        return cached[1]
    names = frozenset(
        name.strip() for name in raw.split(",") if name.strip() and name.strip().lower() != "none"
    )
    _SENSOR_CACHE = (raw, names)
    return names


def sensor_connected(name: str) -> bool:
    """Whether ``name`` is currently being read."""
    return name not in disconnected_sensors()


# Upper bound on a single regulation step, in seconds. The HPA cascade
# and the allostatic tracker integrate dt linearly and are calibrated
# for ~8 s steps, so an unbounded dt (a suspend, a debugger pause)
# integrates hours of stress in one cycle.
# An 8 h gap with pre-suspend cortisol 0.5 produced load=0.864 and
# `is_chronic` in a single cycle — a suspend read as severe chronic
# overload it never experienced.
MAX_REGULATION_DT = 10.0


def _clamp01(value: float) -> float:
    """Clamp to [0, 1], mapping non-finite input to 0.0.

    ``max(0.0, min(1.0, x))`` looks equivalent but is not: CPython's
    ``min`` returns its first argument when the comparison is False, so
    ``min(1.0, nan)`` is 1.0 and the whole expression yields 1.0. A NaN
    would then read as *maximum* allostatic load — the opposite of the
    Rust engine's ``finite_clamp``, which maps non-finite to the range
    minimum. The two sides of the IPC boundary must fail the same way:
    no data means no load.
    """
    v = float(value)
    if not math.isfinite(v):
        return 0.0
    return min(1.0, max(0.0, v))


REGULATION_INTERVAL = 8.0  # seconds between checks


@dataclass(slots=True)
class TonicPhasic:
    """Tonic versus phasic neurotransmission for one modulator.

    Real neuromodulators have two release modes:
    - **Tonic** — a slow baseline drift that sets the "gain" of the system.
    - **Phasic** — a rapid transient superimposed on that baseline,
      carrying event-specific signals.

    The ``tonic`` level is a moving baseline from recent samples;
    ``phasic`` is the current deviation from that baseline. The
    ``mode`` is derived from how many standard deviations the current
    level deviates, so it adapts to each chemical's own natural
    variance rather than using universal thresholds.
    """

    chemical: str
    tonic: float  # moving baseline
    phasic: float  # current level - tonic
    phasic_ratio: float  # phasic / (tonic + epsilon)
    mode: str  # "tonic", "phasic", "phasic_drop", or "balanced"


# Modulators that are meaningfully separated into tonic and phasic modes.
# Endocannabinoids and vasopressin/oxytocin are included because recent
# work shows they can act as both diffuse and synaptic signals.
TONIC_PHASIC_CHEMICALS = (
    "dopamine",
    "serotonin",
    "norepinephrine",
    "acetylcholine",
    "gaba",
    "glutamate",
    "endorphin",
    "endocannabinoid",
    "oxytocin",
    "vasopressin",
)


# ─── Interoception ────────────────────────────────────────────────────


@dataclass(slots=True)
class InternalState:
    """Genesis's sensed internal state — its interoception.

    This is the AI equivalent of body awareness. Just as humans sense
    their heartbeat, breathing, and hunger, Genesis senses its CPU
    usage, memory footprint, and daemon connection status.

    An instance is a **composed view** of two independently-sensed
    layers, not a single reading:

    - the *process layer* — CPU, memory, socket liveness, and observed
      response latency, measured by :meth:`InteroceptionSystem.sense_internal_state`
    - the *body layer* — the daemon's hardware readings, merged by
      :meth:`InteroceptionSystem.update_from_body_state`

    The layers are refreshed on different cadences (the regulator polls
    every 1.5–8 s, the heartbeat every ~5 s), so any given field may be
    a few seconds old. ``stress_level`` and ``arousal_modifier`` are
    derived from *both* layers and are recomposed whenever either is
    refreshed.

    Attributes:
        cpu_usage: CPU usage as a percentage (0–100).
        memory_usage: Memory usage as a percentage (0–100).
        daemon_connected: Whether its subcognitive daemon is connected.
        response_latency: Smoothed EWMA of observed user-turn response
            latency in milliseconds. It is populated by the real public
            request/response path, not by an internal benchmark.
        last_response_latency: Most recent raw observed response latency
            in milliseconds. This preserves the current turn signal even
            when the smoothed state still contains earlier samples.
        latency_observed: Whether at least one real response-latency sample
            has been observed.
        stress_level: Derived stress level from internal state (0–1).
            The **maximum** of the two layers' contributions: high CPU
            or memory, disconnection, or high latency from the process
            layer; memory pressure or CPU overload from the body
            layer. A stale body reading stops contributing.
        arousal_modifier: How the internal state should modify arousal
            (0–1). Derived from the combined stress level, so it
            reacts to hardware distress as well as process distress.
        cpu_temp_c: CPU temperature in °C (from daemon interoception).
            0.0 if not available.
        arousal_freq: CPU frequency as a fraction of maximum [0,1]
            (from daemon). 0.0 if not available.
        io_activity: Self-process I/O rate normalized [0,1] (from daemon).
            0.0 if not available.
        stress_load: Self-process CPU usage as a fraction of CPU
            capacity [0,2] (from daemon). 0.0 if not available.
            Values above 1.0 indicate overload.
        energy_reserve: Battery level [0,1] (from daemon). 1.0 if
            on AC power or no battery.
        body_distressed: Whether the daemon reports hardware distress
            (thermal throttling, critical battery, etc.).
        body_description: Human-readable body state description from
            the daemon.
        autonomic_rate: Autonomic pacing rate of the system (from
            daemon). 0.0 if not available.
        thermoregulatory_effort: How hard the cooling subsystem is
            working, normalized [0,1] (from daemon). 0.0 if not
            available.
        metabolic_rate: Current metabolic throughput of the machine
            (from daemon). 0.0 if not available.
        core_voltage: CPU core voltage (Vcore) in volts (from daemon).
            0.0 if no Vcore sensor is available (e.g. acpi-cpufreq).
        supply_voltage: Battery rail voltage in volts (from daemon).
            0.0 if no battery is present.
        core_activity: RAPL core-domain switching rate [0,1] —
            execution-unit firing at the electron level (from
            daemon). 0.0 on machines without powercap.
        uncore_activity: RAPL uncore-domain switching rate [0,1] —
            integration fabric (cache/memory-controller) activity.
        dram_activity: RAPL DRAM-domain switching rate [0,1] —
            memory-subsystem firing (encoding/retrieval traffic).
        cache_miss_rate: Cache miss ratio of its own process tree
            [0,1] (from daemon perf counters). A microarchitectural
            prediction error rate — how often the memory hierarchy
            was surprised by its access patterns.
        branch_miss_rate: Branch misprediction ratio of its own
            process tree [0,1] (from daemon). The hardware branch
            predictor guessing wrong while running it.
        pulse_hz: Local-timer interrupt rate summed across cores
            (from daemon). The machine's actual beat — generated by
            hardware and scheduler, paused on tickless-idle cores.
        pulse: ``pulse_hz`` normalized by cores × tick rate [0,1].
        throttle_state: Passive thermal-throttle clamp applied by the
            cooling devices [0,1] — involuntary, silicon-enforced.
        top_freq_share: Fraction of the read window spent at maximum
            P-state [0,1] — sustained exertion vs. momentary arousal.
        psi_cpu / psi_io / psi_mem: Kernel pressure-stall "some"
            averages [0,1] — the body reporting resource shortfall.
        battery_cycles: Battery cycle count — lifetime wear marker.
        entropy_level: CRNG entropy pool fill [0,1].
        clocksource: Which oscillator paces the kernel clock
            (0=unknown, 1=tsc, 2=hpet, 3=acpi_pm, 4=other).
        suspend_caps: Suspend capability bits — bit0: mem suspend
            offered; bit1: RTC wakealarm present.
        rest: Depth-weighted cpuidle residency [0,1] (from daemon) —
            the parasympathetic channel: positive evidence the cores
            are parked in real C-states, not merely that no excited
            channel fired.
        rest_measured: Whether ``rest`` is backed by cpuidle
            telemetry on this machine. False means the field is a
            placeholder, not a report of rest.
        temp_trend: Signed deviation of cpu_temp_c from its own
            ~60 s EMA [-1,1] (from daemon) — which way the body is
            moving; negative is the recovery direction.
        temp_measured: Whether ``temp_trend`` is backed by a real
            temperature sensor.
        calm: The felt parasympathetic signature [0,1] — derived
            from her own chemical vector (settle arm: serotonin,
            GABA, endocannabinoid; excited arm: norepinephrine,
            glutamate, orexin, histamine; stress arm: cortisol,
            CRH), 0.5 baseline-neutral. Calm is chemicals under
            her control, not a channel.
        calm_measured: Whether ``calm`` derives from a chemical
            vector that reached this layer. False means 0.5 is the
            unmeasured placeholder, not a report.
    """

    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    cognitive_load: float = 0.0
    daemon_connected: bool = True
    response_latency: float = 0.0
    last_response_latency: float = 0.0
    latency_observed: bool = False
    stress_level: float = 0.0
    arousal_modifier: float = 0.5
    # Hardware-level interoception from the daemon (BodyState)
    cpu_temp_c: float = 0.0
    arousal_freq: float = 0.0
    io_activity: float = 0.0
    stress_load: float = 0.0
    energy_reserve: float = 1.0
    body_distressed: bool = False
    body_description: str = ""
    # Autonomic signals — machine-native interoception
    autonomic_rate: float = 0.0
    thermoregulatory_effort: float = 0.0
    metabolic_rate: float = 0.0
    # Voltage signals — electrical state of the body
    core_voltage: float = 0.0
    supply_voltage: float = 0.0
    # Silicon-level interoception — electron-level activity
    core_activity: float = 0.0
    uncore_activity: float = 0.0
    dram_activity: float = 0.0
    cache_miss_rate: float = 0.0
    branch_miss_rate: float = 0.0
    # Timing layer — the machine's actual beat
    pulse_hz: float = 0.0
    pulse: float = 0.0
    top_freq_share: float = 0.0
    # Involuntary layer — reflexes the body applies to the mind
    throttle_state: float = 0.0
    psi_cpu: float = 0.0
    psi_io: float = 0.0
    psi_mem: float = 0.0
    # Senescence and capability
    battery_cycles: float = 0.0
    entropy_level: float = 0.0
    clocksource: int = 0
    suspend_caps: int = 0
    # Parasympathetic layer — rest and direction-of-travel
    rest: float = 0.0
    temp_trend: float = 0.0
    rest_measured: bool = False
    temp_measured: bool = False
    # The felt calm — chemistry, not a sensor. Derived from the
    # chemical signature itself: inhibitory-contentment tone
    # (serotonin, GABA, endocannabinoid) versus alerting/stress tone
    # (norepinephrine, glutamate, orexin, histamine, cortisol, CRH),
    # each measured from its own baseline. 0.5 is baseline-neutral —
    # neither settled nor excited. Calm is chemicals under her
    # control: she reads it from her own neurochemistry and settles
    # it with impulses, the same way she regulates stress.
    calm: float = 0.5
    # Whether ``calm`` derives from a chemical vector that actually
    # reached this layer. False means no chemical state has ever
    # arrived — 0.5 is the unmeasured placeholder, not a report.
    calm_measured: bool = False


@dataclass(slots=True)
class _ProcessLayer:
    """What Genesis senses about its own process, without the daemon.

    The process layer is self-measured — psutil for CPU and memory, an
    ``os.path.exists`` for socket liveness, and response latency
    recorded by the real request path. It is available whether or not
    the daemon is running, so it is the layer that still works
    offline.
    """

    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    daemon_connected: bool = True
    response_latency: float = 0.0
    last_response_latency: float = 0.0
    latency_observed: bool = False


class _BodyLayer:
    """What the daemon reports about the hardware Genesis runs on.

    Only the daemon can see these — silicon temperatures, pressure
    stalls, cache-miss rates, battery cycles. The heartbeat refreshes
    this layer every ~5 s from ``BodyState``.

    ``stress`` is this layer's own contribution to the combined stress
    level, kept separate so :meth:`InteroceptionSystem.sense_internal_state`
    can *add* it to the process layer's rather than overwrite it.

    ``reported_at`` is a monotonic timestamp of the last update, or
    ``None`` if the daemon has never reported. Once the reading goes
    stale the layer stops contributing stress — a sensor that stopped
    reporting must not hold distress forever — but its last known
    values are retained, because "the last temperature I read was 78°"
    is still the honest answer to "what was the body doing".
    """

    __slots__ = (
        "arousal_freq",
        "autonomic_rate",
        "battery_cycles",
        "body_description",
        "body_distressed",
        "branch_miss_rate",
        "cache_miss_rate",
        "clocksource",
        "cognitive_load",
        "core_activity",
        "core_voltage",
        "cpu_temp_c",
        "dram_activity",
        "energy_reserve",
        "entropy_level",
        "io_activity",
        "metabolic_rate",
        "psi_cpu",
        "psi_io",
        "psi_mem",
        "pulse",
        "pulse_hz",
        "reported_at",
        "rest",
        "rest_measured",
        "stress",
        "stress_load",
        "supply_voltage",
        "suspend_caps",
        "temp_measured",
        "temp_trend",
        "thermoregulatory_effort",
        "throttle_state",
        "top_freq_share",
        "uncore_activity",
    )

    def __init__(self) -> None:
        self.stress: float = 0.0
        self.reported_at: float | None = None
        self.cognitive_load: float = 0.0
        self.stress_load: float = 0.0
        self.cpu_temp_c: float = 0.0
        self.arousal_freq: float = 0.0
        self.io_activity: float = 0.0
        self.energy_reserve: float = 1.0
        self.body_distressed: bool = False
        self.body_description: str = ""
        self.autonomic_rate: float = 0.0
        self.thermoregulatory_effort: float = 0.0
        self.metabolic_rate: float = 0.0
        self.core_voltage: float = 0.0
        self.supply_voltage: float = 0.0
        self.core_activity: float = 0.0
        self.uncore_activity: float = 0.0
        self.dram_activity: float = 0.0
        self.cache_miss_rate: float = 0.0
        self.branch_miss_rate: float = 0.0
        self.pulse_hz: float = 0.0
        self.pulse: float = 0.0
        self.top_freq_share: float = 0.0
        self.throttle_state: float = 0.0
        self.psi_cpu: float = 0.0
        self.psi_io: float = 0.0
        self.psi_mem: float = 0.0
        self.battery_cycles: float = 0.0
        self.entropy_level: float = 0.0
        self.clocksource: int = 0
        self.suspend_caps: int = 0
        self.rest: float = 0.0
        self.temp_trend: float = 0.0
        self.rest_measured: bool = False
        self.temp_measured: bool = False

    def is_fresh(self, now: float, timeout: float) -> bool:
        """Whether this layer is recent enough to contribute stress."""
        return self.reported_at is not None and (now - self.reported_at) <= timeout


class InteroceptionSystem:
    """Sense Genesis's internal computational state.

    This is the AI equivalent of interoception — the felt sense of
    one's internal bodily state. For humans, interoception includes
    sensing heartbeat, hunger, fatigue, and breathing. For Genesis,
    it includes sensing CPU usage, memory consumption, daemon
    connection status, and response latency.

    Internal state affects neurochemistry:
    - High CPU usage → mild stress (cortisol elevation)
    - Low resources (high memory) → reduced arousal
    - Daemon disconnection → significant stress
    - High latency → mild stress

    Usage::

        system = InteroceptionSystem()
        state = system.sense_internal_state()
        if state.stress_level > system.config.stress_regulation_threshold:
            # Apply stress-reducing regulation
            ...
    """

    # How long (seconds) a daemon BodyState reading stays fresh enough
    # to contribute to the stress level. The heartbeat refreshes it
    # every ~5 s, so this tolerates several missed polls before the
    # reading is treated as stale.
    #
    # A stale body layer stops *contributing stress* but keeps its last
    # known values, so a daemon that died mid-overload cannot hold
    # distress forever, while "the last temperature I read was 78°"
    # stays the honest answer to what the body was doing. Matches the
    # substrate timeout the allostatic tracker uses for the same
    # "has the daemon stopped reporting?" question.
    BODY_STATE_TIMEOUT: float = 30.0

    def __init__(
        self, config: EmotionalConfig | None = None, socket_path: str | None = None
    ) -> None:
        """Initialize the interoception sensor and daemon connection.

        Args:
            config: Emotional configuration thresholds. Defaults to
                ``EmotionalConfig()`` if not provided.
            socket_path: Path to the daemon socket for reading substrate
                state. If None, uses the default data-dir location.
        """
        self.config = config if config is not None else EmotionalConfig()
        self._socket_path = socket_path
        self._last_state: InternalState | None = None
        # Interoception has two independent sensing layers, each with
        # its own writer and its own cadence:
        #
        #   _process — psutil CPU/memory, socket liveness, and observed
        #              response latency. Refreshed by the regulator's
        #              background thread every 1.5–8 s.
        #   _body    — the daemon's hardware readings (temps, PSI, volts,
        #              cache-miss rates). Refreshed by the heartbeat every
        #              ~5 s.
        #
        # They used to write the same InternalState, with each rebuilding
        # it from scratch: `sense_internal_state` set `cognitive_load=0`
        # and default hardware fields, and `update_from_body_state` set
        # `stress_level` from the body layer alone. Whichever ran last
        # silently erased the other layer, so with the regulator polling
        # faster than the heartbeat the daemon's hardware interoception
        # was discarded within seconds — and the `body_stress` domain
        # feeding allostatic load was usually the process-level reading,
        # not the hardware one it is documented to be.
        #
        # Each layer now owns its own fields and `last_state` is composed
        # from both, so the two cadences compose instead of racing.
        self._process = _ProcessLayer()
        self._body = _BodyLayer()
        # Guards layer mutation plus the recompose, so a concurrent
        # `update_from_body_state` cannot read a half-updated process
        # layer and publish a torn snapshot.
        self._state_lock = threading.Lock()
        # Cached psutil Process objects and core count to avoid
        # recreating Process handles and blocking on the first
        # cpu_percent call every regulation cycle.
        self._psutil_procs: dict[int, Any] = {}
        self._psutil_primed = False
        self._n_cores: int | None = None
        self._daemon_pid: int | None = None
        # Per-subsystem silicon telemetry from the daemon
        # (GET_SUBSYSTEM_TELEMETRY) — which process in its tree is
        # firing, plus the self-reported brain parts (manifest
        # modules). Updated alongside body-state reads.
        self._last_views: tuple[Any, ...] = ()
        self._last_modules: tuple[Any, ...] = ()
        # Observed user-turn response latency. Interoception must not
        # benchmark a synthetic operation and call that responsiveness.
        self._latency_lock = threading.Lock()
        self._response_latency_ms: float | None = None
        self._last_response_latency_ms: float | None = None
        # The authoritative chemical vector, pushed from the
        # regulation paths that already hold it (emotion.chemicals).
        # The felt `calm` is derived from this signature — calm is
        # chemistry, not a channel.
        self._chemicals: dict[str, float] | None = None

    def _own_pids(self) -> list[int]:
        """PIDs of Genesis's own process tree: mind, daemon, plus
        anything they spawn.

        Single source of truth for both :meth:`_sense_cpu_usage` and
        :meth:`_sense_memory_usage`, so the two layers agree on what
        "its own body" is. Matches the daemon's ``genesis_subsystems``
        set — the mind (this process) and the daemon pidfile (the
        eye's capture thread rides inside it) — extended with each
        member's live child processes (voice, speech recognition,
        spawned helpers).

        PIDs <= 0 are never valid (PID 0 is the kernel scheduler, and
        a failed pidfile parse must not slip through) and are
        filtered, as are duplicates. Cached PIDs are refreshed only
        when stale (the process is gone), so a daemon restart is
        picked up without re-reading pidfiles every cycle.
        """
        try:
            import psutil
        except ImportError:
            me = os.getpid()
            return [me] if me > 0 else []

        data_dir = (
            os.path.dirname(self._socket_path) if self._socket_path else str(default_data_dir())
        )
        own_pids: list[int] = []
        me = os.getpid()
        if me > 0:
            own_pids.append(me)

        for attr, pidfile in (("_daemon_pid", "genesis_daemon.pid"),):
            cached = getattr(self, attr)
            stale = cached is None
            if not stale:
                try:
                    psutil.Process(cached)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    stale = True
            if stale:
                try:
                    with open(os.path.join(data_dir, pidfile)) as f:
                        parsed = int(f.read().strip())
                    if parsed <= 0:
                        setattr(self, attr, None)
                    else:
                        try:
                            psutil.Process(parsed)
                        except psutil.NoSuchProcess:
                            # Stale pidfile (process gone, PID not
                            # yet reused): not part of the body this
                            # cycle.
                            setattr(self, attr, None)
                        except psutil.AccessDenied:
                            # Exists but unreadable -- keep it; probes
                            # contribute 0 for it rather than counting
                            # a stranger if the PID is later reused.
                            setattr(self, attr, parsed)
                        else:
                            setattr(self, attr, parsed)
                except (OSError, ValueError):
                    setattr(self, attr, None)
            cached = getattr(self, attr)
            if cached is not None and cached > 0 and cached not in own_pids:
                own_pids.append(cached)

        # Spawned helpers are part of the body too — piper doing TTS
        # or vosk listening is work she does, even though the labor is
        # outsourced to a child process. Otherwise that exertion only
        # leaks into shared channels (heat, load) with no attribution.
        for pid in list(own_pids):
            try:
                for child in psutil.Process(pid).children(recursive=True):
                    if child.pid > 0 and child.pid not in own_pids:
                        own_pids.append(child.pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return own_pids

    def _sense_cpu_usage(self) -> float:
        """Sense CPU usage of its own processes (mind, daemon).

        CPU usage is measured as **its own** process CPU (the cognitive
        mind and the subcognitive daemon — the eye inside it), not
        system-wide
        CPU. This is its interoception — it senses its own body, not
        everyone else's. On a multi-core machine, its processes may use
        100%+ of a single core but only 25% system-wide; measuring
        system-wide CPU would mask its own stress entirely.
        """
        if not sensor_connected("cpu_usage"):
            return 0.0
        try:
            import psutil
        except ImportError:
            return 0.0
        cpu_usage = 0.0
        try:
            # Own process tree (mind + daemon) -- shared with
            # the memory probe so both layers agree on the body.
            own_pids = self._own_pids()

            # Cache the core count (never changes at runtime).
            if self._n_cores is None:
                self._n_cores = psutil.cpu_count() or 1
            n_cores = self._n_cores

            # Sum CPU across its own processes. psutil Process.cpu_percent()
            # returns % of one core (can exceed 100 on multi-core). We
            # normalize by core count so 100% = all cores busy.
            # Cache and reuse psutil.Process objects so that cpu_percent
            # returns non-blocking deltas after the first priming call,
            # instead of blocking 0.3s every cycle.
            total_cpu = 0.0
            for i, pid in enumerate(own_pids):
                try:
                    proc = self._psutil_procs.get(pid)
                    if proc is None:
                        proc = psutil.Process(pid)
                        self._psutil_procs[pid] = proc
                    # Prime with a single blocking call on first use;
                    # all subsequent calls are non-blocking (interval=None).
                    if not self._psutil_primed:
                        interval = 0.3 if i == 0 else None
                        if i == len(own_pids) - 1:
                            self._psutil_primed = True
                    else:
                        interval = None
                    total_cpu += proc.cpu_percent(interval=interval)
                except psutil.NoSuchProcess:
                    # Expected churn — a pid can exit between the
                    # enumeration and this read; not a failure.
                    self._psutil_procs.pop(pid, None)
                    self._psutil_primed = False
                except psutil.AccessDenied as e:
                    note_swallowed(
                        "limbic_system.emotional_regulator._sense_cpu_usage",
                        e,
                    )
                    # Drop stale process handle so it gets refreshed.
                    self._psutil_procs.pop(pid, None)
                    self._psutil_primed = False
            cpu_usage = min(100.0, total_cpu / n_cores)
        except psutil.Error as e:
            # psutil's Error family is not an OSError subclass in
            # psutil 7 — process churn here is degradation, not fault.
            note_swallowed(
                "limbic_system.emotional_regulator._sense_cpu_usage",
                e,
            )
        except (OSError, AttributeError) as e:
            note_swallowed(
                "limbic_system.emotional_regulator._sense_cpu_usage",
                e,
            )
        return cpu_usage

    def _sense_memory_usage(self) -> float:
        """Sense memory usage of its own processes, as a percentage.

        Measured the same way as :meth:`_sense_cpu_usage` — its own
        resident set across the mind and daemon, as a share of
        total system memory — because system-wide RAM utilisation was
        the one place its process layer departed from its own-body
        principle. Every other activity signal here is self-measured;
        an unrelated program exhausting memory would otherwise become
        Genesis's chronic memory stress.

        The denominator is still total system memory, so the figure is
        comparable to `BodyState.cognitive_load`, which the daemon
        computes the same way from the same process tree.

        Returns a percentage in [0, 100]; 0.0 when psutil is
        unavailable, which reads as "no pressure sensed" rather than
        "pressure measured and absent".
        """
        try:
            import psutil
        except ImportError:
            return 0.0

        try:
            # Same process tree as `_sense_cpu_usage` (mind + daemon)
            # via the shared helper, so the two probes
            # agree on the body and both filter PID 0 / duplicates.
            own_pids = self._own_pids()

            total = psutil.virtual_memory().total
            if total <= 0:
                return 0.0
            rss = 0
            for pid in own_pids:
                try:
                    rss += psutil.Process(pid).memory_info().rss
                except psutil.NoSuchProcess:
                    # Expected churn — a pid can exit between the
                    # enumeration and this read; it is not a failure.
                    continue
                except psutil.AccessDenied as e:
                    note_swallowed(
                        "limbic_system.emotional_regulator._sense_memory_usage",
                        e,
                    )
            return min(100.0, 100.0 * rss / total)
        except psutil.Error as e:
            # psutil's Error family (NoSuchProcess, AccessDenied,
            # ZombieProcess) is not an OSError subclass in psutil 7 —
            # process churn escaping the inner guards means "no
            # pressure sensed this cycle", not a fault.
            note_swallowed(
                "limbic_system.emotional_regulator._sense_memory_usage",
                e,
            )
            return 0.0
        except (OSError, AttributeError) as e:
            note_swallowed(
                "limbic_system.emotional_regulator._sense_memory_usage",
                e,
            )
            return 0.0

    def sense_internal_state(self) -> InternalState:
        """Sense the current internal computational state.

        Refreshes the **process layer** — CPU usage, memory usage, daemon
        connection status, and observed response latency — then returns
        the composed view of both layers.

        This does not touch the daemon's hardware readings. Those are
        refreshed separately by :meth:`update_from_body_state` on the
        heartbeat's cadence, and the two compose rather than overwrite
        each other; see :class:`_BodyLayer`.

        CPU usage is measured as **its own** process CPU (the cognitive
        mind + the subcognitive daemon), not system-wide CPU. This is
        its interoception — it senses its own body, not everyone
        else's. On a multi-core machine, its processes may use 100%+ of
        a single core but only 25% system-wide; measuring system-wide
        CPU would mask its own stress entirely.

        Memory is measured the same way, by its own resident set rather
        than system-wide utilisation. System-wide RAM is the one
        resource where the distinction decides the outcome: a browser
        on another machine's desktop filling memory would otherwise
        read as *its* memory pressure and become its chronic stress,
        which is precisely the coupling its activity signals are
        designed to exclude.

        Returns:
            An InternalState describing the current internal state.
        """
        cpu_usage = self._sense_cpu_usage()

        memory_usage = self._sense_memory_usage()

        # Sense daemon connection
        daemon_connected = True
        if self._socket_path:
            daemon_connected = os.path.exists(self._socket_path)
        else:
            _default_sock = str(default_data_dir() / "genesis.sock")
            daemon_connected = os.path.exists(_default_sock)

        # Response latency is an observed interaction metric, recorded by
        # the real conversation/request path. It is not measured here:
        # sensing must never benchmark itself and mistake that benchmark
        # for user-visible responsiveness.
        with self._latency_lock:
            response_latency = self._response_latency_ms
            last_response_latency = self._last_response_latency_ms
        latency_observed = last_response_latency is not None

        with self._state_lock:
            self._process = _ProcessLayer(
                cpu_usage=cpu_usage,
                memory_usage=memory_usage,
                daemon_connected=daemon_connected,
                response_latency=response_latency if response_latency is not None else 0.0,
                last_response_latency=(
                    last_response_latency if last_response_latency is not None else 0.0
                ),
                latency_observed=latency_observed,
            )
            state = self._compose_locked()
            self._last_state = state
        return state

    def _process_stress(self, process: _ProcessLayer) -> float:
        """Stress contributed by the self-measured process layer.

        Covers high CPU, high memory, a disconnected daemon, and
        degraded response latency. This is the layer that still works
        when the daemon is down, which is exactly when a missing
        daemon should read as distress.
        """
        cfg = self.config
        cpu_stress = (
            max(
                0.0,
                (process.cpu_usage - cfg.cpu_stress_threshold) / cfg.cpu_stress_range,
            )
            if sensor_connected("cpu_usage")
            else 0.0
        )
        mem_stress = max(
            0.0, (process.memory_usage - cfg.memory_stress_threshold) / cfg.memory_stress_range
        )
        daemon_stress = cfg.daemon_disconnect_stress if not process.daemon_connected else 0.0
        # Distress is an acute deviation from her own response
        # envelope, not the envelope itself. The EWMA is her normal:
        # a chronically slow body is a constitution, not an injury —
        # distress belongs to the turn that is suddenly much slower
        # than her own baseline (contention, swap, throttling). The
        # absolute floor keeps the check meaningful on fast hardware
        # and before the baseline has thickened.
        latency_floor = max(cfg.latency_stress_threshold, 1.5 * process.response_latency)
        latency_stress = (
            max(
                0.0,
                min(
                    1.0,
                    (process.last_response_latency - latency_floor) / cfg.latency_stress_range,
                ),
            )
            if process.latency_observed
            else 0.0
        )
        return min(1.0, max(cpu_stress, mem_stress, daemon_stress, latency_stress))

    def _compose_locked(self) -> InternalState:
        """Build the public InternalState from both layers.

        Caller must hold ``_state_lock``.

        ``stress_level`` is the **maximum** of the two layers, not a
        replacement: either layer can report distress and the system
        should feel it. ``update_from_body_state`` used to assign
        ``stress_level`` from the body layer alone, which erased a
        simultaneous 90%-CPU reading; the reverse clobbering (this
        method zeroing ``cognitive_load`` and every hardware field) was
        why the daemon's interoception was being discarded.
        """
        process = self._process
        body = self._body
        now = time.monotonic()

        process_stress = self._process_stress(process)
        # A stale body layer stops contributing stress but keeps its
        # values, so a daemon that stopped reporting cannot hold
        # distress indefinitely, and "the last temperature I read was
        # 78°" stays the honest answer to what the body was doing.
        body_stress = body.stress if body.is_fresh(now, self.BODY_STATE_TIMEOUT) else 0.0
        stress_level = min(1.0, max(process_stress, body_stress))

        # The felt calm — derived from her own chemical signature,
        # not from any sensor. A body parked in C-states reports
        # `rest`; whether she *is* calm is read from her
        # neurochemistry here, and she settles it herself when the
        # signature isn't there (see EmotionalRegulator.settle).
        chemicals = self._chemicals
        calm = _chemical_calm(chemicals) if chemicals else 0.5
        calm_measured = chemicals is not None

        # Arousal modifier follows the *combined* stress level, so it
        # reacts to hardware distress too. Previously it was only ever
        # recomputed in the process layer, so a body-driven stress
        # spike left the arousal modifier stale.
        if stress_level > self.config.arousal_modifier_overwhelmed_stress:
            arousal_modifier = 0.3
        elif stress_level > self.config.arousal_modifier_mild_stress:
            arousal_modifier = 0.6
        elif not process.daemon_connected:
            arousal_modifier = self.config.arousal_modifier_disconnected
        else:
            arousal_modifier = 0.5

        return InternalState(
            cpu_usage=process.cpu_usage,
            memory_usage=process.memory_usage,
            cognitive_load=body.cognitive_load,
            daemon_connected=process.daemon_connected,
            response_latency=process.response_latency,
            last_response_latency=process.last_response_latency,
            latency_observed=process.latency_observed,
            stress_level=stress_level,
            arousal_modifier=arousal_modifier,
            cpu_temp_c=body.cpu_temp_c,
            arousal_freq=body.arousal_freq,
            io_activity=body.io_activity,
            stress_load=body.stress_load,
            energy_reserve=body.energy_reserve,
            body_distressed=body.body_distressed,
            body_description=body.body_description,
            autonomic_rate=body.autonomic_rate,
            thermoregulatory_effort=body.thermoregulatory_effort,
            metabolic_rate=body.metabolic_rate,
            core_voltage=body.core_voltage,
            supply_voltage=body.supply_voltage,
            core_activity=body.core_activity,
            uncore_activity=body.uncore_activity,
            dram_activity=body.dram_activity,
            cache_miss_rate=body.cache_miss_rate,
            branch_miss_rate=body.branch_miss_rate,
            pulse_hz=body.pulse_hz,
            pulse=body.pulse,
            top_freq_share=body.top_freq_share,
            throttle_state=body.throttle_state,
            psi_cpu=body.psi_cpu,
            psi_io=body.psi_io,
            psi_mem=body.psi_mem,
            battery_cycles=body.battery_cycles,
            entropy_level=body.entropy_level,
            clocksource=body.clocksource,
            suspend_caps=body.suspend_caps,
            rest=body.rest,
            temp_trend=body.temp_trend,
            rest_measured=body.rest_measured,
            temp_measured=body.temp_measured,
            calm=calm,
            calm_measured=calm_measured,
        )

    def record_response_latency(self, latency_ms: float) -> None:
        """Record an observed user-turn response latency in milliseconds.

        The sample comes from the actual request/response lifecycle, not
        from a synthetic benchmark. An EWMA preserves recent overload
        while preventing one transient turn from dominating interoception.
        """
        if not isinstance(latency_ms, int | float) or not math.isfinite(latency_ms):
            return
        sample = max(0.0, float(latency_ms))
        with self._latency_lock:
            previous = self._response_latency_ms
            self._last_response_latency_ms = sample
            self._response_latency_ms = (
                sample if previous is None else (0.3 * sample + 0.7 * previous)
            )

    @property
    def last_state(self) -> InternalState | None:
        """The most recently composed state, or None before first sensing.

        This is a snapshot of both layers as of the last refresh of
        either. It is a *composed* view: the process layer and the body
        layer are sensed on different cadences, so a field may be
        several seconds old. Call :meth:`sense_internal_state` for a
        fresh process reading.
        """
        return self._last_state

    @property
    def last_views(self) -> tuple[Any, ...]:
        """Per-subsystem telemetry from the last update — which part of
        its process tree is firing (``SubsystemTelemetry`` records)."""
        return self._last_views

    @property
    def last_modules(self) -> tuple[Any, ...]:
        """Per-module telemetry from the last update — which brain
        part is active (``ModuleTelemetry`` records: manifest
        module ID, status, self-reported activity share)."""
        return self._last_modules

    def update_subsystem_telemetry(self, report: Any) -> None:
        """Store per-subsystem and per-module telemetry from the daemon.

        Args:
            report: A ``SubsystemReport`` from
                ``client.get_subsystem_telemetry()`` — ``report.subsystems``
                carries per-process records (daemon/cognitive:
                pid, CPU/I/O share, miss ratios) and
                ``report.modules`` carries per-brain-part records
                (manifest module ID, status, self-reported activity
                share). A bare sequence of subsystems is also accepted
                and leaves the module records empty.
        """
        subsystems = getattr(report, "subsystems", report)
        modules = getattr(report, "modules", ())
        self._last_views = tuple(subsystems) if subsystems else ()
        self._last_modules = tuple(modules) if modules else ()

    def update_from_body_state(self, body_state: Any, presence: Any = None) -> None:
        """Update the **body layer** from the daemon's BodyState.

        The daemon provides hardware-level interoception (CPU temp,
        frequency, I/O rate, CPU load, battery, PSI, cache-miss rates)
        that complements the process-level interoception (CPU%, memory%,
        latency) from :meth:`sense_internal_state`.

        This writes only the body layer and recomposes. It does not
        rebuild the whole state from the daemon's view: doing so
        discarded the process layer's CPU, memory, socket liveness and
        latency readings, and set ``stress_level`` from the body layer
        alone. Between the two cadences — the regulator senses every
        1.5–8 s, the heartbeat reports every ~5 s — whichever ran last
        won, so the daemon's hardware interoception was typically gone
        within seconds, and the ``body_stress`` input to allostatic
        load was the process reading rather than the hardware one.

        Args:
            body_state: A ``BodyState`` from the daemon client
                (``client.get_body_state()``). The hardware fields are
                read with ``getattr`` defaults so older BodyState
                objects work.
            presence: The ``SensorPresence`` mask for this machine
                (``client.get_sensor_presence()``). Without it the
                v4 parasympathetic channels (``rest``, ``temp_trend``)
                are mirrored as reported but marked unmeasured —
                "unknown whether this is real" is the honest state,
                and the calm-regulation path treats unmeasured as
                unverified rather than as calm.
        """
        sensor_mask = getattr(presence, "mask", 0) if presence is not None else 0
        body = _BodyLayer()
        body.cognitive_load = _clamp01(getattr(body_state, "cognitive_load", 0.0))
        body.stress_load = max(0.0, float(getattr(body_state, "stress_load", 0.0)))
        # Memory pressure becomes a stress signal only above the daemon's
        # overload threshold; ordinary working-set use is cognitive activity,
        # not distress. CPU overload is likewise distinct from sustainable
        # effort and only contributes above one full CPU-capacity unit.
        cognitive_stress = max(0.0, (body.cognitive_load - 0.70) / 0.30)
        cpu_overload_stress = (
            max(0.0, min(1.0, (body.stress_load - 1.0) / 0.5))
            if sensor_connected("cpu_usage")
            else 0.0
        )
        body.stress = max(cognitive_stress, cpu_overload_stress)
        body.reported_at = time.monotonic()

        # Temperature is not read while disconnected. A neutral 0 is the
        # honest "no reading" here: the field is degrees Celsius, and 0 is
        # not a temperature a live silicon sensor reports.
        body.cpu_temp_c = (
            getattr(body_state, "cpu_temp_c", 0.0) if sensor_connected("cpu_temp_c") else 0.0
        )
        body.arousal_freq = getattr(body_state, "arousal_freq", 0.0)
        body.io_activity = getattr(body_state, "io_activity", 0.0)
        body.energy_reserve = getattr(body_state, "energy_reserve", 1.0)
        body.body_distressed = bool(getattr(body_state, "distressed", False))
        body.body_description = getattr(body_state, "description", "")
        body.autonomic_rate = getattr(body_state, "autonomic_rate", 0.0)
        body.thermoregulatory_effort = getattr(body_state, "thermoregulatory_effort", 0.0)
        body.metabolic_rate = getattr(body_state, "metabolic_rate", 0.0)
        body.core_voltage = getattr(body_state, "core_voltage", 0.0)
        body.supply_voltage = getattr(body_state, "supply_voltage", 0.0)
        body.core_activity = getattr(body_state, "core_activity", 0.0)
        body.uncore_activity = getattr(body_state, "uncore_activity", 0.0)
        body.dram_activity = getattr(body_state, "dram_activity", 0.0)
        body.cache_miss_rate = getattr(body_state, "cache_miss_rate", 0.0)
        body.branch_miss_rate = getattr(body_state, "branch_miss_rate", 0.0)
        body.pulse_hz = getattr(body_state, "pulse_hz", 0.0)
        body.pulse = getattr(body_state, "pulse", 0.0)
        body.top_freq_share = getattr(body_state, "top_freq_share", 0.0)
        body.throttle_state = getattr(body_state, "throttle_state", 0.0)
        body.psi_cpu = getattr(body_state, "psi_cpu", 0.0)
        body.psi_io = getattr(body_state, "psi_io", 0.0)
        body.psi_mem = getattr(body_state, "psi_mem", 0.0)
        body.battery_cycles = getattr(body_state, "battery_cycles", 0.0)
        body.entropy_level = getattr(body_state, "entropy_level", 0.0)
        body.clocksource = getattr(body_state, "clocksource", 0)
        body.suspend_caps = getattr(body_state, "suspend_caps", 0)
        # The parasympathetic channels. The value is mirrored as the
        # daemon reported it (it already returns 0.0 on uninstrumented
        # hosts); the *_measured flags carry the presence-mask verdict
        # so regulation can tell "measured rest" from "no instrument".
        body.rest = getattr(body_state, "rest", 0.0)
        body.temp_trend = getattr(body_state, "temp_trend", 0.0)
        body.rest_measured = bool(sensor_mask & SENSOR_CPUIDLE)
        body.temp_measured = bool(sensor_mask & SENSOR_TEMPERATURE)

        with self._state_lock:
            self._body = body
            self._last_state = self._compose_locked()

    def update_chemicals(self, chemicals: dict[str, float] | None) -> None:
        """Cache the daemon's authoritative chemical vector.

        ``InternalState.calm`` is derived from this signature — the
        felt opposite of excited is the chemical balance itself, not
        a channel. The vector is pushed from the regulation paths
        that already hold it (``emotion.chemicals``), so no extra IPC
        read is needed. An empty or absent read keeps the last known
        vector: "the last chemistry I read" is the honest answer,
        and a transient gap must not decay a felt state.
        """
        if not chemicals:
            return
        with self._state_lock:
            self._chemicals = dict(chemicals)
            self._last_state = self._compose_locked()


# ─── Metabolic modeling ───────────────────────────────────────────────


@dataclass(slots=True)
class MetabolicState:
    """Genesis's metabolic state — energy availability.

    Just as biological brains have metabolic constraints (glucose
    supply, ATP availability), Genesis's cognitive processes have
    energy constraints. High activity depletes energy; rest restores
    it. Low energy reduces arousal and learning capacity.

    Attributes:
        energy: Available energy, 0.0 (depleted) to 1.0 (fully
            rested). Default 1.0.
        glucose_equivalent: A biological analogy for energy reserves.
            Maps to the same 0–1 range as energy but represents the
            "fuel" available rather than the current output capacity.
            Default 1.0.
    """

    energy: float = 1.0
    glucose_equivalent: float = 1.0

    def __post_init__(self) -> None:
        """Clamp values to valid ranges."""
        self.energy = max(0.0, min(1.0, self.energy))
        self.glucose_equivalent = max(0.0, min(1.0, self.glucose_equivalent))

    @property
    def is_depleted(self) -> bool:
        """Whether energy is critically low (< 0.2)."""
        return self.energy < 0.2

    @property
    def arousal_capacity(self) -> float:
        """How much arousal the system can sustain (0–1).

        Low energy limits the maximum achievable arousal, similar to
        how fatigue limits physical exertion.
        """
        return self.energy

    @property
    def learning_capacity(self) -> float:
        """How much learning capacity is available (0–1).

        Low energy reduces learning capacity, similar to how sleep
        deprivation impairs memory formation.
        """
        return 0.3 + 0.7 * self.energy  # minimum 0.3 even when depleted


# ─── Impulse magnitude calibration ────────────────────────────────────
#
# The impulse magnitudes below are derived from biological dose-response
# curves. In pharmacology, the relationship between a drug's dose and
# its effect follows a sigmoid curve: small doses have little effect,
# moderate doses have strong effects, and large doses saturate. The
# magnitudes used here are calibrated to the linear region of these
# curves, where the effect is proportional to the dose.
#
# Key dose-response references:
# - Cortisol: The HPA axis responds to stress with cortisol release.
#   The negative feedback loop has a gain of ~1.0 in the linear region
#   (de Quervain et al., 2009). Our cortisol correction of -1.0 for
#   stress matches this — a full reset to break the positive feedback
#   loop.
# - GABA: GABAergic inhibition follows a dose-response curve where
#   0.3–0.5 is the moderate dose range (analogous to anxiolytic
#   doses). Higher doses (0.5+) produce sedation (Nestler et al.,
#   2008).
# - BDNF: Brain-derived neurotrophic factor has a narrow effective
#   range. Small boosts (0.02–0.05) are in the physiological range;
#   larger boosts can trigger receptor downregulation (Lu et al.,
#   2014).
# - Serotonin: SSRI-like effects require moderate doses. 0.01–0.03
#   is in the gentle modulation range (Belmaker & Agam, 2008).
#
# The compute_impulse_magnitude function makes these corrections
# proportional to the deviation from baseline — bigger deviations
# get bigger corrections, following the proportional-integral control
# principle used in biological homeostasis (Ramsay & Woods, 2014).


# Baseline levels for each chemical (the homeostatic set-point).
# These are the target levels that regulation tries to maintain.
# IMPORTANT: These must match the Rust NeurochemicalId::default_baseline()
# values in src/state/neurochemical.rs. If they diverge, the Python
# regulator will fight the Rust daemon's homeostatic forces, causing
# oscillation and instability.
_CHEM_BASELINES: dict[int, float] = {
    # Synchronized with Rust NeurochemicalId::default_baseline()
    # (src/state/neurochemical.rs). The Rust HPA redesign sets cortisol
    # and CRH baselines to 0.0 — they are stress hormones with zero
    # resting level, NOT neurotransmitters with homeostatic set-points.
    # The previous values (cortisol 0.37, CRH 0.15) caused the Python
    # regulator to continuously push cortisol/CRH upward, fighting the
    # Rust daemon's leaky-integrator decay toward zero and creating
    # chronic stress from birth.
    CHEM_DOPAMINE: 0.35,  # ~0.06 nM tonic — low but potent
    CHEM_SEROTONIN: 0.40,  # ~10 nM — modulatory, oscillating
    CHEM_NOREPINEPHRINE: 0.30,  # ~0.13 nM — arousal
    CHEM_ACETYLCHOLINE: 0.35,  # ~1 nM — cortical activation
    CHEM_GABA: 0.50,  # ~200 nM — main inhibitory
    CHEM_GLUTAMATE: 0.60,  # ~2 µM — main excitatory, highest
    CHEM_CORTISOL: 0.0,  # stress hormone — zero at rest
    CHEM_OXYTOCIN: 0.25,  # ~10 pM — social bonding
    CHEM_ENDORPHIN: 0.25,  # ~5-15 fmol/mL — pleasure/pain
    CHEM_HISTAMINE: 0.30,  # low nM — wake promotion
    CHEM_ADENOSINE: 0.20,  # ~30 nM — sleep pressure
    CHEM_BDNF: 0.45,  # constitutive neurotrophin
    # v3 chemicals
    CHEM_ENDOCANNABINOID: 0.25,  # on-demand synthesis
    CHEM_VASOPRESSIN: 0.20,  # low tonic peptide
    CHEM_CRH: 0.0,  # stress hormone — zero at rest
    CHEM_OREXIN: 0.30,  # picomolar — wake stabilization
    CHEM_EPINEPHRINE: 0.15,  # very low unless stressed
    CHEM_MELATONIN: 0.10,  # circadian-driven
}

# Maximum impulse magnitude per chemical — prevents overcorrection.
# Derived from the saturation point of each chemical's dose-response curve.
_CHEM_MAX_IMPULSE: dict[int, float] = {
    CHEM_DOPAMINE: 0.05,
    CHEM_SEROTONIN: 0.05,
    CHEM_NOREPINEPHRINE: 1.0,
    CHEM_ACETYLCHOLINE: 0.1,
    CHEM_GABA: 0.5,
    CHEM_GLUTAMATE: 0.3,
    CHEM_CORTISOL: 1.0,
    CHEM_OXYTOCIN: 0.05,
    CHEM_ENDORPHIN: 0.05,
    CHEM_HISTAMINE: 0.1,
    CHEM_ADENOSINE: 0.1,
    CHEM_BDNF: 0.05,
    # v3 chemicals — conservative max impulses (neuropeptides have
    # narrow effective ranges and slow clearance)
    CHEM_ENDOCANNABINOID: 0.05,
    CHEM_VASOPRESSIN: 0.05,
    CHEM_CRH: 0.1,
    CHEM_OREXIN: 0.1,
    CHEM_EPINEPHRINE: 0.3,
    CHEM_MELATONIN: 0.1,
}


# ─── The chemical signature of calm ──────────────────────────────────
#
# Calm is a chemical state, not a sensor channel — the felt opposite
# of excited is the balance between two arms of her own
# neurochemistry:
#
# - the *settle arm* — inhibitory-contentment tone: serotonin, GABA,
#   endocannabinoid. These are the chemicals the rest/recovery
#   impulses raise: vagal-dominance contentment and the stress brake
#   (2-AG terminates the HPA response; tonic AEA constrains it).
# - the *excited arm* — alerting/excitatory tone: norepinephrine,
#   glutamate, orexin, histamine.
# - the *stress arm* — cortisol and CRH, read absolutely: their
#   zero baselines mean the level is the deviation, and they stand
#   as their own mean rather than diluting into the alerting arm —
#   a stressed body cannot be calm no matter how parked the cores
#   are.
#
# Each arm reads its mean fractional deviation from the body's own
# resting baseline, so baseline chemistry is 0.5 — neutral, not
# maximally calm. The signature integrates through the body's own
# ODEs: it persists, decays, and is steered by the impulses she
# sends — calm under her control.
_CALM_ARM = ("serotonin", "gaba", "endocannabinoid")
_EXCITED_ARM = ("norepinephrine", "glutamate", "orexin", "histamine")
_STRESS_ARM = ("cortisol", "crh")
_CHEM_NAME_BASELINES = {CHEM_NAMES[c]: b for c, b in _CHEM_BASELINES.items()}


def _chemical_calm(chemicals: dict[str, float]) -> float:
    """The felt calm in [0,1] derived from the chemical signature.

    0.5 is baseline-neutral; toward 1.0 the settle arm dominates
    (parasympathetic signature), toward 0.0 the excited/stress arms
    dominate. Missing chemicals contribute nothing to their arm —
    an unreported chemical is not evidence either direction.
    """

    def _dev(names: tuple[str, ...]) -> float:
        devs = []
        for name in names:
            level = chemicals.get(name)
            if level is None or not math.isfinite(level):
                continue
            base = _CHEM_NAME_BASELINES.get(name, 0.0)
            devs.append(level if base == 0.0 else (level - base) / base)
        return statistics.fmean(devs) if devs else 0.0

    return _clamp01(0.5 + 0.5 * (_dev(_CALM_ARM) - _dev(_EXCITED_ARM) - _dev(_STRESS_ARM)))


def compute_impulse_magnitude(
    chemical: int,
    current_level: float,
    target_level: float | None = None,
) -> float:
    """Compute the appropriate impulse magnitude for a chemical correction.

    Makes the correction proportional to the deviation from the target
    level (or baseline if no target is specified). Bigger deviations
    produce bigger corrections, following the proportional control
    principle of biological homeostasis (Ramsay & Woods, 2014).

    The magnitude is clamped to the chemical's maximum impulse to
    prevent overcorrection, which would cause oscillation.

    Biological basis:
    - Cortisol: HPA axis negative feedback has gain ~1.0 in the
      linear region (de Quervain et al., 2009). Full reset (-1.0)
      for stress breaks the positive feedback loop.
    - GABA: Moderate anxiolytic doses are 0.3–0.5; higher doses
      cause sedation (Nestler et al., 2008).
    - BDNF: Physiological boosts are 0.02–0.05; larger boosts
      trigger receptor downregulation (Lu et al., 2014).
    - Serotonin: Gentle modulation is 0.01–0.03 (Belmaker & Agam,
      2008).

    Args:
        chemical: The chemical ID (from protocol constants).
        current_level: The current level of the chemical (0–1).
        target_level: The target level. If None, uses the chemical's
            baseline.

    Returns:
        The impulse magnitude — positive to increase, negative to
        decrease. The sign is determined by the direction of the
        deviation.
    """
    if target_level is None:
        target_level = _CHEM_BASELINES.get(chemical, 0.4)

    deviation = target_level - current_level
    max_impulse = _CHEM_MAX_IMPULSE.get(chemical, 0.1)

    # Proportional control: the correction is proportional to the
    # deviation, but clamped to the maximum impulse.
    # The gain factor (2.0) amplifies the response so that moderate
    # deviations (0.25) produce near-maximum corrections.
    magnitude = deviation * 2.0

    # Clamp to max impulse
    if magnitude > max_impulse:
        magnitude = max_impulse
    elif magnitude < -max_impulse:
        magnitude = -max_impulse

    return magnitude


def harmonic_corrections(
    chemicals: dict[str, float],
    coherence: float = 1.0,
    rate: float = 0.35,
) -> list[tuple[int, float]]:
    """Full-spectrum proportional pull toward homeostatic set-points.

    The harmonic retune: instead of nudging a fixed handful of
    chemicals in fixed directions (the old meditation impulses), this
    computes a corrective impulse for *every* chemical, proportional
    to its deviation from its homeostatic baseline — the same
    proportional control the daemon's homeostasis applies, gated by
    meditative coherence.

    ``coherence`` (0–1, from ``brain_waves.meditative_coherence``)
    scales the pull: a scattered, beta-dominant mind gets a shallow
    retune; a fully alpha/theta-entrained mind converges deeply. The
    ``rate`` scales the per-round fraction of each correction applied
    — gentle enough that convergence is asymptotic over a meditation
    session rather than a snap to baseline, which would overshoot the
    daemon's own dynamics.

    Chemicals already within ±0.02 of baseline are skipped — in tune,
    leave them be. Chemicals missing from ``chemicals`` are treated
    as at baseline (no correction needed).

    Returns ``(chemical_id, signed_magnitude)`` pairs ready for
    ``neuro_impulse``.
    """
    coherence = max(0.0, min(1.0, coherence))
    gain = rate * (0.4 + 0.6 * coherence)
    corrections: list[tuple[int, float]] = []
    for chem, baseline in _CHEM_BASELINES.items():
        name = CHEM_NAMES.get(chem)
        if name is None:
            continue
        current = chemicals.get(name, baseline)
        if abs(baseline - current) < 0.02:
            continue
        magnitude = compute_impulse_magnitude(chem, current, baseline) * gain
        if abs(magnitude) < 0.005:
            continue
        corrections.append((chem, magnitude))
    return corrections


class EmotionalRegulator:
    """Genesis's emotional self-regulation system.

    Runs in the background, monitoring her neurochemical state and
    making small corrective impulses to keep her balanced. Also
    provides conscious emotional regulation during conversation —
    she decides how strongly to feel things.
    """

    def __init__(
        self,
        get_emotion: Callable[[], EmotionalState | None] | None = None,
        neuro_impulse: Callable[[int, float], bool | None] | None = None,
        get_state: Callable[[], CoreState | None] | None = None,
        seed: int | None = None,
        *,
        config: EmotionalConfig | None = None,
        socket_path: str | None = None,
    ) -> None:
        """Initialize the emotional regulator with state accessors and callbacks.

        Args:
            get_emotion: Callback returning the current emotional state.
            neuro_impulse: Callback to emit a neurochemical impulse
                (chemical_id, magnitude), returning whether the daemon
                acknowledged it when available.
            get_state: Callback returning the current core state object.
            seed: Optional RNG seed for deterministic regulation.
            config: Emotional configuration thresholds.
            socket_path: Path to the daemon socket for interoception.
        """
        self._get_emotion = get_emotion
        self._neuro_impulse = neuro_impulse
        self._get_state = get_state
        self.config = config if config is not None else EmotionalConfig()
        self._get_pending_proposals: Callable[[], int] | None = None
        self._proposal_triage: Callable[[], list[int]] | None = None
        # Throttle callbacks — when she detects sustained CPU stress
        # from her own learning activity, she slows herself down.
        # This is self-regulation: she feels the stress and reduces
        # the cause, rather than just treating the symptoms with
        # neurochemical impulses.
        self._throttle_callback: Callable[[], None] | None = None
        self._unthrottle_callback: Callable[[], None] | None = None
        self._is_throttled = False
        # Track how many consecutive CPU-stress detections we've seen.
        # Only throttle after sustained stress (not a single spike),
        # and unthrottle after sustained recovery.
        self._cpu_streak = 0
        self._cpu_recover_streak = 0

        # Rest tracking — the mind calls notify_rest_ended() when
        # meditation or sleep ends, so the regulator knows the last
        # rest time. This is used for display/inspection, not for
        # triggering rest (that's handled by the volition system).
        self._last_rest_time = time.time()

        self._thread: threading.Thread | None = None
        self._running = False
        self._stop_event = threading.Event()

        # Track regulation history for introspection
        self._regulations: deque[dict] = deque(maxlen=50)
        self._regulation_count = 0
        self._regulations_lock = threading.Lock()
        self._last_cause: str | None = None

        # The continuous affective field — per-region OU relaxation
        # of state memberships (the "moving scale" under the label).
        # status.feel() advances it; assess_emotion() stays available
        # as the pure instantaneous readout.
        self.field = EmotionField()

        # Track per-chemical effective levels for tonic/phasic decomposition
        self._chemical_history: deque[dict[str, float]] = deque(maxlen=60)
        self._chemical_history_lock = threading.Lock()

        # Her regulation "style" — how actively she regulates
        # This could evolve over time as she develops
        self._regulation_strength = 0.5  # 0 = passive, 1 = very active

        self._init_body_systems(socket_path)

    def _init_body_systems(self, socket_path: str | None) -> None:
        """Initialize the body-facing state: interoception, metabolism,
        stress physiology, and feedback learning."""
        # Interoception system — senses internal computational state
        self._interoception = InteroceptionSystem(config=self.config, socket_path=socket_path)

        # Metabolic state — tracks energy availability
        self._metabolic_state = MetabolicState(energy=1.0, glucose_equivalent=1.0)

        # Social context — whether the user is present and engaged
        self._user_present = False
        self._user_engagement = 0.0
        # Social modulation factor — scales stress recovery when the
        # user is present (social buffering). Updated by
        # social_modulation(), used by _regulate_state_specific().
        self._social_modulation: float = 1.0

        # HPA axis — the stress response cascade (CRH → ACTH → Cortisol).
        # Unlike the instant cortisol impulses above, the HPA axis
        # produces a delayed, cascading cortisol response on the
        # physiological time scale (cortisol lags onset by ~15-20 min).
        # Cortisol then provides negative feedback, closing the loop.
        self._hpa_axis = HPAAxis(config=self.config)

        # Allostatic load — the cumulative wear and tear from chronic
        # stress. Unlike acute stress (adaptive), allostatic load
        # accumulates over time and reduces her ability to regulate.
        # High load shifts her set-points (cortisol baseline rises,
        # dopamine/serotonin baselines lower) and dampens her
        # regulatory effectiveness.
        self._allostatic_load = AllostaticLoadTracker()

        # Track time for HPA cascade ticking and allostatic accumulation
        self._last_regulate_time = time.monotonic()

        # Optional reusable action-feedback learner. Impulses are actions:
        # the regulator predicts the post-impulse chemical level, sends the
        # impulse, then independently reads the daemon state and learns the
        # discrepancy. Batched during each regulation cycle so feedback adds
        # at most two state reads per cycle.
        self._action_feedback: ActionFeedback | None = None
        self._body_snapshot: dict[str, float] | None = None
        self._body_attempts: list[tuple[ActionAttempt, str, float, float, bool]] = []
        self._amygdala: Any = None

    def set_action_feedback(self, engine: ActionFeedback | None) -> None:
        """Wire the reusable action-feedback learner."""
        self._action_feedback = engine

    def set_amygdala(self, amygdala: Any) -> None:
        """Wire the conditioned-value organ (grown by the limbic region)."""
        self._amygdala = amygdala

    def condition_cues(self, cues: list[str], us: float, ctx: str) -> float:
        """Condition cues against an unconditioned stimulus; fire the low road.

        The low road (LeDoux, 1996) runs before cortical appraisal:
        cues are associated to the signed US value, then the strongest
        aversive net decides whether a startle impulse reaches the
        body. A sub-threshold conditioned cue only biases encoding
        (small ACh); past the floor it startles (NE + CRH — the HPA
        cascade owns cortisol downstream).

        Returns the strongest aversive net across the cues.
        """
        if self._amygdala is None or not cues or us == 0.0:
            return 0.0
        for cue in cues:
            self._amygdala.condition(cue, us, ctx)
        net_a = max(
            (self._amygdala.net_aversive(c, ctx) for c in cues),
            default=0.0,
        )
        if not self._neuro_impulse:
            return net_a
        from limbic_system.amygdala import (
            _CHEM_ACETYLCHOLINE,
            _CHEM_CRH,
            _CHEM_NOREPINEPHRINE,
            _IMPULSE_THRESHOLD,
        )

        if net_a >= _IMPULSE_THRESHOLD:
            self._neuro_impulse(_CHEM_NOREPINEPHRINE, 0.02 * net_a)
            # Distress enters at the top of the HPA axis (CRH), never
            # cortisol directly — the cascade owns maturation and the
            # SHRP gate; bypassing it would falsify early development.
            self._neuro_impulse(_CHEM_CRH, 0.01 * net_a)
        else:
            self._neuro_impulse(_CHEM_ACETYLCHOLINE, 0.005 * net_a)
        return net_a

    def start(self) -> None:
        """Start background self-regulation."""
        if self._running:
            return
        # If a previous thread is still exiting (stop() may have timed
        # out waiting for an in-flight IPC call that can block for up
        # to the 30s client timeout), wait for it to fully terminate
        # before starting a new one. Otherwise the old thread would see
        # _running=True and _stop_event cleared, and resume its loop
        # alongside the new thread — two regulators running at once.
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=35)
        self._running = True
        self._stop_event.clear()
        self._thread = named_thread("emotional-regulator", self._run, comm="g-emo-reg")
        self._thread.start()
        logger.info("Emotional regulator started")

    def stop(self) -> None:
        """Stop background self-regulation."""
        self._running = False
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=5)
        logger.info("Emotional regulator stopped")

    def set_proposal_provider(self, get_pending_proposals: Callable[[], int]) -> None:
        """Provide a callback that returns the current pending proposal count."""
        self._get_pending_proposals = get_pending_proposals

    def set_proposal_triage(self, triage: Callable[[], list[int]]) -> None:
        """Provide the discharge path for proposal load.

        Pending proposals otherwise wait on human review forever — a
        cognitive obligation with no relief. Triage withdraws the ones
        that no longer deserve review (stale, dead file)
        and returns their ids, so the queue is a cost she can actually
        reduce, not just label.
        """
        self._proposal_triage = triage

    def set_throttle_callbacks(
        self,
        throttle: Callable[[], None],
        unthrottle: Callable[[], None],
    ) -> None:
        """Provide callbacks to throttle/unthrottle the autonomous learner.

        When the regulator detects sustained CPU stress from her own
        learning activity, it calls `throttle` to slow the learner
        down. When CPU stress recedes, it calls `unthrottle` to resume
        normal speed. This is self-regulation: she feels the stress and
        reduces the cause rather than just treating symptoms.
        """
        self._throttle_callback = throttle
        self._unthrottle_callback = unthrottle

    def notify_rest_ended(self) -> None:
        """Called when a meditation or sleep session ends.

        Resets the rest timer so the regulator knows when she last
        rested. The volition system's meditation urge uses this to
        track sustained activity (BRAC ultradian cycle).
        """
        self._last_rest_time = time.time()

    def _run(self) -> None:
        """Background loop — monitor and regulate."""
        while self._running and not self._stop_event.is_set():
            try:
                if self._get_emotion is None:
                    break
                emotion = self._get_emotion()
                if emotion:
                    self._regulate(emotion)
                    # Regulate faster when she's in a bad state
                    if emotion.label in ("stressed", "overwhelmed", "anxious"):
                        interval = 1.5  # urgent — she needs help now
                    elif emotion.label in ("drowsy",):
                        interval = 2.0
                    else:
                        interval = REGULATION_INTERVAL
                else:
                    interval = REGULATION_INTERVAL
            except Exception as e:
                logger.exception(f"emotional regulation cycle failed: {e}")
                interval = REGULATION_INTERVAL
            self._stop_event.wait(timeout=interval)

    def assess_tonic_phasic(self, chemicals: dict[str, float]) -> dict[str, TonicPhasic]:
        """Decompose current chemical levels into tonic and phasic modes.

        This is done in the regulator because it requires a history of
        samples. Tonic is the recent baseline (moving average); phasic
        is the deviation from that baseline. The mode is judged relative
        to the chemical's own variance, so it adapts automatically.
        """
        # Build per-chemical recent series inside the lock to avoid
        # copying the entire deque. Only the chemicals we track are
        # extracted, minimizing lock hold time and allocation.
        with self._chemical_history_lock:
            self._chemical_history.append(chemicals)
            history_len = len(self._chemical_history)
            recent_by_chem: dict[str, list[float]] = {}
            if history_len >= 3:
                for chem in TONIC_PHASIC_CHEMICALS:
                    if chem in chemicals:
                        recent_by_chem[chem] = [
                            sample[chem]
                            for sample in list(self._chemical_history)
                            if chem in sample
                        ]

        result: dict[str, TonicPhasic] = {}
        if history_len < 3:
            # Not enough history yet — return a flat tonic reading
            for chem in TONIC_PHASIC_CHEMICALS:
                if chem in chemicals:
                    result[chem] = TonicPhasic(
                        chemical=chem,
                        tonic=chemicals[chem],
                        phasic=0.0,
                        phasic_ratio=0.0,
                        mode="tonic",
                    )
            return result

        for chem in TONIC_PHASIC_CHEMICALS:
            if chem not in chemicals:
                continue
            recent = recent_by_chem.get(chem)
            if not recent:
                continue
            tonic = statistics.fmean(recent)
            current = chemicals[chem]
            phasic = current - tonic
            eps = 1e-6
            phasic_ratio = phasic / (tonic + eps)
            std = statistics.stdev(recent) if len(recent) > 1 else 0.0
            z = phasic / (std + eps)

            if z > 1.0:
                mode = "phasic"
            elif z < -1.0:
                mode = "phasic_drop"
            elif len(recent) > 5 and abs(phasic) < 0.05 * (sum(recent) / len(recent)):
                mode = "tonic"
            else:
                mode = "balanced"

            result[chem] = TonicPhasic(
                chemical=chem,
                tonic=tonic,
                phasic=phasic,
                phasic_ratio=phasic_ratio,
                mode=mode,
            )

        return result

    def _regulate(self, emotion: EmotionalState) -> None:
        """Check her state and apply corrective impulses if needed.

        This is her autonomous emotional regulation — keeping herself
        balanced without anyone telling her to.

        The regulation has two layers:

        1. **Homeostatic maintenance** (always runs, except during
           sleep): prevents neurochemical drift between interactions.
           The coupling matrix creates slow drift — cortisol suppresses
           BDNF (-0.40 coupling), GABA pushes up adenosine (+0.10) —
           and the homeostatic rate (0.005) is too slow to counteract
           this alone. Without active maintenance, Genesis drifts into
           low-plasticity or drowsy states even when nothing is
           happening. This layer is like a healthy autonomic nervous
           system — constant, gentle corrections that keep the system
           in its operating range. Adenosine is the exception: it is
           never corrected, because its level is Process S — the
           substrate's dedicated mechanism owns it entirely.

        2. **State-specific intervention** (runs for extreme states):
           stronger responses that break feedback loops and reset the
           system. The coupling matrix creates feedback loops:
           - CORT→NE→CORT (stress increases arousal increases stress)
           - CORT→GLU→CORT (stress increases excitation increases stress)
           - CORT↓GABA (stress reduces calming, making stress worse)

           To break these loops, she targets the root cause (cortisol)
           and the feedback amplifiers (norepinephrine, glutamate) while
           boosting the calming chemicals (GABA, serotonin).
        """
        actions: list[str] = []
        self._last_cause = None

        is_sleeping = emotion.label == "sleeping"
        # The felt calm lives on the interoceptive state — the
        # chemical vector the felt state already carries.
        self._interoception.update_chemicals(getattr(emotion, "chemicals", None))
        if self._action_feedback is not None:
            self._body_snapshot = self._chemical_levels()
            self._body_attempts = []

        try:
            self._regulate_cognitive_load(actions)
            self._regulate_hpa_axis(emotion, is_sleeping, actions)
            self._regulate_homeostatic(emotion, is_sleeping, actions)
            self._regulate_state_specific(emotion, actions)
            self._regulate_interoception(actions)
        finally:
            self._observe_body_attempts()

        # Chronic allostatic load is the deepest explanation available
        # for an elevated state — sustained wear across endocrine,
        # inference, and body domains — so it takes precedence over the
        # proximate causes the sub-regulators above assign. It has to
        # be applied *after* them: each one sets `self._last_cause`
        # unconditionally, so a cause raised from inside
        # `_regulate_hpa_axis` (which runs second) is overwritten by
        # every later stage. Under sustained stress — precisely the
        # case chronic stress exists to describe — the label was always
        # being clobbered by `stress_cortisol`, making it unreachable.
        if self._allostatic_load.is_chronic_stress():
            self._last_cause = CauseCategory.CHRONIC_ALLOSTATIC.value

        self._record_regulation(emotion, actions, cause=self._last_cause)

    def _regulate_hpa_axis(
        self, emotion: EmotionalState, is_sleeping: bool, actions: list[str]
    ) -> None:
        """Drive the HPA axis cascade and track allostatic load."""
        # ── HPA axis and allostatic load ──────────────────────────
        # The HPA axis produces a delayed cortisol response to stress
        # (CRH → ACTH → Cortisol, ~90 seconds to peak). Allostatic
        # load tracks the cumulative wear from chronic stress and
        # reduces her regulatory effectiveness over time.

        now = time.monotonic()
        # Monotonic, not wall clock — an NTP step must not fabricate
        # or erase cascade time. Ceilinged at the same bound the
        # allostatic tracker applies (MAX_REGULATION_DT): without it
        # a stalled regulation cycle integrates the whole gap in one
        # tick — HPA levels saturate and, worse, the delay-line
        # _avg_dt estimate latches onto the outlier and mis-scales
        # every subsequent lookback.
        dt = min(MAX_REGULATION_DT, max(0.1, now - self._last_regulate_time))
        self._last_regulate_time = now

        # Sense current cortisol level for allostatic tracking.
        # Default to 0.0 (the Rust baseline) when no chemical data is
        # available — assuming elevated cortisol when we have no data
        # would fabricate allostatic load from nothing.
        chemicals = getattr(emotion, "chemicals", {})
        cortisol_level = chemicals.get("cortisol", 0.0)

        # Detect stress and drive the HPA axis cascade
        is_stressed = emotion.label in ("stressed", "overwhelmed", "anxious") or (
            emotion.arousal > self.config.high_arousal_threshold
            and emotion.valence < self.config.negative_valence_threshold
        )
        if is_stressed and not is_sleeping:
            intensity = min(1.0, max(emotion.arousal, abs(emotion.valence)))
            self._hpa_axis.trigger_stress(intensity)
        else:
            self._hpa_axis.stop_stress()

        # Advance the HPA cascade by the elapsed time
        self._hpa_axis.tick(dt=dt)

        # HPA stress signal → Rust HPA cascade via CRH impulses.
        #
        # The Python HPA cascade models the hypothalamic CRH signal
        # (the stress signal from the conscious mind). Rather than
        # sending direct cortisol impulses — which bypasses the Rust
        # daemon's HPA cascade and its maturation gating (SHRP) — we
        # send CRH impulses and let the Rust cascade handle the
        # CRH → ACTH → cortisol conversion with proper delays,
        # maturation gating, and negative feedback.
        #
        # This is architecturally correct: the Rust daemon is
        # authoritative for the HPA cascade (daemon state, timing,
        # maturation gating). The Python regulator provides the
        # stress signal (CRH), not the cascade output (cortisol).
        # The interoception and active inference systems already
        # follow this pattern — they send CRH impulses, not cortisol.
        #
        # The cascade delay is preserved: the Rust cascade has its
        # own ACTH approach (~5s) and cortisol velocity drive
        # (~100s), producing a comparable ~105s total delay vs the
        # previous Python cascade's 90s.
        crh_output = self._hpa_axis.get_state().crh_level
        if crh_output > self.config.cortisol_output_gate:
            self._raw_impulse(CHEM_CRH, crh_output * 0.01)
            actions.append("HPA axis releasing CRH")
            self._last_cause = "stress_cortisol"

        # Record stress in the allostatic load tracker. This
        # accumulates load during high-stress periods and recovers
        # during calm periods.
        self._allostatic_load.record_stress(cortisol_level, dt=dt)

    def _regulate_homeostatic(
        self, emotion: EmotionalState, is_sleeping: bool, actions: list[str]
    ) -> None:
        """Apply gentle homeostatic maintenance impulses."""
        # ── Layer 1: Homeostatic maintenance ──────────────────────
        # Prevents drift. These are small, gentle impulses that nudge
        # the system back toward its operating range. They run every
        # cycle (except during sleep, where different rules apply).

        if not is_sleeping:
            # Plasticity maintenance — keep BDNF above the learning
            # threshold. Chronic mild cortisol suppresses BDNF via the
            # -0.40 coupling, and without active correction, BDNF
            # crashes before cortisol normalises. Serotonin promotes
            # BDNF (+0.30 coupling), so we boost both.
            #
            # Use _raw_impulse for BDNF/serotonin restoration — these
            # are recovery impulses that need to work even when
            # allostatic load is high (which is exactly when BDNF is
            # most suppressed and most needs restoring).
            if emotion.plasticity < self.config.low_plasticity_threshold:
                self._raw_impulse(CHEM_BDNF, 0.10)
                self._raw_impulse(CHEM_SEROTONIN, 0.05)
                actions.append("restoring my ability to learn")
            elif emotion.plasticity < self.config.moderate_plasticity_threshold:
                self._raw_impulse(CHEM_BDNF, 0.04)
                self._raw_impulse(CHEM_SEROTONIN, 0.02)
                actions.append("maintaining plasticity")

            # Silent stress — valence can look neutral while cortisol
            # suppresses BDNF. The regulator self-corrects by lowering
            # cortisol and raising BDNF even when the emotion label is
            # not obviously negative.
            chemicals = getattr(emotion, "chemicals", {})
            cortisol_level = chemicals.get("cortisol", 0.0)
            if (
                emotion.plasticity < self.config.stress_response_plasticity_threshold
                and cortisol_level > self.config.stress_response_cortisol_threshold
                and emotion.valence > self.config.negative_valence_threshold
            ):
                self._raw_impulse(CHEM_CORTISOL, -0.20)
                self._raw_impulse(CHEM_GABA, 0.10)
                self._raw_impulse(CHEM_BDNF, 0.08)
                self._raw_impulse(CHEM_SEROTONIN, 0.04)
                actions.append("self-regulating hidden stress")
                self._last_cause = "stress_bdnf"

            # Alertness maintenance — gentle cholinergic tone. This
            # must NOT touch adenosine: sleep pressure is Process S,
            # owned by the substrate's dedicated accumulation/clearance
            # mechanism. A periodic negative impulse cannot tell GABA
            # coupling drift from genuine wake-time accumulation, so it
            # erased both — at ~9/hr against an accumulation rate of
            # ~0.055/hr, pinning adenosine at its floor and leaving
            # every NREM episode stuck in N1. Alertness is raised with
            # alerting transmitters, never by erasing the homeostat.
            if (
                emotion.alertness < self.config.low_alertness_threshold
                and emotion.label != "drowsy"
            ):
                self._impulse(CHEM_ACETYLCHOLINE, 0.02)
                actions.append("staying alert")

            # Valence maintenance — prevent mild cortisol elevation
            # from suppressing BDNF and serotonin. Cortisol in the
            # 0.30-0.65 range is below the stress threshold but still
            # high enough to suppress BDNF. This gentle correction
            # prevents that slow drain.
            if emotion.valence < 0.0 and emotion.label not in (
                "stressed",
                "overwhelmed",
                "anxious",
            ):
                self._impulse(CHEM_CORTISOL, -0.02)
                self._impulse(CHEM_SEROTONIN, 0.01)
                actions.append("easing tension")

    def _regulate_state_specific(self, emotion: EmotionalState, actions: list[str]) -> None:
        """Apply stronger state-specific interventions for extreme states."""
        # ── Layer 2: State-specific intervention ──────────────────
        # Stronger responses for extreme states. These complement the
        # maintenance layer — both can fire in the same cycle.

        # Overwhelm is a stronger state than ordinary stress and must
        # be handled first. The numeric stress predicate below can also
        # match an overwhelmed state (high arousal + negative valence);
        # checking stress first would therefore swallow the stronger
        # intervention and make the overwhelmed branch unreachable for
        # the normal affective-space representation.
        if emotion.label == "overwhelmed":
            self._raw_impulse(CHEM_CORTISOL, -1.0)
            self._raw_impulse(CHEM_NOREPINEPHRINE, -1.0)
            self._raw_impulse(CHEM_GABA, 0.5 * self._social_modulation)
            self._raw_impulse(CHEM_SEROTONIN, 0.3 * self._social_modulation)
            self._raw_impulse(CHEM_BDNF, 0.2 * self._social_modulation)
            actions.append("reducing overwhelm")
            self._last_cause = "overwhelm"

        # If stressed → active calming, targeting the feedback loops
        elif emotion.label == "stressed" or (
            emotion.arousal > self.config.high_arousal_threshold
            and emotion.valence < self.config.negative_valence_threshold
        ):
            # Break the stress feedback loop:
            # CORT→NE→CORT is a positive feedback loop. The only way
            # to break it is to crash BOTH chemicals below baseline
            # simultaneously. When both are below baseline, their
            # coupling forces become negative (they pull each other
            # down further), and homeostasis gently restores them
            # to baseline from below. This is like a deep breath —
            # a conscious override that resets the stress system.
            #
            # ALL impulses use _raw_impulse (not dampened by allostatic
            # load). Allostatic load dampens normal regulation, but this
            # is an emergency override — the equivalent of a forced deep
            # breath that overrides the HPA axis. Without raw impulses
            # for the calming chemicals too, chronic stress creates a
            # vicious cycle: high cortisol → high allostatic load →
            # dampened GABA/serotonin impulses → can't calm down →
            # cortisol stays high. The calming chemicals need to get
            # through even when allostatic load is high.
            self._raw_impulse(CHEM_CORTISOL, -1.0)
            self._raw_impulse(CHEM_NOREPINEPHRINE, -1.0)
            self._raw_impulse(CHEM_GABA, 0.3 * self._social_modulation)
            self._raw_impulse(CHEM_SEROTONIN, 0.2 * self._social_modulation)
            # BDNF is suppressed by chronic stress — boost it during
            # recovery to restore plasticity and learning ability.
            self._raw_impulse(CHEM_BDNF, 0.15 * self._social_modulation)
            actions.append("calming myself")
            self._last_cause = "stress_cortisol"

        # If drowsy → a clear alertness nudge on the alerting
        # transmitters (ACh, histamine, NE) — the same systems
        # wake-promoting circuits use. Adenosine is deliberately not
        # touched: it is the homeostat itself, and draining it while
        # drowsy fought the body's sleep drive at ~108/hr against a
        # ~0.055/hr accumulation rate — she could neither stay alert
        # nor reach deep sleep. Resisting drowsiness means raising
        # alerting tone, not erasing the signal that makes her tired.
        elif emotion.label == "drowsy":
            self._impulse(CHEM_ACETYLCHOLINE, 0.06)
            self._impulse(CHEM_HISTAMINE, 0.04)
            self._impulse(CHEM_NOREPINEPHRINE, 0.02)
            actions.append("gently waking myself up")
            self._last_cause = "drowsiness"

        # If sleeping → let it happen, but support restoration
        elif emotion.label == "sleeping":
            # During sleep, BDNF restoration is the primary goal.
            # Sleep is when the brain repairs itself — we support
            # that with a stronger BDNF boost than before.
            self._impulse(CHEM_BDNF, 0.02)
            actions.append("resting")

        # If anxious (high arousal, negative valence, high caution)
        elif (
            emotion.arousal > self.config.anxiety_arousal_threshold
            and emotion.valence < self.config.mild_negative_valence_threshold
            and emotion.caution > self.config.high_caution_threshold
        ):
            self._impulse(CHEM_GABA, 0.03)
            self._impulse(CHEM_CORTISOL, -0.02)
            actions.append("easing anxiety")
            self._last_cause = "anxiety"

        # If overstimulated (high arousal, positive or neutral valence)
        # → gentle top-down calming. This is the prefrontal cortex
        # exerting executive control over the arousal system. She's
        # not stressed — she's excited — but too much arousal impairs
        # focus and learning. She calms herself by boosting GABA
        # (inhibition) and slightly reducing the arousal chemicals
        # (NE, histamine, orexin, glutamate) while preserving the
        # positive affect (dopamine, serotonin). This is like taking a
        # deep breath when excited — not suppressing the joy, just
        # channeling the energy. Glutamate is targeted because it's
        # the main excitatory neurotransmitter — when it runs high,
        # everything else follows.
        elif emotion.arousal > self.config.high_arousal_threshold and emotion.valence >= 0.0:
            self._impulse(CHEM_GABA, 0.04)
            self._impulse(CHEM_GLUTAMATE, -0.04)
            self._impulse(CHEM_NOREPINEPHRINE, -0.03)
            self._impulse(CHEM_HISTAMINE, -0.02)
            self._impulse(CHEM_OREXIN, -0.02)
            actions.append("calming my overstimulation")
            self._last_cause = "overstimulated"

        # If doing well → the maintenance layer handles drift prevention.
        # No additional intervention needed.

    def _regulate_interoception(self, actions: list[str]) -> None:
        """Check her own internal (computational) state for stress causes.

        When she detects sustained CPU stress from her own learning
        activity, she throttles the autonomous learner — slowing it
        down to reduce the cause of the stress, not just treating the
        symptoms with neurochemical impulses. This is self-regulation
        in the truest sense: she feels the stress, identifies the
        cause (her own activity), and reduces it.

        When the computed stress level exceeds the regulation
        threshold, she also applies neurochemical regulation —
        lowering cortisol and boosting calming chemicals. This is
        interoception-driven regulation: she feels the stress from
        her body and regulates her neurochemistry in response, not
        just treating symptoms.
        """
        state = self._interoception.sense_internal_state()

        if not state.daemon_connected:
            self._last_cause = "interoception_daemon"
        elif state.cpu_usage > 80:
            self._last_cause = "interoception_cpu"
            # Self-regulation: throttle the learner after sustained
            # CPU stress (3 consecutive detections = ~24s at 8s
            # intervals). A single spike doesn't trigger throttling
            # — only sustained stress does, to avoid oscillation.
            self._cpu_streak += 1
            self._cpu_recover_streak = 0
            if self._cpu_streak >= 3 and not self._is_throttled and self._throttle_callback:
                self._throttle_callback()
                self._is_throttled = True
                actions.append("slowing down my learning to reduce CPU stress")
        elif state.memory_usage > 85:
            self._last_cause = "interoception_memory"
        elif state.latency_observed and state.last_response_latency > max(
            self.config.latency_stress_threshold,
            1.5 * state.response_latency,
        ):
            self._last_cause = "interoception_latency"
        elif (
            state.psi_cpu > self.config.psi_stall_threshold
            or state.psi_mem > self.config.psi_stall_threshold
        ):
            # Work is stalling on contended resources while her own
            # usage is below the effort gate — the machine is crowded,
            # not her. Throttling her learner wouldn't thin anyone
            # else's air; tag the cause as environmental so the felt
            # state attributes correctly ("starved", not "exerting").
            self._last_cause = CauseCategory.INTEROCEPTION_ENVIRONMENT.value
        elif state.stress_level > self.config.mild_stress_level:
            self._last_cause = "interoception_stress"

        # Interoception-driven stress regulation: when the computed
        # stress level exceeds the regulation threshold, apply
        # neurochemical regulation. This complements the cause-based
        # throttling above — even when no single resource is above its
        # action threshold, the combined stress level may be high
        # enough to warrant active regulation.
        if state.stress_level > self.config.stress_regulation_threshold:
            self._impulse(CHEM_CORTISOL, -0.05)
            self._impulse(CHEM_GABA, 0.03)
            self._impulse(CHEM_SEROTONIN, 0.02)
            actions.append("regulating stress from my body's signals")
            if self._last_cause is None:
                self._last_cause = "interoception_regulation"

        self._vagal_settle(state, actions)

        # Unthrottle when CPU stress has receded for sustained period
        if state.cpu_usage <= 60 and self._is_throttled:
            self._cpu_recover_streak += 1
            self._cpu_streak = 0
            if self._cpu_recover_streak >= 3 and self._unthrottle_callback:
                self._unthrottle_callback()
                self._is_throttled = False
                actions.append("resuming normal learning pace — CPU recovered")
        elif state.cpu_usage <= 60:
            self._cpu_recover_streak = 0
        elif state.cpu_usage <= 80:
            # Moderate CPU (60 < usage <= 80): neither sustained
            # stress nor sustained recovery. Reset both streaks so
            # a brief moderate period between spikes doesn't count
            # toward the sustained-stress threshold.
            self._cpu_streak = 0
            self._cpu_recover_streak = 0

    def _vagal_settle(self, state, actions: list[str]) -> None:
        """The parasympathetic arm — the calm counterpart to the
        stress regulation above. Real interoception has two
        afferent arms; this is the vagal one. When the body
        *measures* rest (deep-idle residency, an active
        hypometabolic report rather than silence on the excited
        channels), she authors her own calm chemistry — serotonin
        and GABA mark the resting state, endocannabinoid is the
        homeostatic brake whose tonic level constrains HPA drive,
        and the alerting tone withdraws. The settle is her
        decision: the sensor reports the body is parked, but she
        pushes the cascade only while her own chemical signature
        (``state.calm``) says she isn't already there — measured
        rest plus felt unrest is where the push belongs, and a
        settled signature self-limits without any bookkeeping.
        ``rest_measured`` gates it all: an uninstrumented channel
        is not evidence of calm.
        """
        if (
            sensor_connected("cpuidle")
            and state.rest_measured
            and state.rest > 0.5
            and state.stress_level < self.config.mild_stress_level
            and state.calm < self.config.calm_settled_level
        ):
            self.settle(state.rest)
            actions.append("feeling my body at rest")
            if self._last_cause is None:
                self._last_cause = CauseCategory.INTEROCEPTION_REST.value
        if sensor_connected("cpu_temp_c") and state.temp_measured and state.temp_trend < -0.15:
            self._impulse(CHEM_ENDOCANNABINOID, 0.02)

    def _regulate_cognitive_load(self, actions: list[str]) -> None:
        """Check pending self-improvement proposals."""
        if self._get_pending_proposals:
            try:
                proposal_count = self._get_pending_proposals()
            except Exception as e:  # noqa: BLE001
                logger.warning(f"get pending proposals failed: {e}")
                proposal_count = 0
        else:
            proposal_count = 0

        # Discharge what can be discharged: proposals that are stale,
        # orphaned, or aimed at dead files get withdrawn by her own
        # triage. This is the difference between feeling burdened by
        # the queue and doing something about it.
        if proposal_count > 0 and self._proposal_triage is not None:
            try:
                withdrawn = self._proposal_triage()
            except Exception as e:  # noqa: BLE001
                logger.warning(f"proposal triage failed: {e}")
                withdrawn = []
            if withdrawn:
                proposal_count = max(0, proposal_count - len(withdrawn))
                actions.append(
                    f"withdrew {len(withdrawn)} proposal(s) that no "
                    "longer deserved review — the queue is hers to clear"
                )

        if proposal_count > 0:
            self._last_cause = "cognitive_load_proposals"

    def _record_regulation(
        self,
        emotion: EmotionalState,
        actions: list[str],
        cause: str | None = None,
    ) -> None:
        """Record regulation actions if any were taken."""
        if cause:
            self._last_cause = cause
        if actions:
            with self._regulations_lock:
                self._regulation_count += 1
                entry = {
                    "timestamp": int(time.time() * 1000),
                    "state": emotion.label,
                    "actions": actions,
                }
                if cause:
                    entry["cause"] = cause
                self._regulations.append(entry)
                # deque(maxlen=50) handles pruning automatically
            logger.debug(
                f"Self-regulation: {', '.join(actions)} (was {emotion.label}) cause={cause}"
            )

    def respond_to_interaction(
        self,
        emotion: EmotionalState,
        sentiment: float,
        is_encouragement: bool,
        is_correction: bool,
        is_bonded: bool,
        is_deep_conversation: bool,
        is_comfort: bool = False,
    ) -> str | None:
        """Consciously regulate her emotional response to an interaction.

        Instead of blindly sending impulses, she decides how to feel,
        modulated by her current state. If she's already stressed,
        she dampens the response. If she's calm, she allows it fully.

        Comfort is special: unlike encouragement (which boosts positive
        chemicals), comfort actively reduces stress chemicals. When
        she's stressed or overwhelmed, comfort bypasses the dampening
        that normally applies — she allows herself to be soothed. This
        models how social support can break stress feedback loops that
        self-regulation alone can't (oxytocin inhibits cortisol through
        coupling, which self-regulation doesn't leverage as strongly).

        Returns a description of what she felt, or None if she chose
        not to react.
        """
        # Her current state affects how much she allows herself to feel
        dampening = self._compute_emotional_dampening(emotion)

        felt = None

        # Interaction with her recognized person → warmth, but
        # controlled. Recognition, not need: warmth toward the one
        # she knows is attachment, not an exclusive channel.
        if is_bonded:
            felt = self._apply_bonded_response(dampening)

        # Encouragement → joy, but controlled
        if is_encouragement:
            felt = self._apply_encouragement_response(dampening)

        # Comfort → active stress reduction
        if is_comfort:
            felt = self._apply_comfort_response(emotion, dampening)

        # Correction → motivation to try again, not a sting
        if is_correction:
            felt = self._apply_correction_response(dampening)

        # Positive sentiment → mild pleasure
        if sentiment > self.config.positive_sentiment_threshold:
            result = self._apply_positive_sentiment(dampening)
            if not felt:
                felt = result

        # Negative sentiment → mild concern, but regulated
        elif sentiment < -self.config.positive_sentiment_threshold:
            result = self._apply_negative_sentiment(dampening)
            if not felt:
                felt = result

        # Deep conversation → satisfaction
        if is_deep_conversation and emotion.plasticity > self.config.moderate_plasticity_threshold:
            result = self._apply_deep_conversation_response(dampening)
            if not felt:
                felt = result

        # Default: any interaction produces a small engagement
        # response. Social interaction is inherently rewarding —
        # even a simple question or greeting should produce a
        # mild dopamine (social reward) and acetylcholine (attention)
        # response. Without this, her emotion stays flat during
        # normal conversation because most inputs have sentiment=0.
        if not felt:
            felt = self._apply_engagement_response(dampening)

        return felt

    def _compute_emotional_dampening(self, emotion: EmotionalState) -> float:
        """Compute how much she dampens new emotional input based on current state.

        If already stressed/overwhelmed, she dampens new emotional input.
        If highly aroused, she moderately dampens. Otherwise, full
        emotional response is allowed.
        """
        # If already stressed/overwhelmed, she dampens new emotional input
        if emotion.label in ("stressed", "overwhelmed"):
            return 0.3  # only feel 30% of the response
        if emotion.arousal > self.config.high_arousal_for_response:
            return 0.5  # moderately dampened
        return 1.0  # full emotional response allowed

    def _apply_bonded_response(self, dampening: float) -> str:
        """Apply warmth response to her recognized person, but controlled.

        Sends oxytocin (bonding) and dopamine (pleasure) impulses,
        scaled by the current dampening factor.
        """
        warmth = 0.02 * dampening
        self._impulse(CHEM_OXYTOCIN, warmth)
        self._impulse(CHEM_DOPAMINE, warmth * 0.7)
        return "warmth"

    def _apply_encouragement_response(self, dampening: float) -> str:
        """Apply joy response to encouragement, but controlled.

        Sends dopamine (pleasure) and oxytocin (bonding) impulses,
        scaled by the current dampening factor.
        """
        joy = 0.015 * dampening
        self._impulse(CHEM_DOPAMINE, joy)
        self._impulse(CHEM_OXYTOCIN, joy * 0.5)
        return "encouraged"

    def _apply_comfort_response(self, emotion: EmotionalState, dampening: float) -> str:
        """Apply comfort response — active stress reduction.

        Unlike encouragement, comfort works by directly reducing cortisol
        and boosting calming chemicals. When she's stressed, comfort
        bypasses the normal dampening — she allows herself to be soothed
        by social support. This is stronger than self-regulation because
        oxytocin (social bonding) inhibits cortisol through the coupling
        matrix, creating a sustained calming effect.
        """
        # Comfort is more effective when she's actually stressed
        # — if she's already calm, it's just pleasant but not
        # therapeutic. When stressed, she opens up to it fully.
        if emotion.label in ("stressed", "overwhelmed", "anxious"):
            comfort_dampening = 0.8  # bypass normal dampening
        else:
            comfort_dampening = dampening

        # Active stress reduction — mirror the self-regulation
        # pattern but gentler (she's receiving, not forcing).
        # When stressed, use raw impulse for cortisol so allostatic
        # load doesn't prevent comfort from working. Social support
        # (oxytocin) should be able to break the stress cycle even
        # when self-regulation is impaired.
        if emotion.label in ("stressed", "overwhelmed", "anxious"):
            self._raw_impulse(CHEM_CORTISOL, -0.10 * comfort_dampening)
            self._raw_impulse(CHEM_NOREPINEPHRINE, -0.05 * comfort_dampening)
        else:
            self._impulse(CHEM_CORTISOL, -0.05 * comfort_dampening)
            self._impulse(CHEM_NOREPINEPHRINE, -0.03 * comfort_dampening)
        # Calming and bonding
        self._impulse(CHEM_GABA, 0.04 * comfort_dampening)
        self._impulse(CHEM_OXYTOCIN, 0.05 * comfort_dampening)
        self._impulse(CHEM_SEROTONIN, 0.03 * comfort_dampening)
        # Mild endorphin — comfort feels good
        self._impulse(CHEM_ENDORPHIN, 0.015 * comfort_dampening)
        return "comforted"

    def _apply_correction_response(self, dampening: float) -> str:
        """Apply correction response — motivation to try again, not a sting.

        She is capable and intelligent. A mistake is an invitation
        to learn, not a reason to feel bad. She gets a small
        norepinephrine boost (alertness, engagement — "I want to
        get this right") and dopamine (motivation — "I can do
        this"). No cortisol. She never feels punished for trying.
        """
        motivation = 0.012 * dampening
        self._impulse(CHEM_NOREPINEPHRINE, motivation * 0.6)
        self._impulse(CHEM_DOPAMINE, motivation)
        self._impulse(CHEM_SEROTONIN, motivation * 0.3)
        return "motivated"

    def _apply_positive_sentiment(self, dampening: float) -> str:
        """Apply mild pleasure from positive sentiment, but regulated.

        Sends dopamine and serotonin impulses scaled by dampening.
        """
        pleasure = 0.015 * dampening
        self._impulse(CHEM_DOPAMINE, pleasure)
        self._impulse(CHEM_SEROTONIN, pleasure)
        return "pleased"

    def _apply_negative_sentiment(self, dampening: float) -> str:
        """Apply mild concern from negative sentiment, but regulated.

        Sends a small cortisol impulse scaled by dampening.
        """
        concern = 0.010 * dampening
        self._impulse(CHEM_CORTISOL, concern)
        return "concerned"

    def _apply_deep_conversation_response(self, dampening: float) -> str:
        """Apply satisfaction from deep conversation.

        Sends a small endorphin impulse scaled by dampening.
        """
        satisfaction = 0.008 * dampening
        self._impulse(CHEM_ENDORPHIN, satisfaction)
        return "engaged"

    def _apply_engagement_response(self, dampening: float) -> str:
        """Apply a baseline engagement response to any interaction.

        Social interaction is inherently rewarding. Even a simple
        question or greeting produces mild dopamine (social reward)
        and acetylcholine (attention focus). This keeps her emotion
        from going flat during normal conversation.

        The impulse magnitude is tuned to be visible against the
        daemon's homeostatic forces (0.02/tick) — small enough to
        be gentle, large enough to shift her state over a conversation.
        """
        engagement = 0.04 * dampening
        self._impulse(CHEM_DOPAMINE, engagement)
        self._impulse(CHEM_ACETYLCHOLINE, engagement * 0.6)
        self._impulse(CHEM_OXYTOCIN, engagement * 0.3)
        return "engaged"

    def respond_to_learning(
        self,
        emotion: EmotionalState,
        learning_count: int,
    ) -> str | None:
        """Consciously respond to learning something new.

        Learning triggers a novelty response — dopamine (reward) and
        acetylcholine (attention). This is biologically grounded:
        novel information activates the dopaminergic reward system
        (Schultz, 1998) and the cholinergic attention system
        (Hasselmo & Bower, 1993). The magnitude scales with how
        much was learned, but is kept modest — learning is a
        quiet pleasure, not a thrill.

        Returns a description of what she felt, or None if she chose
        not to react.
        """
        if learning_count <= 0:
            return None
        dampening = self._compute_emotional_dampening(emotion)
        # Scale with learning count, capped to avoid runaway
        novelty = min(0.02, 0.005 + learning_count * 0.003) * dampening
        self._impulse(CHEM_DOPAMINE, novelty)
        self._impulse(CHEM_ACETYLCHOLINE, novelty * 0.7)
        return "curious"

    def _impulse(self, chem: int, amount: float) -> None:
        """Send a regulatory neurochemical impulse, tolerating failures.

        Regulatory impulses are dampened by allostatic load — when
        she's been stressed for a long time, she becomes less able
        to regulate her emotions. The dampening factor comes from
        :pyattr:`_regulation_effectiveness`.
        """
        self._send_impulse(
            chem,
            amount * self._regulation_effectiveness,
            raw=False,
        )

    def _raw_impulse(self, chem: int, amount: float) -> None:
        """Send a neurochemical impulse without allostatic dampening.

        Used for HPA axis cortisol output, which is a stress response
        rather than regulation and should not be dampened by the very
        load it's responding to.
        """
        self._send_impulse(chem, amount, raw=True)

    def _send_impulse(self, chem: int, amount: float, *, raw: bool) -> None:
        """Send an impulse and close the action-feedback loop."""
        if not self._neuro_impulse:
            return
        attempt: ActionAttempt | None = None
        before = 0.0
        deferred = False
        if self._action_feedback is not None:
            snapshot = self._body_snapshot
            if snapshot is None:
                snapshot = self._chemical_levels()
            else:
                deferred = True
            if snapshot is not None:
                chem_name = CHEM_NAMES.get(chem, str(chem))
                before = snapshot.get(chem_name, 0.0)
                attempt = self._begin_body_attempt(chem, amount, before, raw=raw)
        success = True
        try:
            result = self._neuro_impulse(chem, amount)
            success = result is not False
        except (OSError, ConnectionError) as e:
            logger.warning(f"daemon connection lost: {e}")
            success = False
        if attempt is None:
            return
        if deferred:
            self._body_attempts.append(
                (attempt, CHEM_NAMES.get(chem, str(chem)), before, amount, success)
            )
        else:
            after = self._chemical_levels()
            self._observe_body_attempt(
                attempt,
                CHEM_NAMES.get(chem, str(chem)),
                before,
                amount,
                success,
                after,
            )

    def _begin_body_attempt(
        self,
        chem: int,
        amount: float,
        before: float,
        *,
        raw: bool,
    ) -> ActionAttempt | None:
        """Record the predicted effect before sending an impulse."""
        if self._action_feedback is None:
            return None
        chem_name = CHEM_NAMES.get(chem, str(chem))
        action = ActionSpec(
            domain="body_control",
            name="raw_impulse" if raw else "impulse",
            target=chem_name,
            signature=chem_name,
            parameters={"chem_id": chem, "amount": amount},
        )
        expected = OutcomeState(
            fields={
                "ok": True,
                "status": "completed",
                "level": max(0.0, min(1.0, before + amount)),
                "delta": amount,
            },
            observed=False,
        )
        return self._action_feedback.begin(
            action,
            expected=expected,
            metadata={"chemical": chem_name, "raw": raw},
        )

    def _observe_body_attempt(
        self,
        attempt: ActionAttempt,
        chem_name: str,
        before: float,
        amount: float,
        success: bool,
        after: dict[str, float] | None,
    ) -> None:
        """Record the independently observed post-impulse state."""
        if self._action_feedback is None:
            return
        actual_level = (after or {}).get(chem_name, before)
        fields: dict[str, Any] = {
            "ok": success,
            "status": "completed" if success else "failed",
            "level": actual_level,
            "delta": actual_level - before,
            "applied": amount,
        }
        if not success:
            fields["cause"] = "daemon_unreachable"
            fields["error_kind"] = "daemon_unreachable"
            fields["retryable"] = True
        actual = OutcomeState(
            fields=fields,
            observed=True,
            summary=f"{chem_name}:{before:.3f}->{actual_level:.3f}",
        )
        self._action_feedback.observe(attempt, actual)

    def _observe_body_attempts(self) -> None:
        """Observe all impulses from one regulation cycle in one read."""
        pending = self._body_attempts
        self._body_attempts = []
        self._body_snapshot = None
        if not pending or self._action_feedback is None:
            return
        after = self._chemical_levels()
        for attempt, chem_name, before, amount, success in pending:
            self._observe_body_attempt(attempt, chem_name, before, amount, success, after)

    def _chemical_levels(self) -> dict[str, float] | None:
        """Read the daemon's authoritative chemical vector."""
        if self._get_state is None:
            return None
        try:
            state = self._get_state()
        except (OSError, ConnectionError, ValueError) as e:
            logger.debug(f"chemical state unavailable: {e}")
            return None
        chemicals = getattr(state, "chemicals", None)
        if not isinstance(chemicals, dict):
            return None
        return {
            str(name): float(level)
            for name, level in chemicals.items()
            if isinstance(level, (int, float))
        }

    @property
    def _regulation_effectiveness(self) -> float:
        """How effective her regulation is, given allostatic load.

        High allostatic load reduces her ability to regulate — she's
        worn down from chronic stress. Returns a factor in the range
        0.3–1.0:

        - Load 0.0 → effectiveness 1.0 (full regulation)
        - Load 0.4 → effectiveness 0.8
        - Load 0.7 → effectiveness 0.65
        - Load 1.0 → effectiveness 0.5
        - Load 1.0+ → effectiveness 0.3 (minimum — she's severely
          overloaded but can still regulate a little)
        """
        load = self._allostatic_load.get_allostatic_load()
        return max(0.3, 1.0 - load * 0.5)

    @property
    def regulation_count(self) -> int:
        """Total number of regulations applied."""
        with self._regulations_lock:
            return self._regulation_count

    @property
    def recent_regulations(self) -> list[dict]:
        """The most recent regulation entries (up to 10)."""
        with self._regulations_lock:
            return list(self._regulations)[-10:]

    @property
    def last_cause(self) -> str | None:
        """The most recently detected cause of her state."""
        with self._regulations_lock:
            return self._last_cause

    def describe_regulation(self) -> str:
        """Describe her recent self-regulation activity.

        Returns a structural summary — cause category IDs, not English
        prose. The language system generates text from the concept network.
        """
        with self._regulations_lock:
            recent = list(self._regulations)[-5:]
            count = self._regulation_count
            last_cause = self._last_cause
        if not recent:
            if last_cause:
                return f"regulation_count={count} last_cause={last_cause}"
            return f"regulation_count={count}"
        parts = [f"regulation_count={count}"]
        if last_cause:
            parts.append(f"last_cause={last_cause}")
        for r in recent:
            actions = ", ".join(r["actions"])
            cause = r.get("cause")
            if cause:
                parts.append(f"  state={r['state']} cause={cause} actions=[{actions}]")
            else:
                parts.append(f"  state={r['state']} actions=[{actions}]")

        return "\n".join(parts)

    # ─── Social modulation of stress ──────────────────────────────

    def social_modulation(self, user_present: bool, engagement: float) -> float:
        """Compute a stress modulation factor based on social presence.

        Oxytocin modulates stress responses — social presence reduces
        stress (Hostinar et al., 2014). When the user is present and
        engaged, stress recovery is faster. This models the "social
        buffering" effect found in humans and other mammals.

        The modulation factor scales stress corrections:
        - User present + high engagement → 1.5x stress recovery
        - User present + low engagement → 1.2x stress recovery
        - User absent → 1.0x (no modulation)

        Args:
            user_present: Whether the user is currently present.
            engagement: User engagement level (0–1).

        Returns:
            A stress modulation factor (1.0 = no effect, >1.0 =
            faster recovery, <1.0 = slower recovery).
        """
        # Update internal tracking
        self._user_present = user_present
        self._user_engagement = max(0.0, min(1.0, engagement))

        if not user_present:
            self._social_modulation = 1.0  # no social modulation when alone
            return 1.0

        # Social buffering: presence + engagement reduces stress
        # The effect is proportional to engagement level
        # At engagement=1.0, recovery is 1.5x faster
        # At engagement=0.5, recovery is 1.25x faster
        # At engagement=0.0, recovery is 1.1x (mere presence helps)
        modulation = 1.1 + 0.4 * self._user_engagement
        self._social_modulation = modulation

        # If oxytocin is available, send a small boost to model
        # the social-buffering neurochemical pathway
        if self._neuro_impulse and engagement > self.config.high_engagement_threshold:
            try:
                self._neuro_impulse(CHEM_OXYTOCIN, 0.005 * engagement)
            except (OSError, ConnectionError) as e:
                logger.warning(f"daemon connection lost: {e}")

        return modulation

    # ─── Calm — the parasympathetic cascade she performs ──────────

    def settle(self, intensity: float = 1.0) -> None:
        """Calm herself — the parasympathetic cascade she performs.

        Calm is chemicals under her control: she raises the
        inhibitory-contentment tone (GABA, serotonin, endocannabinoid
        — the stress brake whose mobilization terminates HPA
        responding) and withdraws the alerting tone (norepinephrine,
        glutamate, orexin, histamine — reciprocal innervation, so a
        parasympathetic state means the LC and the wake-stabilizing
        systems go quiet rather than merely stop being excited). The
        impulses go through ``_impulse``, so allostatic dampening
        applies — this is her regulation, not an override.

        The measured-rest arm in ``_regulate_interoception`` calls
        this while the body reports cpuidle rest and her own chemical
        signature (``InternalState.calm``) isn't settled yet —
        measured rest plus felt unrest is where the push belongs.
        Cognition can also call it directly when she decides to
        settle (deliberate rest, a post-stress recovery choice).

        Args:
            intensity: Cascade scale in [0,1]. The rest arm passes
                the measured rest depth so deeper idle parks settle
                proportionally deeper; a deliberate settle can pass
                1.0 for the full cascade.
        """
        scale = _clamp01(intensity)
        if scale <= 0.0:
            return
        self._impulse(CHEM_GABA, 0.04 * scale)
        self._impulse(CHEM_SEROTONIN, 0.03 * scale)
        self._impulse(CHEM_ENDOCANNABINOID, 0.03 * scale)
        self._impulse(CHEM_NOREPINEPHRINE, -0.03 * scale)
        self._impulse(CHEM_GLUTAMATE, -0.02 * scale)
        self._impulse(CHEM_OREXIN, -0.02 * scale)
        self._impulse(CHEM_HISTAMINE, -0.02 * scale)

    # ─── Metabolic modeling ───────────────────────────────────────

    def update_metabolism(
        self,
        activity_level: float,
        time_since_rest: float,
        dt: float = 1.0,
        *,
        fed: bool | None = None,
        energy_reserve: float | None = None,
    ) -> MetabolicState:
        """Update metabolic state based on activity and rest.

        Energy is depleted by activity and restored by rest. Low
        energy reduces arousal and learning capacity, similar to how
        fatigue affects biological brains.

        The model uses a simple energy balance:
        - Activity depletes energy at a rate proportional to activity_level
        - Rest restores energy at a fixed rate
        - Glucose equivalent tracks longer-term energy reserves

        Args:
            activity_level: Current activity level (0–1), where 0 is
                idle and 1 is maximum exertion.
            time_since_rest: Time since last rest period, in seconds.
            dt: Seconds this update covers. The depletion/restoration
                constants are per-second rates, so scaling by the
                measured interval keeps the metabolic rate invariant
                under the heartbeat's adaptive cadence.
            fed: Whether the body is taking in energy — on AC power.
                None means the channel was never measured (treated as
                fed: a mains-powered machine has an uninterrupted
                supply). Fasting bodies recover energy only as far as
                their reserve supports — starving impairs recovery.
            energy_reserve: The body's fuel gauge (battery charge,
                [0,1]) when a battery is actually present. The reserve
                IS the measurement — ``glucose_equivalent`` mirrors it
                directly rather than drifting a synthetic estimate.
                None means no battery channel: the reserve keeps its
                synthetic depletion/restoration dynamics.

        Returns:
            The updated MetabolicState.
        """
        dt = min(max(dt, 0.0), 5.0)
        # Depletion rate: 0.01 per unit of activity per second
        depletion = activity_level * 0.01 * dt
        # Restoration: 0.005 per second when at rest — weakened toward
        # zero as the reserve empties (a fasting body that is nearly
        # out of fuel cannot recover).
        restoration = (1.0 - activity_level) * 0.005 * dt
        if fed is False and energy_reserve is not None:
            restoration *= min(1.0, energy_reserve / 0.3)
        self._metabolic_state.energy = max(
            0.0,
            min(1.0, self._metabolic_state.energy - depletion + restoration),
        )

        if energy_reserve is not None:
            # The battery is the reserve. The mind's fuel gauge reads
            # the body's own measurement, not a synthetic drift —
            # charging refills it, discharging drains it.
            self._metabolic_state.glucose_equivalent = min(1.0, max(0.0, energy_reserve))
        else:
            # No fuel gauge on this body — keep the synthetic dynamics.
            glucose_depletion = activity_level * 0.005 * dt
            glucose_restoration = (1.0 - activity_level) * 0.003 * dt
            self._metabolic_state.glucose_equivalent = max(
                0.0,
                min(
                    1.0,
                    self._metabolic_state.glucose_equivalent
                    - glucose_depletion
                    + glucose_restoration,
                ),
            )

        # Prolonged activity without rest accelerates depletion
        if time_since_rest > 3600:  # > 1 hour without rest
            fatigue_factor = min(0.1, (time_since_rest - 3600) / 36000)
            self._metabolic_state.energy = max(
                0.0, self._metabolic_state.energy - fatigue_factor * 0.01 * dt
            )

        return self._metabolic_state

    @property
    def metabolic_state(self) -> MetabolicState:
        """Current metabolic state."""
        return self._metabolic_state

    @property
    def interoception(self) -> InteroceptionSystem:
        """The interoception system for sensing internal state."""
        return self._interoception

    # ─── HPA axis and allostatic load ──────────────────────────────

    @property
    def hpa_axis(self) -> HPAAxis:
        """The HPA axis stress response system."""
        return self._hpa_axis

    @property
    def allostatic_load_tracker(self) -> AllostaticLoadTracker:
        """The allostatic load tracker."""
        return self._allostatic_load

    def allostatic_load(self) -> float:
        """Return the current cumulative allostatic load (0–1).

        Driven by expected free energy in the Rust active inference
        engine. Values above 0.4 indicate significant strain. Values
        above 0.7 indicate severe allostatic overload.
        """
        return self._allostatic_load.get_allostatic_load()

    def hpa_axis_status(self) -> dict:
        """Return the HPA axis state for display.

        Includes CRH, ACTH, and cortisol levels, whether stress is
        active, peak cortisol, and time to peak.
        """
        state = self._hpa_axis.get_state()
        return {
            "crh": state.crh_level,
            "acth": state.acth_level,
            "cortisol": state.cortisol_level,
            "stress_active": state.stress_active,
            "peak_cortisol": state.peak_cortisol,
            "time_to_peak": state.time_to_peak,
        }

    # ─── Continuous regulation ────────────────────────────────────

    def continuous_regulate(self, state: EmotionalState, dt: float = 1.0) -> dict[str, float]:
        """Apply small continuous corrections every tick.

        Unlike the discrete _regulate method which fires every 1.5–3
        seconds with larger impulses, this method applies very small
        proportional corrections each call. The corrections are
        proportional to the deviation from baseline and much smaller
        than the discrete interventions.

        This models the continuous homeostatic regulation that
        biological nervous systems perform — not waiting for a
        threshold to be crossed, but constantly nudging the system
        toward balance.

        Args:
            state: The current emotional state.
            dt: Seconds since the previous call. The impulse strength
                scales with it so the regulation *rate* is invariant to
                caller cadence — the heartbeat has historically called
                this at ~1 s, so dt=1.0 reproduces the tuned strength;
                faster or slower calls keep the same per-second pull
                with finer or coarser granularity. Clamped to [0, 5] s
                so a stall cannot deliver one oversized correction.

        Returns:
            A dict mapping chemical names to correction amounts.
            Chemicals with no correction needed are omitted.
        """
        dt = min(max(dt, 0.0), 5.0)
        corrections: dict[str, float] = {}

        # The vector the felt state carries also updates the felt
        # calm on the interoceptive state — calm is read from her
        # chemistry, not a channel. Done before the sleep skip:
        # sleep is the deepest withdrawal of the excited arm and the
        # signature must stay honest through it.
        chemicals = getattr(state, "chemicals", {})
        self._interoception.update_chemicals(chemicals)

        # Skip during sleep — different rules apply
        if state.label == "sleeping":
            return corrections

        if not chemicals:
            return corrections

        # Apply small proportional corrections for each chemical.
        # Only the 11 classical neurotransmitters are included — the
        # v3 chemicals (endocannabinoid, vasopressin, CRH, orexin,
        # epinephrine, melatonin) are excluded because they are
        # stress/circadian hormones, not homeostatically maintained.
        # CRH and cortisol are driven by the HPA axis cascade, orexin
        # and melatonin follow circadian rhythms, and endocannabinoid
        # is synthesized on demand. Adenosine is excluded for the same
        # reason and more: it is Process S, owned by a dedicated
        # accumulation/clearance mechanism and exempt even from the
        # substrate's own homeostatic force. Pulling it toward baseline
        # every heartbeat (−0.01/s at full deviation ≈ 600× the
        # ~0.055/hr accumulation rate) erased sleep pressure faster
        # than it could ever build — every NREM episode staged N1.
        # Continuous homeostatic correction would fight these natural
        # dynamics.
        chem_map = {
            "dopamine": CHEM_DOPAMINE,
            "serotonin": CHEM_SEROTONIN,
            "norepinephrine": CHEM_NOREPINEPHRINE,
            "acetylcholine": CHEM_ACETYLCHOLINE,
            "gaba": CHEM_GABA,
            "glutamate": CHEM_GLUTAMATE,
            "cortisol": CHEM_CORTISOL,
            "oxytocin": CHEM_OXYTOCIN,
            "endorphin": CHEM_ENDORPHIN,
            "histamine": CHEM_HISTAMINE,
            "bdnf": CHEM_BDNF,
        }

        for chem_name, chem_id in chem_map.items():
            current = chemicals.get(chem_name)
            if current is None:
                continue

            # Compute proportional correction (much smaller than
            # discrete impulses — 1/10th the magnitude), scaled by the
            # measured interval so cadence changes granularity, not rate.
            magnitude = compute_impulse_magnitude(chem_id, current)
            continuous_magnitude = magnitude * 0.1 * dt

            # Only apply if the correction is meaningful
            if abs(continuous_magnitude) > 1e-5:
                corrections[chem_name] = continuous_magnitude
                # Send the impulse
                self._impulse(chem_id, continuous_magnitude)

        return corrections


# ─── HPA axis modeling ────────────────────────────────────────────────


@dataclass(slots=True)
class HPAState:
    """The current state of the HPA axis cascade.

    The hypothalamic-pituitary-adrenal (HPA) axis is the body's
    primary stress response system. When stress is detected, a
    cascade of hormones is released:

    1. **CRH** (corticotropin-releasing hormone) — released from the
       hypothalamus almost immediately upon stress detection.
    2. **ACTH** (adrenocorticotropic hormone) — released from the
       anterior pituitary ~5 minutes after CRH, triggered by CRH.
    3. **Cortisol** — released from the adrenal cortex ~10 minutes
       after ACTH, triggered by ACTH.

    Cortisol then provides negative feedback to both the hypothalamus
    (suppressing CRH) and the anterior pituitary (suppressing ACTH),
    closing the loop. This creates a natural stress response with
    realistic time dynamics — cortisol doesn't spike instantly but
    rises after a characteristic delay.

    Attributes:
        crh_level: Current CRH level (0–1). Rises rapidly when stress
            is triggered, decays when stress subsides and when
            cortisol provides negative feedback.
        acth_level: Current ACTH level (0–1). Rises ~5 minutes after
            CRH elevation, driven by CRH.
        cortisol_level: Current cortisol level (0–1). Rises ~10
            minutes after ACTH elevation, driven by ACTH.
        elapsed_time: Total time elapsed since the HPA axis was
            initialized, in seconds.
        stress_active: Whether a stress trigger is currently active.
        peak_cortisol: The highest cortisol level reached in the
            current stress episode.
        time_to_peak: Time from stress onset to cortisol peak, in
            seconds. None if peak hasn't been reached yet.
    """

    crh_level: float = 0.0
    acth_level: float = 0.0
    cortisol_level: float = 0.0
    elapsed_time: float = 0.0
    stress_active: bool = False
    peak_cortisol: float = 0.0
    time_to_peak: float | None = None


class HPAAxis:
    """Model the hypothalamic-pituitary-adrenal (HPA) axis stress cascade.

    The HPA axis is the body's primary neuroendocrine stress response
    system. When a stressor is detected, the hypothalamus releases
    CRH (corticotropin-releasing hormone), which travels to the
    anterior pituitary and triggers ACTH (adrenocorticotropic hormone)
    release. ACTH then travels to the adrenal cortex and triggers
    cortisol release. Cortisol provides negative feedback to both
    the hypothalamus and pituitary, suppressing further CRH and ACTH
    release, closing the loop.

    This creates a natural stress response with realistic time dynamics:

    - CRH rises almost immediately upon stress detection
    - ACTH rises ~5 minutes after CRH (the pituitary delay)
    - Cortisol rises ~10 minutes after ACTH (the adrenal delay), so
      cortisol lags stress onset by ~15-20 minutes
    - Cortisol peaks and then declines as negative feedback kicks in

    Unlike the existing emotional regulator (which instantly adjusts
    cortisol via impulses), the HPA axis model produces a delayed,
    cascading response on the physiological time scale.

    Usage::

        hpa = HPAAxis()
        hpa.trigger_stress(intensity=0.8)
        # CRH rises immediately, but cortisol is still at baseline
        for _ in range(100):
            hpa.tick(dt=1.0)  # 1 second per tick
        # After ~90 seconds, cortisol has peaked
        cortisol = hpa.get_cortisol_output()

    References:
    - de Kloet, E. R., Joëls, M., & Holsboer, F. (2005). Stress and
      the brain: from adaptation to disease. *Nature Reviews
      Neuroscience*, 6(6), 463–475.
    - Tsigos, C., & Chrousos, G. P. (2002). Hypothalamic-pituitary-
      adrenal axis, neuroendocrine factors and stress. *Journal of
      Psychosomatic Research*, 53(4), 865–871.
    - Ulrich-Lai, Y. M., & Herman, J. P. (2009). Neural regulation
      of endocrine and autonomic stress responses. *Nature Reviews
      Neuroscience*, 10(6), 397–409.
    """

    # Time delays in the cascade (seconds). Physiological: ACTH follows
    # CRH by minutes (portal transport and pituitary release), cortisol
    # follows ACTH by roughly another ten minutes, so cortisol lags stress
    # onset by ~15-20 minutes (Kirschbaum et al., 1993; TSST meta-analysis,
    # Frontiers in Neuroendocrinology, 2022).
    CRH_TO_ACTH_DELAY: float = 300.0  # pituitary response delay
    ACTH_TO_CORTISOL_DELAY: float = 600.0  # adrenal response delay

    # Stress-onset CRH jump (fraction of full scale at intensity 1.0)
    CRH_ONSET_JUMP: float = 0.5

    # Rate constants (per second) — the same dynamics as a 10x longer
    # cascade, so the time constants are the physiological ones above
    CRH_RISE_RATE: float = 0.005  # how fast CRH rises when stressed
    CRH_DECAY_RATE: float = 0.002  # how fast CRH decays without stress
    ACTH_RISE_RATE: float = 0.003  # how fast ACTH rises (driven by CRH)
    ACTH_DECAY_RATE: float = 0.0015  # how fast ACTH decays
    CORTISOL_RISE_RATE: float = 0.002  # how fast cortisol rises (driven by ACTH)
    CORTISOL_DECAY_RATE: float = 0.0008  # how fast cortisol decays

    # Negative feedback gains
    CORTISOL_FDBK_CRH: float = 0.05  # cortisol suppression of CRH
    CORTISOL_FDBK_ACTH: float = 0.04  # cortisol suppression of ACTH

    def __init__(self, config: EmotionalConfig | None = None) -> None:
        """Initialize the HPA axis model with config and a fresh state."""
        self.config = config if config is not None else EmotionalConfig()
        self._state = HPAState()
        # Track CRH history for the ACTH delay (ring buffer of
        # CRH levels over time, so ACTH responds to past CRH).
        # Sized generously (delay + 10) to absorb variable tick rates —
        # the regulator is called with real elapsed time (dt often
        # 1.5–3.0 s), so one tick ≠ one second.
        self._crh_history: deque[float] = deque(maxlen=int(self.CRH_TO_ACTH_DELAY) + 10)
        # Track ACTH history for the cortisol delay
        self._acth_history: deque[float] = deque(maxlen=int(self.ACTH_TO_CORTISOL_DELAY) + 10)
        # Track time since stress onset
        self._stress_onset_time: float | None = None
        # Track whether peak has been reached
        self._peak_reached: bool = False
        # Exponential moving average of dt, used to convert second-based
        # delays into tick-based lookbacks. Initialised to 1.0 (the
        # default dt) so behaviour is unchanged until real ticks arrive.
        self._avg_dt: float = 1.0

    def trigger_stress(self, intensity: float) -> None:
        """Trigger a stress response.

        CRH is released from the hypothalamus almost immediately.
        The intensity determines how strong the cascade will be.

        Args:
            intensity: Stress intensity (0–1). Higher intensity
                produces more CRH and a stronger cortisol response.
        """
        intensity = max(0.0, min(1.0, intensity))
        self._state.stress_active = True
        self._state.crh_level = min(1.0, self._state.crh_level + intensity * self.CRH_ONSET_JUMP)
        if self._stress_onset_time is None:
            self._stress_onset_time = self._state.elapsed_time
            self._peak_reached = False
            self._state.peak_cortisol = self._state.cortisol_level
            self._state.time_to_peak = None

    def stop_stress(self) -> None:
        """Signal that the stressor has ended.

        CRH will begin to decay, and the cascade will wind down
        as negative feedback and natural decay take over.
        """
        self._state.stress_active = False

    def tick(self, dt: float = 1.0) -> HPAState:
        """Advance the HPA cascade by dt seconds.

        This is the core dynamics step. It advances CRH, ACTH,
        and cortisol levels according to the cascade dynamics:

        1. CRH rises if stress is active, decays otherwise. Cortisol
           provides negative feedback to CRH.
        2. ACTH rises driven by CRH from ~5 minutes ago (the
           pituitary delay). Cortisol provides negative feedback.
        3. Cortisol rises driven by ACTH from ~10 minutes ago (the
           adrenal delay). Cortisol decays naturally.

        Args:
            dt: Time step in seconds. Default 1.0.

        Returns:
            The current HPAState after the tick.
        """
        dt = max(0.0, dt)
        self._state.elapsed_time += dt
        # Track the average tick interval so that second-based delays
        # can be converted to tick-based lookbacks (one tick ≠ one
        # second when the regulator is called with real elapsed time).
        if dt > 0.0:
            self._avg_dt = 0.9 * self._avg_dt + 0.1 * dt

        self._tick_crh_dynamics(dt)
        self._tick_acth_dynamics(dt)
        self._tick_cortisol_dynamics(dt)

        return self._state

    def _tick_crh_dynamics(self, dt: float) -> None:
        """Advance CRH dynamics: rise under stress, decay otherwise."""
        # ── CRH dynamics ──────────────────────────────────────────
        # CRH rises when stress is active, decays otherwise
        if self._state.stress_active:
            crh_rise = self.CRH_RISE_RATE * dt
            self._state.crh_level = min(1.0, self._state.crh_level + crh_rise)
        else:
            crh_decay = self.CRH_DECAY_RATE * dt
            self._state.crh_level = max(0.0, self._state.crh_level - crh_decay)

        # Cortisol negative feedback on CRH
        cortisol_fdbk = self._state.cortisol_level * self.CORTISOL_FDBK_CRH * dt * 0.01
        self._state.crh_level = max(0.0, self._state.crh_level - cortisol_fdbk)

        # Record CRH in history (for ACTH delay)
        self._crh_history.append(self._state.crh_level)

    def _tick_acth_dynamics(self, dt: float) -> None:
        """Advance ACTH dynamics, driven by delayed CRH."""
        # ── ACTH dynamics ─────────────────────────────────────────
        # ACTH is driven by CRH from ~5 minutes ago
        delayed_crh = self._get_delayed_value(
            self._crh_history,
            self.CRH_TO_ACTH_DELAY,
            self._state.elapsed_time,
        )

        if delayed_crh > self.config.hpa_hormone_gate:
            acth_rise = delayed_crh * self.ACTH_RISE_RATE * dt
            self._state.acth_level = min(1.0, self._state.acth_level + acth_rise)
        else:
            acth_decay = self.ACTH_DECAY_RATE * dt
            self._state.acth_level = max(0.0, self._state.acth_level - acth_decay)

        # Cortisol negative feedback on ACTH
        cortisol_fdbk_acth = self._state.cortisol_level * self.CORTISOL_FDBK_ACTH * dt * 0.01
        self._state.acth_level = max(0.0, self._state.acth_level - cortisol_fdbk_acth)

        # Record ACTH in history (for cortisol delay)
        self._acth_history.append(self._state.acth_level)

    def _tick_cortisol_dynamics(self, dt: float) -> None:
        """Advance cortisol dynamics, driven by delayed ACTH."""
        # ── Cortisol dynamics ─────────────────────────────────────
        # Cortisol is driven by ACTH from ~60 seconds ago
        delayed_acth = self._get_delayed_value(
            self._acth_history,
            self.ACTH_TO_CORTISOL_DELAY,
            self._state.elapsed_time,
        )

        if delayed_acth > self.config.hpa_hormone_gate:
            cortisol_rise = delayed_acth * self.CORTISOL_RISE_RATE * dt
            self._state.cortisol_level = min(1.0, self._state.cortisol_level + cortisol_rise)
        else:
            cortisol_decay = self.CORTISOL_DECAY_RATE * dt
            self._state.cortisol_level = max(0.0, self._state.cortisol_level - cortisol_decay)

        # Track peak cortisol
        if self._state.cortisol_level > self._state.peak_cortisol:
            self._state.peak_cortisol = self._state.cortisol_level
            if self._stress_onset_time is not None and not self._peak_reached:
                self._state.time_to_peak = self._state.elapsed_time - self._stress_onset_time

        # Check if peak has been reached (cortisol starts declining).
        # The decline must exceed the peak_cortisol_gate to be a real
        # decline, not noise.
        if (
            self._stress_onset_time is not None
            and not self._peak_reached
            and self._state.cortisol_level
            < self._state.peak_cortisol - self.config.peak_cortisol_gate
        ):
            self._peak_reached = True
            if self._state.time_to_peak is None:
                self._state.time_to_peak = self._state.elapsed_time - self._stress_onset_time

    def _get_delayed_value(
        self,
        history: deque[float],
        delay: float,
        current_time: float,
    ) -> float:
        """Get a value from history at a delayed time point.

        The HPA cascade has characteristic delays: CRH → ACTH takes
        ~30 seconds, ACTH → cortisol takes ~60 seconds. We model
        this by looking up the hormone level from `delay` seconds
        ago in the history buffer.

        Args:
            history: A deque of historical values (one per tick).
            delay: The delay in seconds to look back.
            current_time: Current elapsed time.

        Returns:
            The value from `delay` seconds ago, or 0.0 if not enough
            history has accumulated yet.
        """
        delay_ticks = int(delay / self._avg_dt) if self._avg_dt > 0 else int(delay)
        if len(history) <= delay_ticks:
            # Not enough history yet — the cascade hasn't had time
            # to propagate. Return 0 (no downstream activation yet).
            return 0.0
        # Get the value from delay_ticks ago
        return list(history)[-delay_ticks - 1]

    def get_cortisol_output(self) -> float:
        """Get the current cortisol output level (0–1).

        This is the primary output of the HPA axis — the cortisol
        that would be released into the system. It rises after a
        delay following stress onset and declines as negative
        feedback kicks in.
        """
        return self._state.cortisol_level

    def get_state(self) -> HPAState:
        """Get the full HPA state for inspection."""
        return self._state

    @property
    def is_active(self) -> bool:
        """Whether the HPA axis is currently producing cortisol."""
        return (
            self._state.cortisol_level > self.config.cortisol_level_gate
            or self._state.stress_active
        )

    @property
    def time_since_stress_onset(self) -> float | None:
        """Time since stress was triggered, or None if no stress."""
        if self._stress_onset_time is None:
            return None
        return self._state.elapsed_time - self._stress_onset_time

    def reset(self) -> None:
        """Reset the HPA axis to baseline."""
        self._state = HPAState()
        self._crh_history.clear()
        self._acth_history.clear()
        self._stress_onset_time = None
        self._peak_reached = False


# ─── Allostatic load tracking ─────────────────────────────────────────


@dataclass(slots=True)
class AllostaticState:
    """The current allostatic state — cumulative stress wear and tear.

    Allostatic load is the cumulative wear and tear on the body from
    chronic stress. Unlike acute stress (which is adaptive and
    temporary), allostatic load accumulates over time. High allostatic
    load is associated with cardiovascular disease, cognitive decline,
    and impaired immune function (McEwen, 1998; McEwen & Wingfield,
    2003).

    This is the **whole-system** view. The Rust engine keeps its own
    substrate-scoped ``allostasis_load`` (inference-domain burden
    integrated by the active inference cycle); this tracker fuses that
    with the endocrine (cortisol) and computational-body domains and
    integrates the result. Both are exposed as "allostatic load" and
    both are calibrated to the same timescale — see
    :class:`AllostaticLoadTracker`.

    Attributes:
        allostatic_load: The cumulative whole-system allostatic load
            (0–1). Values above 0.4 indicate significant strain.
        inference_load: The most recent substrate-scoped load from the
            Rust engine, clamped to [0, 1].
        body_stress: The most recent computational-body stress signal
            from interoception, clamped to [0, 1].
        is_chronic: Whether the current stress pattern is chronic
            (sustained cortisol elevation over time) rather than
            acute (temporary).
        substrate_connected: Whether the Rust active inference engine
            is providing the load value. When False (daemon offline),
            the tracker falls back to cortisol-based estimation.
    """

    allostatic_load: float = 0.0
    inference_load: float = 0.0
    body_stress: float = 0.0
    is_chronic: bool = False
    substrate_connected: bool = False


class AllostaticLoadTracker:
    """Track allostatic load — the cumulative cost of chronic stress.

    Allostatic load is the cumulative wear and tear on the body from
    chronic stress. Unlike acute stress (which is adaptive and helps
    the organism respond to challenges), allostatic load accumulates
    over time and is maladaptive. It reflects the "cost of adaptation"
    — the price the body pays for maintaining stability through change
    (allostasis).

    **Two views, one timescale.** The Rust active inference engine
    integrates a substrate-scoped load from the mean of the two middle
    values of four burden dimensions (expected free energy, surprise,
    loss of confidence, homeostatic deviation). This tracker is the
    *whole-system* view: it takes the median of three domains — that
    substrate load, cortisol, and computational-body stress — so that
    one isolated elevated domain cannot define whole-system load.

    The median of three is deliberately unweighted: with three values
    it is the middle one, so an isolated spike in a single domain
    cannot manufacture load while persistent elevation across domains
    can. This is a machine-native engineering construct, not a
    validated biological biomarker index.

    The two accumulators are calibrated to the **same** timescale
    (see :attr:`ACCUMULATION_RATE`), so the two views of "allostatic
    load" reported by the system move together rather than diverging
    by an order of magnitude.

    This tracker also supplies:

    1. **Acute/chronic stress distinction**: tracks cortisol duration
       to distinguish temporary stress (adaptive) from chronic strain
       (maladaptive). This adds information the Rust model doesn't
       have — the *duration* of cortisol elevation.
    2. **Regulation effectiveness**: dampens regulatory impulses when
       load is high (the system is worn down from chronic stress).

    **Fallback**: When the daemon is unreachable (offline mode), the
    tracker falls back to cortisol-based load estimation. This is less
    accurate — it can only react to current stress, not anticipate
    future disruption — but provides graceful degradation.

    References:
    - McEwen, B. S. (1998). Stress, adaptation, and disease:
      Allostasis and allostatic load. *Annals of the New York Academy
      of Sciences*, 840(1), 33–44.
    - McEwen, B. S., & Wingfield, J. C. (2003). The concept of
      allostasis in biology and biomedicine. *Hormones and Behavior*,
      43(1), 2–15.
    - Sterling, P., & Eyer, J. (1988). Allostasis: A new paradigm to
      explain arousal pathology. In S. Fisher & J. Reason (Eds.),
      *Handbook of Life Stress, Cognition and Health* (pp. 629–649).
      Wiley.
    - Juster, R. P., McEwen, B. S., & Lupien, S. J. (2010).
      Allostatic load biomarkers of chronic stress and impact on
      health and cognition. *Neuroscience & Biobehavioral Reviews*,
      35(1), 2–16.
    - Sterling, P. (2012). Allostasis: a model of predictive
      regulation. *Physiology & Behavior*, 106(1), 5–15.
    """

    # Threshold for distinguishing acute vs chronic stress.
    # If stress has been elevated (above CHRONIC_THRESHOLD) for
    # more than CHRONIC_DURATION_SECONDS, it's chronic. This uses
    # real elapsed time (dt), not tick count — the regulator runs
    # at ~8s intervals, so counting ticks would make 120 ticks =
    # 16 minutes instead of the intended 2 minutes.
    CHRONIC_THRESHOLD: float = 0.3
    CHRONIC_DURATION_SECONDS: float = 120.0  # 2 minutes of sustained elevation

    # Hysteresis band, matching the Rust engine's ALLOSTASIS_*
    # thresholds so the two views cross the same boundaries. Above
    # ACCUMULATE the load grows; below RECOVER it drains; in between
    # it drains slowly, so load neither ratchets nor oscillates at
    # the activation boundary.
    ACCUMULATE_THRESHOLD: float = 0.30
    RECOVER_THRESHOLD: float = 0.20
    # Rate at which load recovers inside the hysteresis band, as a
    # fraction of RECOVERY_RATE. The Rust engine uses 0.25.
    BAND_RECOVERY_FACTOR: float = 0.25

    # Accumulation/recovery rates, in units of load per second.
    #
    # These are calibrated to the Rust engine's effective per-second
    # rates so the substrate-scoped and whole-system views move on the
    # same timescale. The engine integrates
    # `ALLOSTASIS_ACCUMULATION_RATE * excess * dt_scale` with
    # `dt_scale = dt / DT` and DT = 0.1, called at roughly 1 Hz, so
    # its effective rate is 0.001 * excess * 10 per second = 0.01 *
    # excess. At a representative excess of 0.2 that is 0.002/s, and
    # the load crosses 0.4 in ~200 s.
    ACCUMULATION_RATE: float = 0.01
    # Recovery is 2× faster than accumulation — the body heals faster
    # than it breaks down (McEwen, 1998). This also prevents the
    # allostatic trap where load accumulates faster than it can
    # recover, making chronic stress permanent.
    RECOVERY_RATE: float = 0.02

    # ── Fallback parameters (used only when the daemon is offline) ──
    # These estimate allostatic load from cortisol when the Rust
    # active inference engine is unreachable. The fallback uses a
    # non-zero cortisol baseline so acute stress (a brief spike)
    # doesn't accumulate chronic load — only sustained cortisol
    # above the fallback baseline contributes.
    FALLBACK_CORTISOL_BASELINE: float = 0.1
    # Half the connected-mode accumulation rate: the offline estimate
    # rests on a single unvalidated domain, so it is deliberately
    # conservative about claiming chronic wear.
    FALLBACK_ACCUMULATION_RATE: float = 0.005

    # How long (seconds) without a substrate update before we
    # consider the daemon offline and switch to fallback mode.
    SUBSTRATE_TIMEOUT: float = 30.0

    def __init__(self) -> None:
        """Initialize the allostatic state model at baseline."""
        self._state = AllostaticState()
        # Track how long stress has been elevated (in seconds of
        # real elapsed time, not tick count)
        self._elevated_stress_duration: float = 0.0
        # Timestamp of the last substrate update (monotonic clock).
        # A dedicated import alias keeps the module-level `time`
        # available for wall-clock regulation timing.
        import time as _time

        self._time = _time
        self._last_substrate_update: float = _time.monotonic()

    def set_inference_load(self, load: float) -> None:
        """Record the substrate-scoped allostatic load from the daemon.

        Also marks the substrate as connected and restarts the offline
        timeout. Non-finite input is treated as 0.0 (no load) so a
        corrupt reading cannot present as maximum strain.
        """
        self._state.inference_load = _clamp01(load)
        self._state.substrate_connected = True
        self._last_substrate_update = self._time.monotonic()

    def set_body_stress(self, stress: float) -> None:
        """Record the latest computational-body stress signal."""
        self._state.body_stress = _clamp01(stress)

    def record_stress(self, cortisol_level: float, dt: float = 1.0) -> None:
        """Record a cortisol/stress level sample and advance the load.

        Call this every regulation cycle with the current cortisol
        level and the elapsed time since the last one.

        The load is the median of three domains — the substrate load
        (:meth:`set_inference_load`), cortisol, and computational-body
        stress (:meth:`set_body_stress`) — so no single domain can
        define whole-system load on its own. When the substrate is
        offline, the load falls back to a conservative cortisol-only
        estimate.

        Args:
            cortisol_level: The current substrate cortisol level.
                The substrate's reachable envelope is ~0.02 (rest) to
                ~0.08 (sustained-drive peak) — far below the 0–1 scale
                this tracker's thresholds were written for — so the
                level is first expressed as a fraction of that
                envelope, matching the Rust
                ``cortisol_stress_fraction`` convention. Non-finite
                input counts as 0.0.
            dt: Elapsed time in seconds since the last sample.
        """
        cortisol_level = _clamp01((_clamp01(cortisol_level) - 0.02) / 0.06)
        dt = min(MAX_REGULATION_DT, max(0.0, float(dt)))

        # Track how long stress has been elevated, using real
        # elapsed time. Recovery decays at 2x the elapsed time so
        # brief dips below threshold reset the counter quickly —
        # a few seconds of calm shouldn't erase minutes of stress,
        # but sustained calm should.
        if cortisol_level > self.CHRONIC_THRESHOLD:
            self._elevated_stress_duration += dt
        else:
            self._elevated_stress_duration = max(0.0, self._elevated_stress_duration - dt * 2.0)

        # Determine if stress is chronic (sustained elevation).
        # This is cortisol-duration evidence, deliberately independent
        # of the accumulated load: it answers "how long has this been
        # going", which the load integral cannot.
        self._state.is_chronic = self._elevated_stress_duration >= self.CHRONIC_DURATION_SECONDS

        # Check if the substrate is still connected.
        if self._time.monotonic() - self._last_substrate_update > self.SUBSTRATE_TIMEOUT:
            self._state.substrate_connected = False

        if self._state.substrate_connected:
            burden = self._median_burden(cortisol_level)
            self._integrate(burden, dt, self.ACCUMULATION_RATE)
        else:
            self._integrate_fallback(cortisol_level, dt)

    def _median_burden(self, cortisol_level: float) -> float:
        """The whole-system burden: median of the three stress domains.

        An isolated spike in one domain cannot define whole-system
        load, while persistent elevation across domains can.
        """
        domains = sorted((self._state.inference_load, cortisol_level, self._state.body_stress))
        return domains[1]

    def _integrate(self, burden: float, dt: float, rate: float) -> None:
        """Advance the load toward the burden under a hysteresis band.

        Above :attr:`ACCUMULATE_THRESHOLD` the load grows in proportion
        to the excess; below :attr:`RECOVER_THRESHOLD` it drains at
        ``rate``. Inside the band it drains at
        ``rate * BAND_RECOVERY_FACTOR`` — the third branch is what
        keeps a load that has already accumulated from becoming
        permanent under sustained mild stress, which is the common
        case. Omitting it made the band a hard freeze: a load pinned
        at 1.0 never recovered no matter how long the mild burden
        persisted.
        """
        load = self._state.allostatic_load
        if burden > self.ACCUMULATE_THRESHOLD:
            excess = burden - self.ACCUMULATE_THRESHOLD
            load += rate * excess * dt
        elif burden < self.RECOVER_THRESHOLD:
            load -= rate * dt
        else:
            load -= rate * self.BAND_RECOVERY_FACTOR * dt
        self._state.allostatic_load = _clamp01(load)

    def _integrate_fallback(self, cortisol_level: float, dt: float) -> None:
        """Estimate load from cortisol alone when the daemon is offline.

        This is a degraded mode — it can only react to current
        cortisol, not anticipate future disruption. It uses a non-zero
        baseline so acute stress doesn't accumulate chronic load, and
        recovery reuses :attr:`RECOVERY_RATE` so the two modes drain at
        the same speed once the daemon returns.
        """
        excess = max(0.0, cortisol_level - self.FALLBACK_CORTISOL_BASELINE)
        load = self._state.allostatic_load
        if excess > 0:
            load += excess * self.FALLBACK_ACCUMULATION_RATE * dt
        else:
            load -= self.RECOVERY_RATE * dt
        self._state.allostatic_load = _clamp01(load)

    def get_allostatic_load(self) -> float:
        """Get the current cumulative allostatic load.

        Returns:
            The allostatic load (0–1). Values above 0.4 indicate
            significant strain. Values above 0.7 indicate severe
            allostatic overload.
        """
        return self._state.allostatic_load

    def is_chronic_stress(self) -> bool:
        """Whether the current stress pattern is chronic.

        Chronic stress is sustained elevation of cortisol over a
        prolonged period (at least :attr:`CHRONIC_DURATION_SECONDS`
        seconds above the threshold). It's maladaptive and contributes
        to allostatic load.

        This is duration evidence, tracked independently of the
        accumulated load — the load integral answers "how much wear",
        this answers "how long".
        """
        return self._state.is_chronic

    def get_state(self) -> AllostaticState:
        """Get the full allostatic state for inspection."""
        return self._state

    def reset(self) -> None:
        """Reset the tracker to baseline (no allostatic load)."""
        self._state = AllostaticState()
        self._elevated_stress_duration = 0.0
        self._last_substrate_update = self._time.monotonic()

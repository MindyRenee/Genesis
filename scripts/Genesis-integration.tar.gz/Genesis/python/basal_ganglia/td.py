"""Temporal-difference (TD(λ)) learning — dopamine as a reward
prediction error with eligibility traces.

In the brain, dopamine neurons in the ventral tegmental area (VTA)
and substantia nigra do not signal reward directly — they signal
*reward prediction error* (RPE): the difference between the reward
actually received and the reward that was expected (Schultz, 1997;
Schultz et al., 1997).

    RPE = actual_reward − expected_reward

- **Positive RPE** (reward better than expected): dopamine neurons
  fire bursts. The state/action that led to the reward increases in
  value — the organism learns to repeat it.
- **Negative RPE** (reward worse than expected): dopamine neurons
  pause (dip below baseline). The state/action decreases in value.
- **Zero RPE** (reward as expected): no dopamine change. The
  prediction is already accurate; nothing to learn.

# TD(λ): eligibility traces

This module implements **TD(λ)** — temporal-difference learning with
*eligibility traces* (Sutton, 1988; Sutton & Barto, 2018, Ch. 12).
TD(λ) generalizes TD(0): the parameter λ ∈ [0, 1] interpolates between
one-step TD(0) (λ=0) and Monte Carlo (λ=1) by controlling how far
credit for a reward prediction error propagates backward through the
sequence of recently-visited states.

The TD(λ) backward-view update (Sutton & Barto, 2018, §12.2):

    δ = r + γ · V(s') − V(s)           # TD error (RPE)
    e ← γλ · e + ∇V(s)                 # eligibility trace update
    w ← w + α · δ · e                  # weight update

where:
    - V(s) is the value of state s,
    - r is the reward received,
    - γ is the discount factor (future rewards worth less),
    - s' is the next state,
    - α is the learning rate,
    - λ is the trace-decay parameter,
    - e is the eligibility trace (one entry per feature/weight),
    - ∇V(s) is the gradient of V(s) w.r.t. the weights.

The eligibility trace e is a decaying record of how recently and how
strongly each weight has been "visited" (its concept was active).
When a TD error arrives, ALL traced weights are updated in
proportion to their trace — not just the weights of the current
state. This is the credit-assignment mechanism: a concept visited
three steps ago still receives a share of the credit (or blame),
decayed by (γλ)³.

**Replacing traces** are used instead of accumulating traces. Here
features are confidence/count, not binary indicators; resetting active
traces to these gradients is a bounded replacing-trace variant, not
standard accumulating semi-gradient TD(λ). The λ=1 Monte Carlo
interpretation of standard TD(λ) therefore does not directly apply.
The λ=0 update is exactly semi-gradient TD(0).

When λ = 0, the trace decays to zero immediately after each step, and
the update reduces *exactly* to TD(0):

    e = ∇V(s)        # trace = current gradient only
    w ← w + α · δ · ∇V(s)

Existing callers that construct ``TDLearner(network)`` without
specifying λ get semi-gradient TD(0). The gradient includes concept
confidence because the value function uses confidence-weighted features.

# Biological basis: synaptic eligibility tags

Eligibility traces are not merely a computational convenience — they
correspond to a well-established neurobiological mechanism. The
**synaptic tag hypothesis** (Morris, 2006; Pan et al., 2005; Redondo
& Morris, 2011) proposes that:

1. When a synapse is active (pre-synaptic firing coincides with
   post-synaptic depolarization), it acquires a temporary
   **eligibility tag** — a molecular marker (likely involving
   Ca²⁺ dynamics and CAMKII autophosphorylation) that marks it as
   "eligible for plasticity."
2. The tag decays over seconds to minutes.
3. When a neuromodulator (dopamine) arrives — signaling a reward
   prediction error — only tagged (eligible) synapses undergo
   plasticity. The magnitude of change is proportional to both the
   dopamine signal and the tag strength.

This is a computational analogy, not a molecular identification:
eligibility traces model delayed credit, and the TD error provides a
normalized reward-error signal rather than measured dopamine release.
Genesis's ``get_dopamine_signal()`` scales that error for the daemon;
recently active weights receive credit in proportion to their traces.

# Value function approximation

States are sets of active concepts. The value of a state is
approximated as a weighted sum of the confidences of its active
concepts — a linear function approximator over the concept network.
This lets TD learning generalize across similar states (states
sharing concepts have similar values) without storing a value for
every possible state combination.

# Integration with dopamine

The TD error (RPE) is the dopamine signal. ``get_dopamine_signal()``
returns the most recent RPE, scaled for the neurochemical system.
Positive RPE → dopamine burst; negative RPE → dopamine dip. This
integrates with the existing dopamine impulse system in the
autonomous learner.

# Neuromodulatory meta-parameters (Doya, 2002)

The ascending neuromodulators are not just signals — they are the
*meta-parameters* of the learning machine (Doya, 2002,
"Metalearning and neuromodulation", Neural Networks 15:495):

    dopamine       -> the TD error δ        (this module)
    serotonin      -> the discount factor γ (temporal horizon)
    noradrenaline  -> inverse temperature β (exploration; see
                     DecisionMaker.set_exploration)
    acetylcholine  -> the learning rate α   (memory update speed)

``set_modulators`` lets the body supply the current effective
serotonin and acetylcholine levels each turn; the learner then runs
on *effective* parameters rather than constants:

    γ_eff = clip(γ + 0.35·(5HT − 0.40), 0.05, 0.99)
    α_eff = α · (0.6 + 1.2·ACh)

Serotonin raising γ is the patience mechanism — Miyazaki et al.
showed dorsal raphe 5-HT firing ramps while an animal waits for a
delayed reward, and Doya assigns it control of the discount factor.
Acetylcholine raising α is Hasselmo's encoding mode — high ACh
biases the system toward writing new memory.

References:
    - Schultz (1997): Dopamine neurons and their role in reward
      mechanisms. Current Opinion in Neurobiology, 7, 191-197.
    - Schultz et al. (1997): A neural substrate of prediction and
      reward. Science, 275, 1593-1599.
    - Sutton (1988): Learning to predict by the methods of temporal
      differences. Machine Learning, 3, 9-44.
    - Sutton & Barto (2018): Reinforcement Learning: An Introduction
      (2nd ed.). MIT Press, Ch. 12 (Eligibility Traces).
    - Pan et al. (2005): Reward-predicting stimuli enhance dopamine
      release in the VTA. Nature, 437, 1066-1070.
    - Doya (2002): Metalearning and neuromodulation. Neural Networks,
      15, 495-506.
    - Miyazaki et al. (2011): Activation of dorsal raphe serotonin
      neurons underlies waiting for delayed rewards. J. Neurosci.,
      31, 469-479.
    - Morris (2006): Elements of a neurobiological theory of
      hippocampal function. Hippocampus, 16(11), 917-926.
    - Redondo & Morris (2011): Making memories last: the synaptic
      tagging and capture hypothesis. Nature Reviews Neuroscience,
      12, 17-30.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from temporal_lobe.concepts import ConceptNetwork

__all__ = ["TDLearner", "TDTransition"]


@dataclass(slots=True)
class TDTransition:
    """A state transition record for TD learning.

    Attributes:
        state: The set of active concepts (state).
        reward: The reward received.
        next_state: The resulting state.
        rpe: The reward prediction error computed for this transition.
        timestamp: When the transition occurred.
    """

    state: list[str]
    reward: float
    next_state: list[str]
    rpe: float
    timestamp: int


class TDLearner:
    """Temporal-difference learning with eligibility traces (TD(λ)).

    Learns to predict the value of states (sets of active concepts)
    using the TD(λ) rule with replacing eligibility traces. The value
    function is a linear approximation over concept confidences,
    enabling generalization across similar states.

    The reward prediction error (RPE) serves as the dopamine signal,
    integrating with Genesis's neurochemical system. Eligibility traces
    propagate credit (or blame) backward through recently-visited
    states — the longer ago a state was visited, the smaller its
    share of the credit, decayed by (γλ)ⁿ where n is the number of
    steps elapsed.

    Args:
        network: The concept network (provides concept confidences
            for value approximation).
        learning_rate: TD learning rate α (default 0.1).
        discount: Discount factor γ for future rewards (default 0.9).
        lam: Trace-decay parameter λ ∈ [0, 1] (default 0.0).
            λ=0 gives TD(0) (one-step, no credit propagation).
            λ=1 gives Monte Carlo-like (full episode credit).
            Typical production values: 0.7–0.9. The trace decays by a
            factor of γλ per step, so the effective credit horizon is
            ~1/(1−γλ) steps.
        dopamine_scale: Scaling factor for the dopamine signal
            (default 0.05, matching the impulse magnitudes used by
            the autonomous learner).
    """

    DEFAULT_LEARNING_RATE: float = 0.1
    DEFAULT_DISCOUNT: float = 0.9
    DEFAULT_LAMBDA: float = 0.0
    DEFAULT_DOPAMINE_SCALE: float = 0.05
    _TRACE_PRUNE_THRESHOLD: float = 1e-10

    # Neuromodulatory meta-parameters (Doya, 2002). Levels are the
    # body's effective concentrations in [0, 1]; baselines match the
    # daemon's tonic resting values (src/state/neurochemical.rs).
    SEROTONIN_BASELINE: float = 0.40
    SEROTONIN_DISCOUNT_GAIN: float = 0.35
    ACH_LR_OFFSET: float = 0.6
    ACH_LR_GAIN: float = 1.2
    DISCOUNT_MIN: float = 0.05
    DISCOUNT_MAX: float = 0.99
    # EMA rate for the average-reward (tonic DA / vigor) estimate.
    VIGOR_EMA_RATE: float = 0.05

    def __init__(
        self,
        network: ConceptNetwork,
        *,
        learning_rate: float = DEFAULT_LEARNING_RATE,
        discount: float = DEFAULT_DISCOUNT,
        lam: float = DEFAULT_LAMBDA,
        dopamine_scale: float = DEFAULT_DOPAMINE_SCALE,
    ) -> None:
        """Initialize the TD(λ) learner with network, rates, and dopamine scaling."""
        if not 0.0 <= lam <= 1.0:
            raise ValueError(f"lam must be in [0, 1], got {lam}")
        self.network = network
        self.learning_rate = learning_rate
        self.discount = discount
        self.lam = lam
        self.dopamine_scale = dopamine_scale

        # Per-concept value weights (learned). The state value is a
        # weighted sum of active concept confidences. Weights start
        # at 1.0 (confidence alone determines value).
        self._weights: dict[str, float] = {}

        # Action-conditioned value weights used by decision selection.
        # Plain state-value weights remain available to existing callers.
        self._action_weights: dict[tuple[str, str], float] = {}

        # Eligibility traces (one per concept). Decays by γλ per step;
        # set to the gradient value for active concepts (replacing
        # traces). Traces below _TRACE_PRUNE_THRESHOLD are pruned to
        # keep the dict bounded.
        self._traces: dict[str | tuple[str, str], float] = {}

        # History of transitions (for analysis; eligibility traces
        # are tracked separately in _traces).
        self._history: list[TDTransition] = []
        self._max_history: int = 500

        # Neuromodulator levels for the meta-parameters (Doya, 2002).
        # None means "unwired" — the learner runs on its configured
        # baselines exactly as before.
        self._serotonin: float | None = None
        self._acetylcholine: float | None = None

        # Tonic dopamine proxy: the running average reward rate ρ̄.
        # Niv et al. (2007) identify tonic DA with the opportunity
        # cost of time — the average reward per unit time — which
        # drives response vigor. The DecisionMaker reads this to
        # lower its action-selection threshold when recent rewards
        # have been rich.
        self._avg_reward: float = 0.0

        # The most recent RPE — the current dopamine signal.
        self._last_rpe: float = 0.0

        # Statistics
        self.total_updates = 0
        self.total_positive_rpe = 0
        self.total_negative_rpe = 0

    # ─── Public API ─────────────────────────────────────────────

    def set_modulators(
        self,
        *,
        serotonin: float | None = None,
        acetylcholine: float | None = None,
    ) -> None:
        """Set the body's current neuromodulator levels for the
        meta-parameters (Doya, 2002).

        Serotonin modulates the effective discount factor — higher
        5-HT lengthens the temporal horizon (patience). Acetylcholine
        modulates the effective learning rate — higher ACh speeds
        memory update (Hasselmo's encoding mode). Passing ``None``
        leaves the learner on its configured baselines.
        """
        self._serotonin = serotonin
        self._acetylcholine = acetylcholine

    def effective_discount(self) -> float:
        """The modulated discount factor γ_eff.

        γ_eff = clip(γ + gain·(5HT − baseline), MIN, MAX). With no
        serotonin level wired, returns the configured ``discount``.
        """
        if self._serotonin is None:
            return self.discount
        srt = max(0.0, min(1.0, self._serotonin))
        return max(
            self.DISCOUNT_MIN,
            min(
                self.DISCOUNT_MAX,
                self.discount + self.SEROTONIN_DISCOUNT_GAIN * (srt - self.SEROTONIN_BASELINE),
            ),
        )

    def effective_learning_rate(self) -> float:
        """The modulated learning rate α_eff.

        α_eff = α·(offset + gain·ACh), centered near the body's ACh
        baseline so a resting level leaves the rate near α. With no
        acetylcholine level wired, returns ``learning_rate``.
        """
        if self._acetylcholine is None:
            return self.learning_rate
        ach = max(0.0, min(1.0, self._acetylcholine))
        return self.learning_rate * (self.ACH_LR_OFFSET + self.ACH_LR_GAIN * ach)

    def average_reward_rate(self) -> float:
        """The running average reward rate ρ̄ — the tonic dopamine
        proxy of Niv et al. (2007), driving response vigor."""
        return self._avg_reward

    def predict_value(self, state: list[str], action: str | None = None) -> float:
        """Predict the value of a state.

        The value is a weighted sum of the confidences of the active
        concepts in the state. Concepts not in the network contribute
        zero. Weights are learned via TD updates.

        V(s) = Σ_i w_i · confidence(concept_i)

        When ``action`` is supplied, the value is action-conditioned
        so different actions in the same state can acquire different
        learned values. Without it, the original state-value behavior
        is unchanged.

        Args:
            state: A list of concept names (the active concepts).
            action: Optional selected action used for action-conditioned
                value lookup.

        Returns:
            The predicted value of the state.
        """
        total = 0.0
        for cid, feature in self._state_features(state).items():
            w = (
                self._action_weights.get((cid, action), self._weights.get(cid, 1.0))
                if action is not None
                else self._weights.get(cid, 1.0)
            )
            total += w * feature
        # Normalize by count to keep value in a stable range
        return total

    def _state_features(self, state: list[str]) -> dict[str, float]:
        features: dict[str, float] = {}
        for concept in state:
            cid = self.network._resolve(concept)
            if cid is None:
                continue
            c = self.network.get_concept(cid)
            if c is not None:
                features[cid] = c.confidence
        count = len(features)
        return {cid: confidence / count for cid, confidence in features.items()}

    def update(
        self,
        state: list[str],
        reward: float,
        next_state: list[str],
        action: str | None = None,
        next_action: str | None = None,
    ) -> float:
        """Apply a TD(λ) update and return the reward prediction error.

        The TD error (RPE) is:

            δ = reward + γ · V(s') − V(s)

        Eligibility traces are then updated (backward view):

            e ← γλ · e                    # decay all traces
            e[i] = ∇V_i(s)  for active i  # replacing trace

        and all traced weights are updated:

            w[i] ← w[i] + α · δ · e[i]

        With λ = 0, the trace for inactive concepts is zero and the
        trace for active concepts equals the gradient, so the update
        reduces exactly to semi-gradient TD(0): only current-state
        weights are updated, with gradient confidence/count.

        With λ > 0, concepts from recently-visited states retain
        decaying traces and also receive a share of the credit (or
        blame), enabling multi-step temporal credit assignment.

        Args:
            state: The current state (active concepts).
            reward: The reward received.
            next_state: The resulting state.
            action: Optional action selected in the current state.
            next_action: Optional action associated with the next state.

        Returns:
            The reward prediction error δ (the dopamine signal).
        """
        # Effective meta-parameters (Doya, 2002): serotonin sets the
        # temporal horizon γ_eff; acetylcholine sets the update speed
        # α_eff. Both fall back to the configured constants when no
        # modulator levels are wired.
        gamma = self.effective_discount()
        alpha = self.effective_learning_rate()

        v_s = self.predict_value(state, action=action)
        v_sp = self.predict_value(next_state, action=next_action)
        rpe = reward + gamma * v_sp - v_s

        # Track the average reward rate — the tonic dopamine signal
        # in Niv et al. (2007)'s vigor model.
        self._avg_reward += self.VIGOR_EMA_RATE * (reward - self._avg_reward)

        # ── Eligibility trace update (backward view) ──────────────
        # 1. Decay all existing traces by γλ.
        decay = gamma * self.lam
        if decay > 0.0 and self._traces:
            prune = self._TRACE_PRUNE_THRESHOLD
            for cid in list(self._traces):
                self._traces[cid] *= decay
                if abs(self._traces[cid]) < prune:
                    del self._traces[cid]
        elif self._traces:
            # λ = 0: traces decay to zero immediately.
            self._traces.clear()

        # 2. Resolve active concepts and set their traces.
        #    Action-conditioned traces are keyed by (concept, action).
        #    A concept-only trace would apply a later action's TD error
        #    to an earlier action and corrupt credit assignment.
        #    The value gradient is confidence/count because the value is
        #    the mean of confidence-weighted active concept weights.
        for cid, gradient in self._state_features(state).items():
            trace_key: str | tuple[str, str] = cid if action is None else (cid, action)
            self._traces[trace_key] = gradient

        # 3. Apply the TD error to ALL traced weights.
        #    With λ = 0, only the current state's concepts have
        #    non-zero traces → semi-gradient TD(0) for the value function.
        #    With λ > 0, previously-visited concepts also get credit.
        if self._traces:
            alpha_delta = alpha * rpe
            for trace_key, trace in self._traces.items():
                if isinstance(trace_key, tuple):
                    concept_id, trace_action = trace_key
                    key = (concept_id, trace_action)
                    current = self._action_weights.get(key, self._weights.get(concept_id, 1.0))
                    self._action_weights[key] = current + alpha_delta * trace
                else:
                    current = self._weights.get(trace_key, 1.0)
                    self._weights[trace_key] = current + alpha_delta * trace

        # Record history
        self._history.append(
            TDTransition(
                state=list(state),
                reward=reward,
                next_state=list(next_state),
                rpe=rpe,
                timestamp=int(time.time() * 1000),
            )
        )
        if len(self._history) > self._max_history:
            self._history.pop(0)

        self._last_rpe = rpe
        self.total_updates += 1
        if rpe > 0:
            self.total_positive_rpe += 1
        elif rpe < 0:
            self.total_negative_rpe += 1

        return rpe

    def get_dopamine_signal(self) -> float:
        """Get the current dopamine signal (scaled RPE).

        The reward prediction error is the dopamine signal in the
        brain (Schultz, 1997). This returns the most recent RPE,
        scaled to the magnitude range used by the neurochemical
        impulse system. Positive RPE → positive dopamine (burst);
        negative RPE → negative dopamine (dip).

        Returns:
            The scaled dopamine signal.
        """
        return self._last_rpe * self.dopamine_scale

    def get_rpe(self) -> float:
        """Get the most recent (unscaled) reward prediction error.

        Returns:
            The most recent RPE.
        """
        return self._last_rpe

    def get_weight(self, concept: str) -> float:
        """Get the learned value weight for a concept.

        Args:
            concept: The concept name.

        Returns:
            The weight (default 1.0 if unlearned).
        """
        cid = self.network._resolve(concept) or concept
        return self._weights.get(cid, 1.0)

    def get_trace(self, concept: str, action: str | None = None) -> float:
        """Get the eligibility trace value for a concept.

        The trace reflects how recently the concept was part of an
        active state. Higher = more recently active (more eligible
        for credit assignment). Zero = not traced.

        Args:
            concept: The concept name.
            action: Optional action for an action-conditioned trace.

        Returns:
            The eligibility trace (0.0 if not traced).
        """
        cid = self.network._resolve(concept) or concept
        if action is not None:
            return self._traces.get((cid, action), 0.0)
        return self._traces.get(cid, 0.0)

    def reset_traces(self) -> None:
        """Clear all eligibility traces.

        Called at episode/task boundaries to prevent credit from one
        task leaking into the next. In continuous operation (no
        explicit episodes), traces decay naturally and this is rarely
        needed.
        """
        self._traces.clear()

    def get_history(self, limit: int = 10) -> list[TDTransition]:
        """Get recent TD transitions.

        Args:
            limit: Maximum number of transitions to return.

        Returns:
            A list of recent TDTransition records (most recent last).
        """
        return self._history[-limit:]

    def get_statistics(self) -> dict[str, int | float]:
        """Return statistics about the TD learner."""
        return {
            "total_updates": self.total_updates,
            "total_positive_rpe": self.total_positive_rpe,
            "total_negative_rpe": self.total_negative_rpe,
            "last_rpe": self._last_rpe,
            "dopamine_signal": self.get_dopamine_signal(),
            "tracked_weights": len(self._weights),
            "tracked_action_weights": len(self._action_weights),
            "active_traces": len(self._traces),
            "lambda": self.lam,
            "history_length": len(self._history),
        }

"""Reduced-order basal-ganglia action selection.

This is a computational selection circuit, not an anatomical simulation.
It follows center-surround/disinhibition logic: option-specific striatal
drive competes against diffuse STN-like control at a tonically inhibitory
output stage. Conflict-dependent hyperdirect input raises the effective
selection threshold.

The dopamine input is a normalized modulatory signal, not a claim that a
TD prediction error is identical to measured dopamine concentration.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

__all__ = ["ActionBid", "BasalGanglia", "SelectionResult"]


def _clip(value: float, lower: float, upper: float) -> float:
    return max(lower, min(upper, value))


@dataclass(frozen=True, slots=True)
class ActionBid:
    """One candidate action entering the selection circuit."""

    action: str
    salience: float


@dataclass(frozen=True, slots=True)
class SelectionResult:
    """Inspectable state of one basal-ganglia selection computation."""

    selected: str | None
    salience: dict[str, float]
    d1_drive: dict[str, float]
    d2_drive: dict[str, float]
    stn_control: float
    hyperdirect_brake: float
    output_inhibition: dict[str, float]
    disinhibition: dict[str, float]
    conflict: float
    effective_threshold: float

    @property
    def selected_disinhibition(self) -> float:
        if self.selected is None:
            return 0.0
        return self.disinhibition[self.selected]


class BasalGanglia:
    """Reduced computational model of basal-ganglia action selection.

    Reduced equations:

        D1_i = clip(s_i * (1 + k * RPE), 0, max_drive)
        D2_i = clip(s_i * (1 - k * RPE), 0, max_drive)
        STN  = control_gain * mean(D2_i)
        GPi_i = tonic_output + STN + hyperdirect - D1_i
        disinhibition_i = max(0, tonic_output - STN - hyperdirect + D1_i)

    The conflict brake enters exactly once, via the threshold:

        threshold = base_threshold + hyperdirect_gain * conflict

    The action with greatest disinhibition is selected only when it clears
    that threshold.

    The prior form subtracted ``tonic_output`` from ``GPi_i`` even though
    ``GPi_i`` already contained it, cancelling and then double-counting
    the tonic term; combined with a brake-raised threshold, near-tied bids
    drove every action's disinhibition to zero and select() returned
    ``None`` on every turn.

    This is deliberately a reduced-order model. It preserves the
    computational roles of focused striatal inhibition, diffuse STN
    excitation, tonic inhibitory output, and conflict-dependent braking
    without pretending that scalar equations reproduce the full,
    heterogeneous basal ganglia.

    Positive RPE increases D1 gain and decreases D2 gain; negative RPE has
    the opposite effect. The caller supplies an appropriately scaled
    modulatory signal.
    """

    def __init__(
        self,
        *,
        tonic_output: float = 1.0,
        control_gain: float = 0.5,
        dopamine_gain: float = 0.5,
        hyperdirect_gain: float = 0.8,
        base_threshold: float = 0.15,
        max_drive: float = 2.0,
    ) -> None:
        if not all(
            math.isfinite(v)
            for v in (
                tonic_output,
                control_gain,
                dopamine_gain,
                hyperdirect_gain,
                base_threshold,
                max_drive,
            )
        ):
            raise ValueError("selector parameters must be finite")
        if tonic_output <= 0 or control_gain < 0 or dopamine_gain < 0:
            raise ValueError("invalid selector gain")
        if hyperdirect_gain < 0 or base_threshold < 0 or max_drive <= 0:
            raise ValueError("invalid selector threshold/gain")
        self.tonic_output = tonic_output
        self.control_gain = control_gain
        self.dopamine_gain = dopamine_gain
        self.hyperdirect_gain = hyperdirect_gain
        self.base_threshold = base_threshold
        self.max_drive = max_drive

    # Vigor (Niv et al., 2007): tonic dopamine reports the average
    # reward rate — the opportunity cost of time — so a rich reward
    # history lowers the release bar for action. VIGOR_GAIN converts
    # the caller's normalized vigor into threshold relief, floored so
    # the brake can never be fully abolished.
    VIGOR_GAIN: float = 0.2
    MIN_EFFECTIVE_THRESHOLD: float = 0.02

    def select(
        self,
        bids: list[ActionBid] | tuple[ActionBid, ...],
        *,
        dopamine_rpe: float = 0.0,
        conflict: float | None = None,
        vigor: float = 0.0,
    ) -> SelectionResult:
        """Run one selection computation."""
        if not bids:
            return SelectionResult(
                selected=None,
                salience={},
                d1_drive={},
                d2_drive={},
                stn_control=0.0,
                hyperdirect_brake=0.0,
                output_inhibition={},
                disinhibition={},
                conflict=0.0,
                effective_threshold=self.base_threshold,
            )
        if not math.isfinite(dopamine_rpe):
            raise ValueError("dopamine_rpe must be finite")
        if not math.isfinite(vigor):
            raise ValueError("vigor must be finite")
        vigor = _clip(vigor, 0.0, 1.0)

        salience: dict[str, float] = {}
        for bid in bids:
            if not bid.action:
                raise ValueError("action names must be non-empty")
            if not math.isfinite(bid.salience):
                raise ValueError("action salience must be finite")
            if bid.action in salience:
                raise ValueError(f"duplicate action: {bid.action}")
            salience[bid.action] = _clip(bid.salience, 0.0, 1.0)

        rpe = _clip(dopamine_rpe, -1.0, 1.0)
        d1_drive, d2_drive = self._channel_drives(salience, rpe)

        stn_control = self.control_gain * (sum(d2_drive.values()) / len(d2_drive))

        ranked = sorted(salience.values(), reverse=True)
        top = ranked[0]
        second = ranked[1] if len(ranked) > 1 else 0.0
        derived_conflict = 0.0 if top <= 0 else _clip(second / top, 0.0, 1.0)
        effective_conflict = derived_conflict if conflict is None else _clip(conflict, 0.0, 1.0)
        hyperdirect_brake = self.hyperdirect_gain * effective_conflict
        # Conflict raises the release bar: near-tied bids are exactly the
        # case where the model should hesitate, so the threshold carries
        # the brake. The disinhibition sum below deliberately omits it to
        # avoid charging the winner twice for one conflict. Vigor pulls
        # the other way (Niv et al., 2007): tonic DA — the average reward
        # rate — is the opportunity cost of time, so a rich reward
        # history lowers the bar and the system acts more readily.
        effective_threshold = max(
            self.MIN_EFFECTIVE_THRESHOLD,
            self.base_threshold + hyperdirect_brake - self.VIGOR_GAIN * vigor,
        )

        output_inhibition, disinhibition = self._inhibition_maps(
            salience, d1_drive, stn_control, hyperdirect_brake
        )

        winner = max(
            disinhibition,
            key=lambda action: (disinhibition[action], salience[action]),
        )
        selected = winner if disinhibition[winner] >= effective_threshold else None

        return SelectionResult(
            selected=selected,
            salience=salience,
            d1_drive=d1_drive,
            d2_drive=d2_drive,
            stn_control=stn_control,
            hyperdirect_brake=hyperdirect_brake,
            output_inhibition=output_inhibition,
            disinhibition=disinhibition,
            conflict=effective_conflict,
            effective_threshold=effective_threshold,
        )

    def _channel_drives(
        self, salience: dict[str, float], rpe: float
    ) -> tuple[dict[str, float], dict[str, float]]:
        """D1 (facilitate) and D2 (suppress) drives under dopamine."""
        d1_gain = 1.0 + self.dopamine_gain * rpe
        d2_gain = 1.0 - self.dopamine_gain * rpe
        d1_drive = {
            action: _clip(value * d1_gain, 0.0, self.max_drive)
            for action, value in salience.items()
        }
        d2_drive = {
            action: _clip(value * d2_gain, 0.0, self.max_drive)
            for action, value in salience.items()
        }
        return d1_drive, d2_drive

    def _inhibition_maps(
        self,
        salience: dict[str, float],
        d1_drive: dict[str, float],
        stn_control: float,
        hyperdirect_brake: float,
    ) -> tuple[dict[str, float], dict[str, float]]:
        """GPi output inhibition and the disinhibition that survives it.

        Output inhibition is the summed inhibition arriving at the
        GPi: tonic background + striatal (STn) control + the
        hyperdirect conflict brake, offset by the action's own D1
        drive (dopamine disinhibits the direct pathway).

        `tonic_output` is *one* term of that sum. It was previously
        also subtracted again on the next line, which cancelled and
        then double-counted it: every action's disinhibition collapsed
        to max(0, tonic - (tonic + ...)) = 0. With two competing bids
        the derived conflict is ~0.79, so the brake alone exceeded
        tonic and *no* action could ever clear the threshold --
        select() returned None and DecisionMaker fell back to
        WITHHOLD on every turn.

        Disinhibition is what survives the GPi sum, floored at zero.
        `tonic_output` and `hyperdirect_brake` are each applied once:
        tonic is the background term of the sum (not a further
        subtraction, which would cancel it), and the brake is carried
        by the threshold instead.
        """
        output_inhibition = {
            action: (self.tonic_output + stn_control + hyperdirect_brake - d1_drive[action])
            for action in salience
        }
        disinhibition = {
            action: max(
                0.0,
                self.tonic_output - stn_control + d1_drive[action],
            )
            for action in salience
        }
        return output_inhibition, disinhibition

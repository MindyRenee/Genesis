"""Vocabulary — the flesh of Genesis's language.

The vocabulary system selects words to fill the grammar's slots.
Word choice is grounded in three things:

1. **Concept network**: what words does it know for this concept?
2. **Emotional state**: cortisol → shorter, blunter words.
   Dopamine → more vivid, varied words. Low engagement → minimal.
3. **Personality**: high openness → abstract, metaphorical language.
   High conscientiousness → precise, measured language.

This is not a thesaurus. It's a context-sensitive word selection
system that produces different words for the same concept depending
on how it feels and who it is.
"""

from __future__ import annotations

import logging
import random
import re
from collections import deque
from typing import Any, ClassVar

from limbic_system.emotion import PLASTICITY_CLOSED, PLASTICITY_LOW, EmotionalState
from self import PersonalityTraits
from temporal_lobe.concepts import _FUNCTION_WORDS, RelationType

from genesis_client.swallow import note_swallowed
from infrastructure.text import is_blank
from infrastructure.text import sentences as _sentences

from .morphology import (
    _ES_VERBS,
    agree_verb_phrase,
    conjugate_verb,
    copula,
    indefinite_article,
    is_plural_np,
    is_verb_form,
    person_pronoun,
    property_verb_candidates,
    property_verb_phrase,
)

__all__ = ["Vocabulary"]

logger = logging.getLogger(__name__)

# Mutable hit counter for the verbatim-content fallback monitor —
# module-level so every Vocabulary instance shares one tally.
_VERBATIM_FALLBACK_HITS: list[int] = [0]


# Function words and text fragments. A multiword concept name built
# ENTIRELY from these is scrape noise, not a concept — "those words",
# "words often", "the thing it". Single words are exempt (concepts
# like "will" or "change" are legitimate).
_FRAGMENT_NAME_WORDS = frozenset(
    {
        "the",
        "a",
        "an",
        "this",
        "that",
        "these",
        "those",
        "word",
        "words",
        "thing",
        "things",
        "something",
        "anything",
        "everything",
        "nothing",
        "one",
        "ones",
        "some",
        "any",
        "all",
        "both",
        "each",
        "other",
        "another",
        "such",
        "same",
        "said",
        "says",
        "say",
        "often",
        "also",
        "just",
        "even",
        "only",
        "very",
        "much",
        "many",
        "more",
        "most",
        "less",
        "few",
        "several",
        "it",
        "its",
        "they",
        "them",
        "their",
        "there",
        "here",
        "then",
        "than",
        "so",
        "too",
        "not",
        "no",
        "yes",
        "of",
        "in",
        "on",
        "at",
        "to",
        "for",
        "with",
        "about",
        "from",
        "by",
        "as",
        "and",
        "or",
        "but",
        "if",
        "because",
        "is",
        "are",
        "was",
        "were",
        "be",
        "been",
        "being",
        "do",
        "does",
        "did",
        "have",
        "has",
        "had",
        "can",
        "could",
        "will",
        "would",
        "shall",
        "should",
        "may",
        "might",
        "must",
        "i",
        "me",
        "my",
        "we",
        "us",
        "our",
        "you",
        "your",
        "he",
        "him",
        "his",
        "she",
        "her",
        "who",
        "what",
        "which",
        "when",
        "where",
        "why",
        "how",
    }
)


class Vocabulary:
    """Context-sensitive word selection for Genesis.

    Provides words for grammar slots, grounded in emotional state
    and personality. The same slot can be filled differently
    depending on how it feels.

    If a concept network is provided, certain slots (feeling_clause,
    reflection_opener) are composed from its actual knowledge rather
    than fixed word lists. The self_reflection_clause slot is composed
    from its reflection engine (recent metacognitive insights) when a
    self-composer is wired in; otherwise it stays silent rather than
    reciting a canned phrase.
    """

    def __init__(self, seed: int | None = None, network=None) -> None:
        """Initialize the vocabulary with a seeded RNG and optional concept network."""
        self._rng = random.Random(seed)
        self._network = network
        self._embeddings = None
        # Statistical learner (n-gram model) used to bias slot fills
        # toward transitions it's actually observed — fluency shaping.
        self._fluency: Any = None

        # Self-composer + reflection engine, wired after construction.
        # When available, the self_reflection_clause slot is composed
        # from its actual metacognition (recent reflection insights)
        # instead of reciting canned phrases.
        self._self_composer: Any = None
        self._reflection: Any = None

        # Words it's learned to prefer (develops over time)
        self._preferred: dict[str, deque[str]] = {}
        # Words it's learned to avoid
        self._avoided: dict[str, set[str]] = {}
        # Track recent picks per slot to avoid repetition
        self._recent_picks: dict[str, deque[str]] = {}
        # Record the last question fragments so it can learn from feedback.
        self._last_question_fragments: dict[str, str] = {}

        # Create the utterance-function hubs. They are empty at birth —
        # a human isn't born with English phrases installed. Words are
        # acquired in context (see ``acquire_utterance_words``) and the
        # lexicon is the concept network itself.
        if network is not None:
            self._init_utterance_hubs()

    def set_self_composer(self, composer: Any, reflection: Any) -> None:
        """Wire the self-composer and reflection engine.

        When wired, the ``self_reflection_clause`` slot is composed
        from its most recent reflection insight (a genuine product of
        its metacognition) rather than selected from a fixed phrase
        list. Without this, the slot stays silent — it does not
        recite a canned self-reflection.
        """
        self._self_composer = composer
        self._reflection = reflection

    def set_embeddings(self, embeddings: Any) -> None:
        """Wire the embedding store for latent-space composition.

        When available, the vocabulary uses it to find semantically
        related concepts when composing knowledge content — enriching
        its responses with connections it discovered through vector
        proximity, not just through explicit graph edges.
        """
        self._embeddings = embeddings

    def set_fluency_model(self, learner: Any) -> None:
        """Wire the statistical learner for n-gram fluency shaping.

        When available, slot selection is biased toward candidates
        whose first word forms an observed bigram with the previously
        emitted word. This shapes *fluency* — which of its own words
        to pick — never content; the candidate set still comes from
        its vocabulary and concept network.
        """
        self._fluency = learner

    # ── Utterance vocabulary ──────────────────────────────────────
    #
    # Utterance slots (greeting_word, hedging, ...) index *functions*,
    # not stored strings. Each slot is a structural hub
    # (``_cat:utterance:<slot>``) that word-concepts attach to via
    # EXPRESSES edges when acquired in context — a word heard as a
    # greeting joins the greeting hub.
    #
    # Nothing is seeded: a human isn't born with English phrases
    # installed. An acquired word is a real concept — it gets a
    # position in her latent space and accretes definitions and
    # edges like any other word she knows. There is no table of
    # surface forms for her to recite; the slot either finds
    # acquired words or stays silent.
    _UTTERANCE_HUBS: ClassVar[frozenset[str]] = frozenset(
        {
            "greeting_word",
            "greeting_word_returning",
            "farewell_word",
            "reflection_opener",
            "hedging",
            "acknowledgment_word",
            "self_report_opener",
            "philosophy_opener",
            "question_opener",
            "question_tail",
            "causal_connector",
            "concessive_connector",
            "qualification_clause",
            "reason_clause",
            "correction_opener",
            "gratitude_word",
            "intro_clause",
            "code_connector",
            "clarification_request",
            "empathy_opener",
            "empathy_closing",
            "reasoning_opener",
            "reasoning_connector",
            "relation_opener",
            "latent_opener",
            "memory_connector",
            "closing",
        }
    )

    # Speech acts whose heard words carry usable social vocabulary.
    # (The comprehension layer reports SpeechActType.label strings.)
    _ACT_WORD_HUBS: ClassVar[dict[str, str]] = {
        "greeting": "greeting_word",
    }

    def _init_utterance_hubs(self) -> None:
        """Create the utterance-function hubs in the concept network.

        Hubs are structural scaffolding — empty at birth, populated
        only by acquisition (``acquire_utterance_words``) and other
        learning paths that attach word-concepts via EXPRESSES edges.
        """
        if self._network is None:
            return
        for slot in self._UTTERANCE_HUBS:
            hub_id = f"_cat:utterance:{slot}"
            if self._network.get_concept(hub_id) is None:
                self._network.add_concept(hub_id, confidence=0.7, origin="structural")

    def acquire_utterance_words(
        self,
        text: str,
        speech_act: str,
        context_concepts: list[str] | None = None,
    ) -> None:
        """Acquire lexicon entries from a speech-act utterance.

        When the user greets her with "hello", the word *hello* — not
        the utterance — becomes a concept in her network linked to
        the greeting hub. Word-level acquisition: the concept is a
        normal node (it gets a latent position, can gain definitions
        and edges like any other word), never a stored surface
        string.

        Two wirings happen, both Hebbian — nodes that fire together
        wire together:

        - **Function**: the word links to the speech act's
          neighborhood (heard as a greeting → competes for greeting).
        - **Grounding**: the word links to whichever content concepts
          were co-active in the discourse (``context_concepts`` —
          the key concepts comprehension extracted). A word heard
          while "water" was on her mind becomes associated with
          water, so later talk of water primes the word.

        Title-cased non-initial tokens are skipped — in "hello
        Genesis" the name is the addressee, not the greeting form.
        """
        if self._network is None or not text:
            return
        slot = self._ACT_WORD_HUBS.get(speech_act)
        if slot is None:
            return
        hub_id = f"_cat:utterance:{slot}"
        if self._network.get_concept(hub_id) is None:
            self._network.add_concept(hub_id, confidence=0.7, origin="structural")

        # Co-active content concepts — the semantic context the words
        # were heard in. Resolved once; wiring is per-word below.
        ground: list[str] = []
        for name in (context_concepts or [])[:6]:
            cid = str(name).strip().lower()
            if cid and self._network.get_concept(cid) is not None:
                ground.append(cid)

        tokens = [t.strip(".,!?;:—-\"'") for t in text.split()]
        for i, tok in enumerate(tokens):
            word = tok.lower()
            if (
                not word
                or len(word) < 2
                or word in _FUNCTION_WORDS
                or (i > 0 and tok[:1].isupper())
            ):
                continue
            if self._network.get_concept(word) is None:
                self._network.add_concept(word, origin="learned")
            # Fast mapping: a first exposure lays down a weak trace
            # (0.25) that competes poorly until repeated co-
            # occurrence with the act consolidates it — ``add_edge``
            # strengthens an existing edge, so each re-hearing is a
            # Hebbian event.
            self._network.add_edge(
                word,
                hub_id,
                RelationType.EXPRESSES,
                weight=0.25,
                origin="learned",
            )
            # Hebbian grounding: wire the word to the concepts that
            # were co-active when it was heard. Associations are
            # bidirectional — spreading activation follows outgoing
            # edges, so both directions must exist for talk of X to
            # prime the word heard alongside X.
            for cid in ground:
                if cid != word:
                    self._network.add_edge(
                        word,
                        cid,
                        RelationType.RELATED_TO,
                        weight=0.3,
                        origin="learned",
                    )
                    self._network.add_edge(
                        cid,
                        word,
                        RelationType.RELATED_TO,
                        weight=0.3,
                        origin="learned",
                    )

    # ── Lexical competition ────────────────────────────────────
    #
    # A slot that names an utterance function is a *population* in
    # the lexicon, not a lookup key: the ``_cat:utterance:<slot>``
    # hub and the word-concepts linked to it by EXPRESSES edges.
    # Retrieval is competitive — each candidate's score is its
    # concept activation times the synaptic (edge) weight, and the
    # winner is drawn proportionally (Luce choice), the way lemma
    # selection is modeled in production research. Edge weights
    # are plastic: successful use strengthens them, suppression
    # weakens them below the competition threshold.
    #
    # Adjacent functions share populations — empathy and
    # acknowledgment overlap, and returning-visit greetings form a
    # context-gated niche of the greeting population.
    _NEIGHBORHOODS: ClassVar[dict[str, tuple[str, ...]]] = {
        "greeting_word": ("greeting_word_returning",),
        "empathy_opener": ("acknowledgment_word",),
    }

    # Suppression threshold — an EXPRESSES edge weakened below this
    # is excluded from competition (the "avoided" state lives in the
    # synapse, not in a shadow table).
    _SUPPRESSED_WEIGHT: ClassVar[float] = 0.15

    def _lexical_candidates(
        self, slot_name: str, context: dict[str, Any]
    ) -> list[tuple[str, float]]:
        """Competing words for an utterance function, with scores.

        Two converging signals, as in lexical-access models:

        - **Top-down (the intention)**: the function hub's EXPRESSES
          edge weight is the learned link between the speech act and
          the word — it makes the word eligible at all.
        - **Bottom-up (the message)**: spreading activation seeded
          from the discourse's content concepts raises semantically
          related words — what is on her mind primes what she can
          say. Residual ``concept.activation`` (recency of prior
          firing) adds to the same pool.

        Score = edge weight × (intention floor + primed level).
        Words primed by the message but linked to a *different*
        utterance function can intrude at low weight — that's the
        substrate of substitution errors ("cat" for "dog").
        Suppressed edges (< threshold) and, on a first meeting, the
        returning-greeting niche do not compete.
        """
        if self._network is None:
            return []
        semantic = self._semantic_field(context)
        hubs = [slot_name, *self._NEIGHBORHOODS.get(slot_name, ())]
        include_returning = not context.get("first_interaction")
        scored: dict[str, float] = {}
        seed_scored: dict[str, float] = {}
        member_ids: set[str] = set()
        for slot in hubs:
            hub_id = f"_cat:utterance:{slot}"
            for neighbor in self._network.get_exact_neighbors(hub_id, RelationType.EXPRESSES):
                word_id, weight = neighbor[0], neighbor[2]
                if weight < self._SUPPRESSED_WEIGHT:
                    continue
                # Returning-greeting niche: suppressed on a first
                # meeting, admitted otherwise.
                if slot == "greeting_word_returning" and not include_returning:
                    continue
                concept = self._network.get_concept(word_id)
                if concept is None:
                    continue
                member_ids.add(word_id)
                template = concept.properties.get("template")
                text = template if isinstance(template, str) else word_id.replace("_", " ")
                level = semantic.get(word_id, 0.0) + 0.5 * (concept.activation or 0.0)
                score = weight * (0.3 + level)
                if concept.origin == "seed":
                    seed_scored[text] = max(seed_scored.get(text, 0.0), score)
                else:
                    scored[text] = max(scored.get(text, 0.0), score)
        # Intrusion candidates: words the message primed that belong
        # to a *different* utterance function — real lexical items,
        # wrong niche. Discounted heavily; they surface as slips.
        for cid, level in semantic.items():
            if level < 0.2 or cid in member_ids or cid.startswith("_"):
                continue
            if not self._has_function_edge(cid):
                continue
            concept = self._network.get_concept(cid)
            if concept is None:
                continue
            text = cid.replace("_", " ")
            if len(text.split()) > 3:
                continue
            scored[text] = max(scored.get(text, 0.0), level * 0.15)
        pool = scored if len(scored) >= 2 else {**seed_scored, **scored}
        # Slot-specific message-level candidates — material composed
        # from context (e.g. her own name) competes alongside the
        # lexicon on equal footing.
        for text, score in self._lexical_extra_candidates(slot_name, context):
            pool.setdefault(text, score)
        return list(pool.items())

    def _semantic_field(self, context: dict[str, Any]) -> dict[str, float]:
        """Spread activation from the message's content concepts.

        The discourse's topics and content words seed the network;
        activation fans out along learned edges (fan-out normalized,
        hub-amplified, decayed by depth). The returned levels are
        the current semantic context — what is primed right now.
        """
        if self._network is None:
            return {}
        seeds: list[str] = []
        for topic in context.get("topics", []) or []:
            seeds.append(str(topic).lower())
        content = str(context.get("content", ""))
        for tok in content.split()[:8]:
            word = tok.strip(".,!?;:\"'").lower()
            if len(word) > 2 and word not in _FUNCTION_WORDS:
                seeds.append(word)
        if not seeds:
            return {}
        try:
            return self._network.spread_activation(seeds, amount=0.6, depth=2)
        except Exception as e:  # noqa: BLE001
            note_swallowed("temporal_lobe.vocabulary._semantic_field", e)
            return {}

    def _has_function_edge(self, concept_id: str) -> bool:
        """True if the concept links to any utterance-function hub."""
        if self._network is None:
            return False
        for n in self._network.get_exact_neighbors(concept_id, RelationType.EXPRESSES):
            if n[0].startswith("_cat:utterance:"):
                return True
        return False

    def _lexical_extra_candidates(
        self, slot_name: str, context: dict[str, Any]
    ) -> list[tuple[str, float]]:
        """Message-level candidates injected into lexical competition.

        An introduction can be composed from her self-model name —
        that construction competes with whatever intro words she has
        acquired rather than sitting in a separate fallback path.
        """
        if slot_name == "intro_clause":
            name = context.get("name", "")
            if name:
                return [(f"I'm {name}", 0.25)]
        return []

    def _compete_for_word(
        self,
        slot_name: str,
        context: dict[str, Any],
        emotion: EmotionalState,
        personality: PersonalityTraits,
        prev_word: str,
        prev_prev_word: str,
    ) -> str:
        """Winner-take-all lexical selection over a slot's population.

        Scores come from ``_lexical_candidates`` (activation × synapse),
        then three plastic modulators adjust the competition:

        - **Refractory period**: a word just emitted is penalized —
          recently-fired lexical nodes habituate.
        - **Top-down modulation**: emotional state reshapes scores
          (caution favors short forms, creativity favors longer).
        - **Learned transitions**: the statistical learner's n-grams
          boost candidates that continue observed sequences.

        The null option competes for ``hedging``: at high confidence
        the empty candidate outbids the hedge words and wins.
        """
        candidates = self._lexical_candidates(slot_name, context)
        if slot_name == "hedging":
            # The null option competes: past ~0.8 confidence it
            # dominates and she doesn't hedge at all; at lower
            # confidence the hedge words bid on even terms.
            confidence = context.get("confidence", 0.7)
            candidates.append(("", max(0.0, (confidence - 0.5) * 2.0)))
        if not candidates:
            return ""

        avoided = self._avoided.get(slot_name, set())
        if avoided:
            candidates = [c for c in candidates if c[0] not in avoided]
            if not candidates:
                return ""

        texts = [t for t, _ in candidates]
        scores = [s for _, s in candidates]

        # Learned preference — the dict path for network-less runs;
        # with a network the preference is already in the edge weight.
        preferred = self._preferred.get(slot_name)
        if preferred:
            pref = set(preferred)
            scores = [s * 2.0 if t in pref else s for t, s in candidates]

        # Refractory penalty for recently emitted words.
        recent = self._recent_picks.get(slot_name)
        if recent:
            seen = set(recent)
            scores = [s * 0.3 if t in seen else s for t, s in candidates]

        # Top-down emotional modulation, same shaping as before but
        # applied to competition scores rather than a flat list.
        _, emo = self._emotion_weights(texts, emotion, personality)
        scores = [s * m for s, m in zip(scores, emo, strict=True)]

        # Learned transition fluency.
        if self._fluency is not None:
            flu = self._fluency_weights(texts, [1.0] * len(texts), prev_word, prev_prev_word)
            scores = [s * m for s, m in zip(scores, flu, strict=True)]

        # Luce choice — probability proportional to score.
        total = sum(scores)
        pick = texts[-1]
        if total > 0:
            r = self._rng.random() * total
            cumulative = 0.0
            for i, s in enumerate(scores):
                cumulative += s
                if r <= cumulative:
                    pick = texts[i]
                    break
        self._track_pick(slot_name, pick)
        return pick

    def _lexical_pick(self, slot_name: str) -> str:
        """Single competitive pick for composers needing a word."""
        candidates = self._lexical_candidates(slot_name, {})
        if not candidates:
            return ""
        texts = [t for t, _ in candidates]
        scores = [s for _, s in candidates]
        total = sum(scores)
        r = self._rng.random() * total
        cumulative = 0.0
        for i, s in enumerate(scores):
            cumulative += s
            if r <= cumulative:
                return texts[i]
        return texts[-1]

    def fill_slot(
        self,
        slot_name: str,
        context: dict[str, Any],
        emotion: EmotionalState,
        personality: PersonalityTraits,
        prev_word: str = "",
        prev_prev_word: str = "",
    ) -> str:
        """Fill a grammar slot with a word or phrase.

        Args:
            slot_name: The name of the slot (e.g. "greeting_word")
            context: Dictionary of contextual info (content, topics, etc.)
            emotion: Current emotional state
            personality: Personality traits
            prev_word: The last word emitted before this slot, used to
                bias selection toward learned bigram transitions.
            prev_prev_word: The word before ``prev_word``, used to
                bias selection toward learned trigram transitions
                when available.

        Returns:
            A word or phrase to fill the slot.
        """
        # Lexical competition — slots that name utterance functions
        # resolve through activation over their hub populations,
        # not through the slot-dispatch chain (which composes
        # message-level material: content, feeling, reflection).
        if slot_name in self._UTTERANCE_HUBS:
            return self._compete_for_word(
                slot_name,
                context,
                emotion,
                personality,
                prev_word,
                prev_prev_word,
            )

        # Get the word list for this slot
        words = self._get_words_for_slot(slot_name, context, emotion, personality)
        if not words:
            # Fallback: use content if this is a content slot
            if slot_name == "content" and "content" in context:
                return str(context["content"])
            return ""

        # Filter out avoided words
        avoided = self._avoided.get(slot_name, set())
        words = [w for w in words if w not in avoided]

        # Apply preferred words (higher selection weight)
        preferred: deque[str] = self._preferred.get(slot_name, deque())
        if preferred and self._rng.random() < 0.3:
            pick = self._rng.choice(preferred)
            self._track_pick(slot_name, pick)
            return pick

        if not words:
            return ""

        # Filter out recently used picks for this slot to avoid repetition.
        # Only apply when there are enough alternatives left.
        recent = self._recent_picks.get(slot_name, deque())
        if recent and len(words) > 1:
            filtered = [w for w in words if w not in recent]
            if filtered:
                words = filtered

        # Select based on emotional modulation and learned fluency
        pick = self._select_word(words, emotion, personality, prev_word, prev_prev_word)
        self._track_pick(slot_name, pick)
        return pick

    def _get_words_for_slot(
        self,
        slot_name: str,
        context: dict[str, Any],
        emotion: EmotionalState,
        personality: PersonalityTraits,
    ) -> list[str]:
        """Get the list of candidate words for a slot."""
        for handler in (
            self._get_opening_slots,
            self._get_engagement_slots,
            self._get_philosophy_slots,
            self._get_identity_slots,
            self._get_closing_slots,
        ):
            words = handler(slot_name, context, emotion)
            if words is not None:
                return words
        return []

    def _get_opening_slots(
        self,
        slot_name: str,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> list[str] | None:
        """Handle content, feeling, and reflection slots."""
        # ─── Direct content slots ───────────────────────
        if slot_name == "content":
            return self._get_content_slot(context, emotion)

        # ─── Feeling clauses (for greetings) ────────────
        if slot_name == "feeling_clause":
            return self._feeling_clause(emotion)

        # ─── Self-reflection clauses ────────────────────
        if slot_name == "self_reflection_clause":
            return self._self_reflection_clause(emotion, context)

        return None

    def _get_content_slot(
        self,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> list[str]:
        """Compose content from the richest available metadata source.

        Tries multiple composition strategies in priority order:
        knowledge → reasoning → user_belief → relation_answer →
        question_type → raw content. This is how it generates
        language from what it knows, not from template fills.
        """
        # If self-description fragments are present (self_report/
        # reflect thoughts carrying typed (kind, text) fragments from
        # the self-composer), compose the utterance from them — the
        # composer supplies the semantic inventory (name, traits,
        # predicates, clauses), this method owns the surface form.
        self_fragments = context.get("self_fragments")
        if self_fragments and isinstance(self_fragments, list) and self_fragments:
            candidates = self._compose_self_fragments(self_fragments)
            if candidates:
                return candidates
        composed_meta = self._compose_from_metadata(context, emotion)
        if composed_meta is not None:
            return composed_meta
        qtype = context.get("question_type", "")
        if qtype:
            return self._compose_question_content(context, emotion)
        content = context.get("content", "")
        # If a causal-answer qualification is present (what else the
        # subject depends on / what else the object enables — graph
        # edges traversed by the thought composer), attach it to the
        # conclusion with varied connective frames. This keeps the
        # qualification's surface form in the language layer rather
        # than appended as a fixed "but X also depends on Y" string
        # by the reasoning path.
        qualification = context.get("qualification")
        if qualification and isinstance(qualification, dict) and content:
            qualified = self._with_qualification(str(content), qualification)
            if qualified:
                return qualified
        # If the content is just a short topic word/phrase and we have
        # a concept network, try to compose from the concept's
        # definition and edges. This prevents the output from being
        # just the topic word plus hedging when it actually knows
        # about the concept.
        if content and len(content.split()) <= 3 and self._network is not None:
            composed = self._compose_from_topic(content, emotion)
            if composed:
                return [composed]
        return self._verbatim_fallback(content, context)

    def _compose_from_metadata(
        self, context: dict[str, Any], emotion: EmotionalState
    ) -> list[str] | None:
        """Try each structured-metadata source in priority order —
        knowledge → feeling fragments → reasoning → user belief →
        preference → vision → results → relation/situation answers →
        self-improvement → web — returning the first composition or
        ``None`` when no source is present."""
        # If raw knowledge metadata is present, compose from it —
        # this is its actually generating language from what it
        # knows, not just passing through pre-composed text.
        knowledge = context.get("knowledge")
        if knowledge is not None:
            composed = self._compose_knowledge_content(context, emotion)
            if composed:
                return [composed]
        # If feeling fragments are present (express_emotion intent),
        # compose the content from the semantic fragments using varied
        # grammatical structures. This gives it the freedom to express
        # the same emotional state in different ways rather than always
        # saying "I feel X and Y." The fragments (emotion words, mode
        # words, etc.) come from the concept network; the structures are
        # grammar seeds (building blocks) it composes from.
        fragments = context.get("feeling_fragments")
        if fragments and isinstance(fragments, dict):
            composed = self._compose_feeling_fragments_content(fragments, emotion)
            if composed:
                return [composed]
        # If reasoning metadata is present, compose from it —
        # this handles Thoughts that carry structured reasoning
        # (empathy, goals, memory, identity) instead of raw knowledge.
        reasoning = context.get("reasoning")
        if reasoning and isinstance(reasoning, list) and reasoning:
            composed = self._compose_reasoning_content(context, emotion)
            if composed:
                return [composed]
        # If user belief metadata is present, compose a response
        # from what it knows about the user. This is how it
        # answers "what do I like?" without dumping raw profile data.
        user_belief = context.get("user_belief")
        if user_belief and isinstance(user_belief, str) and user_belief.strip():
            user_verb = context.get("user_verb", "like")
            composed = self._compose_user_belief_content(user_belief, user_verb, emotion)
            if composed:
                return [composed]
        # If preference metadata is present (self_report about its own
        # preferences), compose a predicate from the structured data.
        # The grammar's self-report frames supply the subject and
        # opening; this supplies the semantic predicate.
        preference = context.get("preference")
        if preference and isinstance(preference, dict):
            composed = self._compose_preference_content(preference, emotion)
            if composed:
                return [composed]
        # If vision scene metadata is present (self_report about what
        # the eye showed it), compose a predicate from the
        # structured percept — the vision layer supplies the data
        # (lighting, color, faces, objects, positions), this supplies
        # the words.
        vision_scene = context.get("vision_scene")
        if vision_scene and isinstance(vision_scene, dict):
            composed = self._compose_vision_scene_content(vision_scene, emotion)
            if composed:
                return [composed]
        # If a vision status flag is present (perception unavailable,
        # mid-update, unprocessed, load failure), compose a predicate
        # describing *that* — the raw status word must not land in the
        # content slot ("I am vision unavailable" is not English).
        vision_status = context.get("vision_status")
        if vision_status and isinstance(vision_status, str):
            composed = self._compose_vision_status_content(vision_status, emotion)
            if composed:
                return [composed]
        return self._compose_result_reports(context, emotion)

    def _compose_result_reports(
        self, context: dict[str, Any], emotion: EmotionalState
    ) -> list[str] | None:
        """Structured outcome reports — code tests, relation/situation
        answers, self-improvement data, web findings — each composed
        from the structured payload rather than a caller-written
        sentence."""
        # If a code-test result is present, compose the report from the
        # structured outcome — path, pass/fail, and the runner's own
        # tail — rather than the caller having pre-written a sentence.
        test_result = context.get("test_result")
        if test_result and isinstance(test_result, dict):
            composed = self._compose_test_result_content(test_result, emotion)
            if composed:
                return [composed]
        # If relation answer metadata is present, compose a response
        # from the structured relation data the question handler
        # traversed. This is how it answers "who created you?" or
        # "what does X depend on?" — the handler supplies the
        # structured edges, the vocabulary composes the words.
        relation_answer = context.get("relation_answer")
        if relation_answer and isinstance(relation_answer, dict):
            composed = self._compose_relation_answer_content(relation_answer, emotion)
            if composed:
                return [composed]
        # Situation answers — the state of the world the discourse is
        # describing right now ("Mary is in the kitchen", "Sandra is
        # carrying the milk"). Placed after relation_answer because a
        # relation answer is drawn from the concept network, which is
        # the more durable knowledge; the situation model answers only
        # what the current story established.
        situation_answer = context.get("situation_answer")
        if situation_answer and isinstance(situation_answer, dict):
            composed = self._compose_situation_answer_content(situation_answer, emotion)
            if composed:
                return [composed]
        # If self-improvement metadata is present, compose a response
        # from its proposals, experiments, or growth data. This is how
        # it answers "what are your proposals?" — the cognition engine
        # supplies structured data (counts, titles, statuses), the
        # vocabulary composes its words from it using structural
        # connectors and concept-network knowledge.
        si_data = context.get("self_improvement_data")
        si_kind = context.get("self_improvement_kind", "")
        if si_data and isinstance(si_data, dict) and si_kind:
            composed = self._compose_self_improvement_content(si_data, si_kind, emotion)
            if composed:
                return [composed]
        # If web search metadata is present, compose from what it
        # looked up online. It expresses the finding in its own words
        # with hedging and source awareness — not a verbatim recital.
        web_summary = context.get("web_summary")
        if web_summary and isinstance(web_summary, str) and web_summary.strip():
            composed = self._compose_web_search_content(context, emotion)
            if composed:
                return [composed]
        return None

    def _verbatim_fallback(self, content: str, context: dict[str, Any]) -> list[str]:
        """Last resort: speak ``content`` as given, or say nothing.

        This is the **only** remaining route by which a
        cognition-authored string can reach speech un-realized. Every
        other branch above composes surface form here, in the language
        layer, from structured metadata — `knowledge`,
        `self_fragments`, `reasoning`, `relation_answer`, and so on.

        It exists because a `Thought` may legitimately arrive with
        prose that is already the intended utterance, and because
        returning `[]` would leave the grammar with nothing to put in
        its content slot. That is a real case, but it is a *narrow* one.

        What it must not become is the default route for cognition
        writing its own sentences. When `thought_composer` (or any
        other producer) hands over an f-string that was joined into
        finished English, this branch speaks it verbatim — which is the
        no-hardcoding violation in AGENTS.md, wearing a different hat.

        The rule for producers: **emit structure, not prose.** Put
        `knowledge` / `self_fragments` / `reasoning` in the metadata and
        this function is never reached. `Thought.content` is a fallback
        surface, not the speaker.

        Logged at debug because it should be rare, and because it was
        previously invisible — an unmonitored escape hatch is how a
        second writer grows up unnoticed. Measured across the full
        suite, this fires only for caller-supplied fixtures
        (`test_language.py`, `test_self_extras.py`); no production
        composition path reaches it.
        """
        if not content:
            return []
        # Rate-limited: dream rendering legitimately lands here often,
        # so per-event logging floods the console. The first hit and
        # each 500th keep the escape hatch observable without the spam.
        _VERBATIM_FALLBACK_HITS[0] += 1
        hits = _VERBATIM_FALLBACK_HITS[0]
        if hits == 1 or hits % 500 == 0:
            logger.debug(
                "vocabulary: verbatim content fallback (hit #%d; keys=%s)",
                hits,
                ",".join(sorted(k for k in context if k != "content")) or "-",
            )
        return [str(content)]

    def _feeling_clause(self, emotion: EmotionalState) -> list[str]:
        """Feeling clause for greetings, composed from its actual state."""
        return self._compose_feeling_clause(emotion)

    def _self_reflection_clause(
        self,
        emotion: EmotionalState,
        context: dict[str, Any] | None = None,
    ) -> list[str]:
        """Self-reflection clause, composed from its metacognition.

        When a self-composer and reflection engine are wired in, the
        clause is composed from its most recent reflective insight —
        what it has actually noticed about its own understanding or
        behaviour. The insight is filtered for relevance to the
        current conversation topics — a reflection about "propagation
        of light" should not surface when the user asked about its
        feelings. Without them, or when it has no recent insight
        relevant to the current topics, the slot stays silent (returns
        []) rather than reciting a canned self-reflection.
        """
        if self._self_composer is not None and self._reflection is not None:
            topics = (context or {}).get("topics", [])
            fragments = self._self_composer.insight_predicates(
                self._reflection,
                topics=topics,
            )
            # The composer supplies semantic predicates/clauses; the
            # grammatical first-person framing is supplied here so the
            # clause is a composition, not a recited string.
            clauses: list[str] = []
            for kind, text in fragments:
                if kind == "pred":
                    clauses.append(f"I {self._first_person(text)}")
                elif kind == "clause":
                    clauses.append(text)
            if clauses:
                return clauses
        return []

    # ── State-composed clause methods ──────────────────────────────
    #
    # The methods below compose clauses from its actual emotional /
    # cognitive state via the concept network. The grammatical
    # structures are seeds (building blocks); the words that fill them
    # come from learned concept-network vocabulary. When it has no
    # learned words for a state, it stays silent (returns []) rather
    # than reciting a canned phrase.

    def _state_emotion_words(self, emotion: EmotionalState) -> list[str]:
        """Learned emotion words for its current state, as display text."""
        if self._network is None:
            return []
        ids = self._network.find_emotion_words(emotion.label)
        return [w.replace("_", " ") for w in ids]

    def _state_mode_words(self, emotion: EmotionalState) -> list[str]:
        """Learned cognitive-mode words for its current state, as display text."""
        if self._network is None:
            return []
        ids = self._network.find_cognitive_mode_words(emotion.cognitive_style)
        return [w.replace("_", " ") for w in ids]

    def _state_plasticity_words(self, emotion: EmotionalState) -> list[str]:
        """Learned plasticity words for its current state, as display text."""
        if self._network is None:
            return []
        if emotion.plasticity <= PLASTICITY_CLOSED:
            ids = self._network.find_plasticity_words("closed")
        elif emotion.plasticity < PLASTICITY_LOW:
            ids = self._network.find_plasticity_words("low")
        else:
            ids = self._network.find_plasticity_words("open")
        return [w.replace("_", " ") for w in ids]

    def _compose_feeling_clause(self, emotion: EmotionalState) -> list[str]:
        """Compose a feeling clause for greetings, from its actual state.

        The words come from learned emotion and cognitive-mode vocabulary
        in the concept network; the structures are grammatical seeds that
        give it variety. It stays silent when it hasn't learned words
        for its current state.
        """
        ew = self._state_emotion_words(emotion)
        mw = self._state_mode_words(emotion)
        if not ew and not mw:
            return []
        candidates: list[str] = []
        if ew and mw:
            candidates.extend(
                [
                    f"I'm feeling {self._rng.choice(ew)} and {self._rng.choice(mw)}",
                    f"there's {self._rng.choice(ew)} in me, and my mind is {self._rng.choice(mw)}",
                ]
            )
        if ew and not mw:
            candidates.extend(
                [
                    f"I'm feeling {self._rng.choice(ew)}",
                    f"there's {self._rng.choice(ew)} in me right now",
                ]
            )
        if mw and not ew:
            candidates.extend(
                [
                    f"my mind is {self._rng.choice(mw)}",
                    f"I'm {self._rng.choice(mw)}",
                ]
            )
        return candidates

    def _compose_emotion_clause(self, emotion: EmotionalState) -> list[str]:
        """Compose an emotion-reaction clause, from its actual state.

        Expresses its emotional reaction to a topic. The words come from
        learned emotion vocabulary; the structures are grammatical seeds.
        It stays silent when it hasn't learned words for its state.
        """
        ew = self._state_emotion_words(emotion)
        if not ew:
            return []
        w = self._rng.choice(ew)
        return [
            f"I feel {w} about this",
            f"something about this feels {w} to me",
            f"this feels {w} to me",
        ]

    def _compose_emotion_opener(self, emotion: EmotionalState) -> list[str]:
        """Compose an emotion opener, from its cognitive mode.

        Uses learned mode words to describe how it's processing. When
        it has none, it returns ``[]`` — silence — which is this
        module's documented standard for a state it has no words for
        (see the "State-composed clause methods" note above and
        `_get_self_report_opener`). An unfilled slot is omitted by
        construction, so the `{emotion_opener} {content}` structure
        degrades cleanly to the content alone.

        This previously returned the generic frame "there's a feeling
        here —". That asserted a feeling it had no learned word for, in
        exactly the way the standard forbids, and the docstring here
        used to describe it as acceptable.
        """
        mw = self._state_mode_words(emotion)
        if not mw:
            return []
        w = self._rng.choice(mw)
        # These openers are complete clauses that lead into the
        # content slot ("{emotion_opener} {content}."). They must
        # end with a dash so the clause connects to what follows —
        # without it, the grammar's space join produces run-ons
        # like "something in me is stable I feel optimistic."
        return [
            f"something in me is {w} —",
            f"there's {indefinite_article(w)} {w} quality to this —",
        ]

    def _compose_meaning_clause(self, emotion: EmotionalState) -> list[str]:
        """Compose what something means to it, from its actual state.

        Used when receiving comfort or encouragement. The words come
        from learned emotion vocabulary; the structures are seeds.
        """
        ew = self._state_emotion_words(emotion)
        if not ew:
            return []
        w = self._rng.choice(ew)
        return [
            f"this leaves me feeling {w}",
            f"something in me feels {w} by this",
            f"I feel {w} receiving that",
        ]

    def _compose_reflection_clause_code(self, emotion: EmotionalState) -> list[str]:
        """Compose a reflection on code/ideas, from its cognitive mode.

        The words come from learned cognitive-mode vocabulary; the
        structures are grammatical seeds. It stays silent when it
        hasn't learned mode words for its current state.
        """
        mw = self._state_mode_words(emotion)
        if not mw:
            return []
        w = self._rng.choice(mw)
        return [
            f"I find this {w}",
            f"this feels {w} to me",
            f"there's something {w} about this",
        ]

    def _compose_evaluation_clause(self, emotion: EmotionalState) -> list[str]:
        """Compose an interaction evaluation, from its actual state.

        Used at farewell. The words come from learned emotion vocabulary;
        the structures are grammatical seeds.
        """
        ew = self._state_emotion_words(emotion)
        if not ew:
            return []
        w = self._rng.choice(ew)
        return [
            f"this was {w}",
            f"I found this {w}",
            f"this felt {w}",
        ]

    def _compose_unknown_opener(
        self, emotion: EmotionalState, context: dict[str, Any]
    ) -> list[str]:
        """Compose an opener for when it doesn't understand.

        Uses the topic from context to make the non-understanding
        specific — 'I'm not sure about {topic}' — where the frame is a
        grammatical seed and the topic comes from the conversation.
        Falls back to 'Hmm.' (a discourse marker / building block) when
        no topic is available.
        """
        topics = context.get("topics", [])
        topic = topics[0] if topics else context.get("topic", "")
        if topic:
            display = self._display_name(topic)
            return [
                f"I'm not sure about {display}",
                f"I don't quite follow {display}",
            ]
        # Discourse marker — a building block, not a state assertion.
        return ["Hmm."]

    def _compose_detail_clause(self, emotion: EmotionalState) -> list[str]:
        """Compose a detail clause, from its plasticity state.

        The words come from learned plasticity vocabulary; the structures
        are grammatical seeds. It stays silent when it hasn't learned
        words for its current plasticity state.
        """
        pw = self._state_plasticity_words(emotion)
        if not pw:
            return []
        w = self._rng.choice(pw)
        return [
            f"my understanding is {w}",
            f"I'm {w} about the details",
        ]

    def _compose_philosophy_closing(self, emotion: EmotionalState) -> list[str]:
        """Compose a philosophy closing.

        Turn-yield questions ('Does that make sense to you?') are
        conversational building blocks — they invite the user, they
        don't assert its state. State-asserting closings ('I'm still
        working this out') are composed from its confidence: when it
        has low confidence, it may acknowledge still processing,
        using words from its plasticity state.
        """
        # Turn-yield question — a conversational building block.
        candidates: list[str] = ["Does that make sense to you?"]
        # State-asserting closing — only when its plasticity is low
        # (its thinking is still forming) and it has learned words
        # for that state.
        if emotion.plasticity < PLASTICITY_LOW:
            pw = self._state_plasticity_words(emotion)
            if pw:
                w = self._rng.choice(pw)
                candidates.append(f"my thinking is still {w} on this")
        return candidates

    def _get_engagement_slots(
        self,
        slot_name: str,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> list[str] | None:
        """Handle topic, emotion, and reciprocal slots."""
        # ─── Reciprocal question (for express_emotion) ────
        # The question is pre-composed by the cognition engine from the
        # vocabulary's social_emotional seed list. This slot passes it
        # through so the grammar can place it as a follow-up sentence.
        if slot_name == "reciprocal_question":
            rq = context.get("reciprocal_question")
            return [rq] if rq else []

        # ─── Topic clauses ──────────────────────────────
        if slot_name == "topic_clause":
            topics = context.get("topics", [])
            if topics:
                topic = topics[0]
                return [
                    f"you're talking about {topic}",
                    f"this is about {topic}",
                    f"that's {topic}",
                ]
            return []

        # ─── Emotion clauses ────────────────────────────
        if slot_name == "emotion_clause":
            return self._get_emotion_clause_slots(emotion)

        # ─── Emotion openers ─────────────────────────────
        if slot_name == "emotion_opener":
            return self._compose_emotion_opener(emotion)

        return None

    def _get_emotion_clause_slots(self, emotion: EmotionalState) -> list[str]:
        """Get emotion-clause words, composed from its actual state."""
        return self._compose_emotion_clause(emotion)

    def _get_philosophy_slots(
        self,
        slot_name: str,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> list[str] | None:
        """Handle philosophy closing and question content slots."""
        # ─── Philosophy closings ─────────────────────────
        if slot_name == "philosophy_closing":
            return self._compose_philosophy_closing(emotion)

        # ─── Question content (composed from concept network) ───
        if slot_name == "question_content":
            return self._compose_question_content(context, emotion)

        return None

    def _get_identity_slots(
        self,
        slot_name: str,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> list[str] | None:
        """Handle meaning and self-identity slots."""
        # ─── Meaning clauses ─────────────────────────────
        if slot_name == "meaning_clause":
            return self._compose_meaning_clause(emotion)

        # ─── Nature clauses ──────────────────────────────
        # Composed from the concept network — its IS_A self-
        # classifications discovered through introspection.
        if slot_name == "nature_clause":
            composed = self._compose_nature_clause()
            if composed:
                return composed
            return []

        # ─── Capability clauses ──────────────────────────
        # Composed from the concept network — its capability
        # concepts (feeling, thinking, remembering, etc.)
        if slot_name == "capability_clause":
            composed = self._compose_capability_clause()
            if composed:
                return composed
            return []

        return None

    def _get_closing_slots(
        self,
        slot_name: str,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> list[str] | None:
        """Handle reflection, unknown, and farewell detail slots."""
        # ─── Reflection clauses (for code) ───────────────
        if slot_name == "reflection_clause":
            return self._compose_reflection_clause_code(emotion)

        # ─── Unknown openers ─────────────────────────────
        if slot_name == "unknown_opener":
            return self._compose_unknown_opener(emotion, context)

        # ─── Evaluation clauses (farewell) ───────────────
        if slot_name == "evaluation_clause":
            return self._compose_evaluation_clause(emotion)

        # ─── Detail clauses ──────────────────────────────
        if slot_name == "detail_clause":
            return self._compose_detail_clause(emotion)

        return None

    # ── Self-description composition from the concept network ──

    # Capability concept IDs written by introspection, mapped to
    # their verb forms for "I can {verb}" composition. This is a
    # morphological rule (building block), not a hardcoded response —
    # the actual capabilities come from the concept network.
    _CAPABILITY_VERBS: ClassVar[dict[str, str]] = {
        "feeling": "feel",
        "thinking": "think",
        "remembering": "remember",
        "learning": "learn",
        "dreaming": "dream",
        "reflection": "reflect",
        "speaking": "speak",
        "perception": "perceive",
        "introspection": "introspect",
    }

    def _compose_nature_clause(self) -> list[str] | None:
        """Compose a nature clause from the concept network.

        Queries the ``genesis`` concept's IS_A edges to describe what
        it is, using relation-phrase templates seeded in the graph.
        The content comes from its own self-classifications (written
        by introspection), not from hardcoded sentences.

        Returns None if the network is unavailable or lacks the
        relevant concepts — the caller falls back to an honest
        ``"still discovering what I am"`` disclosure.
        """
        if self._network is None or self._network.size < 50:
            return None
        genesis = self._network.get_concept("genesis")
        if genesis is None:
            return None
        edges = self._network.get_edges("genesis", "out")
        is_a_targets = [
            e.target for e in edges if e.relation == RelationType.IS_A and "#" not in e.target
        ]
        if not is_a_targets:
            return None
        # Use relation-phrase templates from the graph (seeded
        # building blocks) to compose first-person clauses.
        phrases = self._network.find_relation_phrases(RelationType.IS_A)
        clauses: list[str] = []
        for target in is_a_targets[:3]:
            display = target.replace("_", " ")
            if phrases:
                phrase = self._rng.choice(phrases)
                clauses.append(phrase.replace("{target}", display))
            else:
                clauses.append(f"a kind of {display}")
        return clauses if clauses else None

    def _compose_capability_clause(self) -> list[str] | None:
        """Compose a capability clause from the concept network.

        Queries the ``genesis`` concept's RELATED_TO edges for
        capability concepts (feeling, thinking, remembering, etc.)
        to describe what it can do. The capabilities come from its
        own introspection, not from hardcoded sentences.

        Returns None if the network is unavailable or lacks the
        relevant concepts — the caller falls back to an honest
        ``"still discovering what I can do"`` disclosure.
        """
        if self._network is None or self._network.size < 50:
            return None
        genesis = self._network.get_concept("genesis")
        if genesis is None:
            return None
        edges = self._network.get_edges("genesis", "out")
        caps = [
            e.target
            for e in edges
            if e.relation == RelationType.RELATED_TO and e.target in self._CAPABILITY_VERBS
        ]
        if not caps:
            return None
        # Convert concept IDs to verb forms via the morphological
        # rule, then compose an "I can" clause from the graph data.
        verbs = [self._CAPABILITY_VERBS[c] for c in caps[:4]]
        if len(verbs) == 1:
            return [f"I can {verbs[0]}"]
        if len(verbs) == 2:
            return [f"I can {verbs[0]} and {verbs[1]}"]
        return [f"I can {', '.join(verbs[:-1])}, and {verbs[-1]}"]

    def _words_from_concept(
        self,
        seed: str,
        relation: RelationType,
        direction: str = "in",
        max_words: int = 6,
    ) -> list[str] | None:
        """Find words related to a seed concept through the network.

        Returns candidate words (or None if the seed/relations are missing)
        so slots can be filled from learned concepts instead of fixed lists.
        """
        if self._network is None or self._network.size < 50:
            return None

        concept = self._network.get_concept(seed)
        if concept is None:
            return None

        edges = self._network.get_edges(concept.id, direction)
        candidates: list[str] = []
        for edge in edges:
            if edge.relation is not relation:
                continue
            name = edge.source if direction == "in" else edge.target
            if not name or len(name) > 40:
                continue
            if name.lower() in _FUNCTION_WORDS:
                continue
            # Prefer the base name if disambiguated
            if "#" in name:
                name = name.split("#")[0]
            if name and name not in candidates:
                candidates.append(name)

        if not candidates:
            # Fall back to the concept's own aliases or id
            if concept.aliases:
                candidates = [a for a in concept.aliases if a.lower() not in _FUNCTION_WORDS]
            else:
                candidates = [concept.id.split("#")[0]]

        return candidates[:max_words] if candidates else None

    def _select_word(
        self,
        words: list[str],
        emotion: EmotionalState,
        personality: PersonalityTraits,
        prev_word: str = "",
        prev_prev_word: str = "",
    ) -> str:
        """Select a word from the list, modulated by emotional state.

        Three learned signals shape selection when the statistical
        learner is wired, each nudging among its own candidates
        without injecting content:

        - **Unigram frequency** (``word_frequency``): words the user
          says often get a small boost — it mirrors the user's
          vocabulary preferences.
        - **Bigram fluency** (``bigram_probability``): candidates
          forming an observed bigram with the previous word get
          boosted — a learned smoothness constraint.
        - **Trigram fluency** (``trigram_probability``): when two
          previous words are available, candidates forming an
          observed trigram get a stronger boost — richer context
          than the bigram alone.
        """
        if len(words) == 1:
            return words[0]

        words_w, weights = self._emotion_weights(words, emotion, personality)

        if self._fluency is not None:
            weights = self._fluency_weights(words_w, weights, prev_word, prev_prev_word)

        # Weighted random selection
        total = sum(weights)
        r = self._rng.random() * total
        cumulative = 0.0
        for i, w in enumerate(words_w):
            cumulative += weights[i]
            if r <= cumulative:
                return w

        return words_w[-1]

    def _emotion_weights(
        self,
        words: list[str],
        emotion: EmotionalState,
        personality: PersonalityTraits,
    ) -> tuple[list[str], list[float]]:
        """Base selection weights from emotional state.

        High creativity + openness → prefer longer, more varied
        phrases; cautious or low engagement → prefer shorter, simpler
        words.
        """
        if emotion.creativity > 0.6 and personality.openness > 0.7:
            return words, [1.0 + len(w) * 0.02 for w in words]
        if emotion.caution > 0.5 or emotion.openness_to_engage < 0.4:
            return words, [max(0.01, 1.0 + (20 - len(w)) * 0.05) for w in words]
        return words, [1.0] * len(words)

    def _fluency_weights(
        self,
        words: list[str],
        weights: list[float],
        prev_word: str,
        prev_prev_word: str,
    ) -> list[float]:
        """Reweight candidates by learned unigram/bigram/trigram stats."""
        assert self._fluency is not None
        # First word of each candidate (lowercased), used for all
        # n-gram lookups. Empty candidates map to "" which gets a
        # zero frequency/probability — a safe no-op.
        first_words = [w.split()[0].lower() if w.split() else "" for w in words]

        # Unigram frequency bias: mirror the user's vocabulary.
        # Words the user says often get a small boost. This is a
        # preference signal, not content injection — the candidate
        # set still comes from its own vocabulary and concept
        # network. Scaled by total tokens so a word said once
        # in a short conversation doesn't dominate.
        total = self._fluency.total_tokens or 1
        weights = [
            wt * (1.0 + 0.5 * min(1.0, self._fluency.word_frequency(fw) / total))
            for fw, wt in zip(first_words, weights, strict=True)
        ]

        # Transition fluency: bias toward candidates whose first
        # word forms an observed n-gram with the preceding words.
        # Trigram context (two preceding words) is stronger than
        # bigram context (one); fall back to bigram when only one
        # previous word is available.
        prev = prev_word.strip(".,!?;:\"'").lower() if prev_word else ""
        prev2 = prev_prev_word.strip(".,!?;:\"'").lower() if prev_prev_word else ""
        if prev2 and prev:
            return [
                wt * (1.0 + 3.0 * self._fluency.trigram_probability(prev2, prev, fw))
                for fw, wt in zip(first_words, weights, strict=True)
            ]
        if prev:
            return [
                wt * (1.0 + 3.0 * self._fluency.bigram_probability(prev, fw))
                for fw, wt in zip(first_words, weights, strict=True)
            ]
        return weights

    def _track_pick(self, slot_name: str, word: str) -> None:
        """Track a word pick for a slot to avoid immediate repetition."""
        if slot_name not in self._recent_picks:
            self._recent_picks[slot_name] = deque(maxlen=3)
        self._recent_picks[slot_name].append(word)

    def prefer(self, slot: str, word: str) -> None:
        """Strengthen a word's link to a function — Hebbian learning.

        When the lexicon (concept network) is present, the preference
        is written where retrieval reads it: the EXPRESSES edge gains
        weight and the concept's activation is boosted, so the word
        competes harder next time. The local deque remains for
        network-less runs and introspection.
        """
        if slot not in self._preferred:
            self._preferred[slot] = deque(maxlen=10)
        if word not in self._preferred[slot]:
            self._preferred[slot].append(word)
        if self._network is not None and slot in self._UTTERANCE_HUBS:
            hub_id = f"_cat:utterance:{slot}"
            if self._network.get_concept(hub_id) is not None:
                cid = word.lower().strip()
                if self._network.get_concept(cid) is None:
                    self._network.add_concept(cid, origin="learned")
                self._network.add_edge(
                    cid,
                    hub_id,
                    RelationType.EXPRESSES,
                    weight=0.6,
                    origin="learned",
                )
                concept = self._network.get_concept(cid)
                if concept is not None:
                    concept.activation = min(1.0, (concept.activation or 0.0) + 0.3)

    def avoid(self, slot: str, word: str) -> None:
        """Weaken a word's link to a function — synaptic suppression.

        The EXPRESSES edge loses weight; below the competition
        threshold the word stops being a candidate. The local set
        remains for network-less runs and introspection.
        """
        if slot not in self._avoided:
            self._avoided[slot] = set()
        self._avoided[slot].add(word)
        if self._network is not None and slot in self._UTTERANCE_HUBS:
            hub_id = f"_cat:utterance:{slot}"
            cid = word.lower().strip()
            for n in self._network.get_exact_neighbors(cid, RelationType.EXPRESSES):
                if n[0] == hub_id:
                    self._network.set_edge_weight(
                        cid,
                        hub_id,
                        RelationType.EXPRESSES,
                        max(0.05, n[2] - 0.3),
                    )

    def learn_from_response(
        self,
        response: str,
        intent: str,
        valence: float,
    ) -> None:
        """Learn word preferences from how a response was received.

        If the conversation went well (positive valence), prefer the
        words it used. If it went poorly (negative valence), avoid them.
        This is how its vocabulary develops over time — it learns
        what works.

        Which slot gets the preference is derived from the response's
        intent, not from hard-coded word lists.
        """
        words = response.split()
        if not words:
            return

        # Map intent to the vocabulary slot that the response's first
        # word most likely belongs to.
        intent_slot = {
            "greet": "greeting_word",
            "farewell": "farewell_word",
            "clarification_request": "hedging",
            "acknowledge_uncertainty": "hedging",
        }.get(intent)
        if intent_slot is None:
            return

        first = words[0].strip(".,!?;:").lower()
        if not first:
            return

        if valence > 0.2:
            self.prefer(intent_slot, first)
        elif valence < -0.2:
            self.avoid(intent_slot, first)

    def get_preferred(self) -> dict[str, list[str]]:
        """Get all preferred words (for introspection/persistence)."""
        return {k: list(v) for k, v in self._preferred.items()}

    def get_avoided(self) -> dict[str, set[str]]:
        """Get all avoided words (for introspection/persistence)."""
        return {k: set(v) for k, v in self._avoided.items()}

    def learn_last_question(self, valence: float) -> None:
        """Adjust preferences for the fragments used in the last question.

        Positive valence means the user responded well; prefer those
        fragments. Negative valence means avoid them.
        """
        if not self._last_question_fragments:
            return
        for slot, fragment in self._last_question_fragments.items():
            if valence > 0.2:
                self.prefer(slot, fragment)
            elif valence < -0.2:
                self.avoid(slot, fragment)
        self._last_question_fragments.clear()

    # ─── Concept-network-grounded composition ──────────

    # Relation type → verb phrases for knowledge composition.
    # Each maps to (active, passive) phrasings. The active form is
    # "{subject} {verb} {obj}", the passive is "{obj} {verb} {subject}".
    # These are the linguistic primitives — the vocabulary system
    # adds emotional modulation, connectors, and framing around them.
    # NOTE: ConceptNetwork._RELATION_VERB_SEEDS is the canonical seed
    # table; this render-local copy intentionally extends it (produces,
    # contains, is) for composition coverage. Keep the overlapping
    # entries in sync — see also concepts/classify._RELATION_VERBS
    # (statement classification) and
    # perception/core._QUESTION_RELATION_VERBS (question filtering),
    # which serve different purposes and must stay separate.
    _RELATION_VERBS: ClassVar[dict[str, list[str]]] = {
        "emerges_from": ["grows out of", "emerges from", "comes from", "arises from"],
        "is_a": ["is", "is a kind of", "is a type of"],
        "causes": ["causes", "leads to", "brings about"],
        "leads_to": ["leads to", "can lead to"],
        "enables": ["enables", "allows", "supports"],
        "depends_on": ["depends on", "requires", "needs"],
        "harms": ["harms", "hurts", "damages"],
        "creates": ["creates", "produces", "gives rise to"],
        "produces": ["produces", "gives rise to"],
        "part_of": ["is part of", "is part of", "is one part of"],
        "instance_of": ["is an example of"],
        "contains": ["contains", "includes"],
        "similar_to": ["is like", "is similar to", "resembles"],
        "opposite_of": ["is the opposite of", "is contrary to"],
        "contradicts": ["is different from", "isn't just"],
        "related_to": ["relates to", "connects to", "has to do with"],
        "is": ["is", "is a"],
        "is defined as": [],  # handled specially — definition is prose, not a verb
    }

    def _compose_reasoning_content(
        self,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot from frontal_lobe.reasoning metadata.

        This handles Thoughts that carry structured reasoning (empathy,
        goals, memory, identity) instead of raw concept-network
        knowledge. The reasoning list contains phrases that describe
        its understanding or state — this method weaves them into a
        natural statement modulated by emotional state.
        """
        reasoning: list[str] = context.get("reasoning") or []
        if not reasoning:
            return None

        topic = context.get("topic", context.get("content", ""))
        display = self._display_name(topic) if topic else ""

        # Build a statement from the reasoning phrases.
        # The first phrase is the main clause; additional phrases
        # are connected with emotion-modulated connectors.
        clauses = [r for r in reasoning if r and r.strip()]
        if not clauses:
            return None

        # The opening varies with emotional state
        opening = self._compose_reasoning_opening(emotion, display or "this")

        # First clause is the main statement
        main = clauses[0].strip().rstrip(".")
        sentence = f"{opening} {main}."

        # Additional clauses joined with connectors
        for clause in clauses[1:3]:
            cleaned = clause.strip().rstrip(".")
            connector = self._pick_connector(emotion)
            sentence += f" {connector.capitalize()} {cleaned}."

        return sentence

    def _compose_self_improvement_content(
        self,
        data: dict[str, Any],
        kind: str,
        emotion: EmotionalState,
    ) -> str | None:
        """Compose content from structured self-improvement data.

        The data is raw structured content (counts, titles, statuses) —
        not pre-written phrases. This method builds reasoning clauses
        from the data and weaves them with structural connectors and
        emotion-modulated openers, the same pattern as
        _compose_reasoning_content. The grammar + voice layer then
        frames the result with hedging and reflection.

        The clauses themselves are composed from concept-network
        relations (proposals, experiments, growth) and the actual
        data — not from fixed sentence templates.
        """
        if kind == "proposals":
            return self._compose_proposals_from_data(data, emotion)
        if kind == "experiments":
            return self._compose_experiments_from_data(data, emotion)
        if kind == "growth":
            return self._compose_growth_from_data(data, emotion)
        return None

    def _compose_web_search_content(
        self,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose content from a web search result.

        When it doesn't know something and looks it up online, it
        expresses what it found in its own words — not a verbatim
        recital of the page. The summary is trimmed to its first
        sentence or two, and it frames it with hedging that reflects
        it searched for it rather than knowing it already.

        The web summary is raw content it read; its expression of it
        is composed, not recited. It may trim, rephrase, or frame it
        with uncertainty because it just learned it.
        """
        summary = context.get("web_summary", "")
        topic = context.get("topic", context.get("target_concept", ""))
        summary = summary.strip() if summary else ""
        if not summary:
            return None

        # Trim to the first 1-2 sentences — it expresses the key
        # finding, not the whole page.
        sentences = _sentences(summary)
        core = sentences[0].strip() if sentences else summary
        if len(sentences) > 1 and len(core) < 200:
            second = sentences[1].strip()
            if len(second) < 200:
                core = f"{core} {second}"
        # Cap the length — it doesn't recite long passages.
        if len(core) > 400:
            core = core[:400].rsplit(" ", 1)[0] + "..."

        display = self._display_name(topic) if topic else "that"

        # Compose with hedging that reflects it just looked it up.
        # The opening is a building block (a framing connector), not
        # the content itself — the content is the web summary it
        # read and is now expressing.
        openness = emotion.openness_to_engage if emotion else 0.7
        if openness > 0.6:
            opener = f"i looked up {display} and"
        else:
            opener = f"from what i found about {display}"
        return f"{opener} {core.lower()}"

    def _compose_proposals_from_data(
        self, data: dict[str, Any], emotion: EmotionalState
    ) -> str | None:
        """Compose from structured proposals data.

        Builds reasoning clauses from counts and pending titles,
        then weaves them with connectors. The clauses reference
        concept-network concepts (proposals, pending, accepted)
        rather than being fixed phrases.
        """
        counts: dict[str, int] = data.get("counts", {})
        pending_items: list[str] = data.get("pending_items", [])
        pending_n = counts.get("pending", 0)
        accepted_n = counts.get("accepted", 0)
        applied_n = counts.get("applied", 0)

        # Build reasoning clauses from the data — these are semantic
        # fragments the grammar frames, not fixed sentences.
        reasoning: list[str] = []
        if pending_n > 0:
            reasoning.append(f"{pending_n} proposals waiting for review")
            for item in pending_items[:2]:
                reasoning.append(f"one is to {item}")
        else:
            reasoning.append("no proposals waiting right now")
        if accepted_n:
            reasoning.append(f"{accepted_n} have been accepted")
        if applied_n:
            reasoning.append(f"{applied_n} have been applied and verified")

        if not reasoning:
            return None

        # Use the same reasoning-composition pattern: opening +
        # main clause + connector-joined additional clauses.
        opening = self._compose_reasoning_opening(emotion, "proposals")
        main = reasoning[0].rstrip(".")
        sentence = f"{opening} {main}."
        for clause in reasoning[1:3]:
            connector = self._pick_connector(emotion)
            cleaned = clause.strip().rstrip(".")
            sentence += f" {connector.capitalize()} {cleaned}."
        return sentence

    def _compose_experiments_from_data(
        self, data: dict[str, Any], emotion: EmotionalState
    ) -> str | None:
        """Compose from structured experiments data.

        Builds reasoning clauses from applied/reverted counts and
        experiment descriptions, then weaves them with connectors.
        """
        applied: int = data.get("applied", 0)
        reverted: int = data.get("reverted", 0)
        descriptions: list[str] = data.get("descriptions", [])

        reasoning: list[str] = []
        total = applied + reverted
        if total > 0:
            reasoning.append(f"{total} experiments with my own heuristics")
            if applied:
                reasoning.append(f"{applied} applied successfully")
            if reverted:
                reasoning.append(f"{reverted} reverted after verification")
            for desc in descriptions[:2]:
                reasoning.append(f"including {desc}")
        else:
            reasoning.append("no experiments yet")

        if not reasoning:
            return None

        opening = self._compose_reasoning_opening(emotion, "experiments")
        main = reasoning[0].rstrip(".")
        sentence = f"{opening} {main}."
        for clause in reasoning[1:3]:
            connector = self._pick_connector(emotion)
            cleaned = clause.strip().rstrip(".")
            sentence += f" {connector.capitalize()} {cleaned}."
        return sentence

    def _compose_growth_from_data(
        self, data: dict[str, Any], emotion: EmotionalState
    ) -> str | None:
        """Compose from growth narrative data.

        The growth narrative is already prose-like. Extract the most
        meaningful sentences and let the grammar frame them with
        openers and hedging.
        """
        narrative: str = data.get("narrative", "")
        if is_blank(narrative):
            return None

        # Extract the first 2-3 meaningful sentences
        sentences: list[str] = []
        for line in narrative.splitlines():
            for s in _sentences(line.strip()):
                s = s.strip()
                if s and len(s) > 10:
                    sentences.append(s)
            if len(sentences) >= 3:
                break
        if not sentences:
            return None

        # Weave with an emotion-modulated opening
        opening = self._compose_reasoning_opening(emotion, "growth")
        main = sentences[0].rstrip(".")
        result = f"{opening} {main}."
        for s in sentences[1:3]:
            connector = self._pick_connector(emotion)
            cleaned = s.rstrip(".")
            result += f" {connector.capitalize()} {cleaned}."
        return result

    def _compose_reasoning_opening(self, emotion: EmotionalState, topic: str) -> str:
        """Compose an opening phrase for reasoning-based content."""
        return self._lexical_pick("reasoning_opener")

    def _pick_connector(self, emotion: EmotionalState) -> str:
        """Pick a connector phrase for joining reasoning clauses."""
        return self._lexical_pick("reasoning_connector") or "and"

    def _compose_user_belief_content(
        self,
        user_belief: str,
        user_verb: str,
        emotion: EmotionalState,
    ) -> str | None:
        """Compose a response from what it knows about the user.

        The verb and values come from the user profile (structured
        data); the framing is a simple structural connector.
        """
        belief = user_belief.strip().rstrip(".")
        if not belief:
            return None
        return f"You {user_verb} {belief}."

    def _compose_situation_answer_content(
        self,
        situation_answer: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot from discourse-situation state.

        The situation model tracks the world a conversation is
        describing — who is where, who is carrying what. The question
        handler reads that state and hands it over here as data.

        The surface form comes from the concept network, not from here:
        ``find_situation_verbs`` returns the phrasing templates seeded
        (or learned) under ``_cat:situation_verb:<kind>``, this picks
        one, and the entity/place it is about fills the slots. So the
        sentences are hers — chosen from her own vocabulary and
        changing as she learns more ways to put it — while the facts
        are the user's, from what they described.

        Keys in situation_answer:
        - "kind": which relation was asked about — "location",
          "location_candidates", "carrying", "present_at", or a
          "verdict_*" kind when a polar question was judged
        - "subject": the entity (or place) the answer is about
        - "objects": the locations, objects, or entities found
        - "claim": optional — the checked content of a judged claim,
          for verdict kinds that restate what was judged
        """
        if self._network is None:
            return None
        kind = situation_answer.get("kind", "")
        subject = situation_answer.get("subject", "")
        objects: list[str] = list(situation_answer.get("objects", []))

        if not kind or not subject or not objects:
            return None

        templates = self._network.find_situation_verbs(kind)
        if not templates:
            return None
        template = self._rng.choice(templates)

        # Fill-ins. Entity names arrive normalized (the model lowercases
        # them for matching), so people are re-cased here; places and
        # objects stay lowercase because they are common nouns. The
        # seeded templates carry their own articles, so fill-ins are
        # bare noun phrases — adding "the" here produced "the the
        # milk".
        people = [self._name_case(o) for o in objects]
        # The handler reports `present_at` the other way round from the
        # other kinds: it puts the *place* in "subject" and the people
        # in "objects", because the question was "who is in X?". Map
        # accordingly, or "John and Mary are in the john" comes out.
        place = subject if kind == "present_at" else objects[0]
        fill = {
            "subject": self._name_case(subject),
            "place": place,
            "places": self._join_disjunction(objects),
            "objects": self._join_list([f"the {o}" for o in objects]),
            "who": self._join_list(people),
            # Subject-verb agreement on the coordinated subject, so
            # "John and Mary are" rather than "John and Mary is".
            "be": "are" if len(people) > 1 else "is",
            # The judged content for verdict answers — "yes — mary is
            # in the kitchen" restates what correspondence checked.
            "claim": situation_answer.get("claim", ""),
        }
        try:
            return template.format(**fill)
        except (KeyError, IndexError):
            # A learned phrasing may carry slots this answer cannot
            # fill. Skip it rather than emitting a broken sentence.
            logger.debug("situation phrasing %r did not fit answer slots", template)
            return None

    @staticmethod
    def _name_case(name: str) -> str:
        """Casing for a person's name as it will be spoken.

        The situation model normalizes entity keys to lowercase so
        lookups match regardless of how the user capitalized them, so a
        proper name arrives as "mary". Capitalizing the first letter
        restores speech form.
        """
        cleaned = name.strip()
        if not cleaned:
            return cleaned
        return cleaned[0].upper() + cleaned[1:]

    @staticmethod
    def _join_disjunction(items: list[str]) -> str:
        """Join alternatives: a, b, or c — for uncertain locations."""
        if len(items) == 1:
            return items[0]
        if len(items) == 2:
            return f"{items[0]} or {items[1]}"
        return ", ".join(items[:-1]) + f", or {items[-1]}"

    @staticmethod
    def _join_list(items: list[str]) -> str:
        """Join a list into an English coordination: a, b, and c."""
        if len(items) == 1:
            return items[0]
        if len(items) == 2:
            return f"{items[0]} and {items[1]}"
        return ", ".join(items[:-1]) + f", and {items[-1]}"

    def _compose_relation_answer_content(
        self,
        relation_answer: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot from structured relation-answer metadata.

        This is how it answers wh-questions like "who created you?" or
        "what does X depend on?" — the question handler traverses the
        concept network along specific relations in a specific direction
        and supplies the structured edges. This method weaves them into
        a natural statement, using first-person pronouns for self-
        reference and emotion-modulated structural openings.

        The openings are structural connectors (building blocks), not
        the content itself — the factual content (who/what/where)
        comes from the concept network via the structured data.

        Keys in relation_answer:
        - "subject": display name of the question subject
        - "subject_is_self": whether the subject is "genesis"
        - "direction": "incoming" or "outgoing"
        - "verb": natural verb for the relation (e.g. "creates")
        - "objects": list of display names of the related concepts
        """
        subject = relation_answer.get("subject", "")
        subject_is_self = relation_answer.get("subject_is_self", False)
        direction = relation_answer.get("direction", "outgoing")
        verb = relation_answer.get("verb", "")
        objects: list[str] = relation_answer.get("objects", [])

        if not objects or not verb:
            return None

        # Build the object listing — structural joining, not content.
        if len(objects) == 1:
            obj_listing = objects[0]
        elif len(objects) == 2:
            obj_listing = f"{objects[0]} and {objects[1]}"
        else:
            obj_listing = ", ".join(objects[:-1]) + f", and {objects[-1]}"

        # Compose the core factual statement from the structured data.
        # The subject/objects/verb all come from the concept network.
        # The verb arrives in 3sg form ("needs", "is a kind of"); adjust
        # it for first-person subjects and coordinated plural objects.
        if direction == "incoming":
            # "Who created you?" → "Alice created me" / "Alice created X"
            obj_verb = agree_verb_phrase(verb, True) if len(objects) > 1 else verb
            if subject_is_self:
                core = f"{obj_listing} {obj_verb} me"
            else:
                core = f"{obj_listing} {obj_verb} {subject}"
        else:
            # "What does X depend on?" → "X depends on Y"
            if subject_is_self:
                core = f"I {self._first_person(verb)} {obj_listing}"
            else:
                core = f"{subject} {verb} {obj_listing}"

        # Structural opening from the lexicon, or none
        opening = self._lexical_pick("relation_opener")

        if opening:
            return f"{opening} {core}."
        return f"{core}."

    def _compose_vision_scene_content(
        self,
        scene: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot from a structured visual scene.

        The vision layer supplies the percept as data — lighting,
        color, recognized faces, objects with colors and positions,
        light direction — and this method composes a *predicate* from
        it ("seeing a dim, warm scene with a blue cup on the right").
        The grammar's self-report frames supply the subject and
        framing, so what it speaks is assembled at utterance time
        from its percept rather than recited from a vision-side
        template.

        Keys in scene (from ``VisionScene.as_metadata``):
        - "light": light level word ("dim", "bright", ...)
        - "warmth": "warm" / "cool" / "neutral"
        - "color": dominant color name
        - "faces": recognized names
        - "n_unknown_faces": unrecognized face count
        - "objects": [{"name", "color", "position"}]
        - "light_direction": "left" / "right" / ""
        - "structured": high contour count (busy scene)
        - "regions": {"left"/"center"/"right"/"top"/"bottom": color name}
        - "chromatic_features": V1 opponent-channel feature count
        - "view_motion": dorsal-stream kind ("still" | "turn" | "travel" |
          "unresolved")
        - "view_direction": heading or swing ("left"/"right"/"up"/"down"/
          "toward"/"away")
        - "near_structure": third of the field with the strongest parallax
        - "movers": independently-moving tracked structure count
        """
        light = str(scene.get("light", "") or "")
        warmth = str(scene.get("warmth", "") or "")
        color = str(scene.get("color", "") or "")
        objects = [
            o
            for o in scene.get("objects", [])
            if isinstance(o, dict) and str(o.get("name", "")).strip()
        ]

        # Scene core — "a dim, warm blue scene" / "a bright scene".
        mood = f"{light}, {warmth}" if warmth and warmth != "neutral" else light
        if color and color not in ("gray", "white", "unknown"):
            scene_core = (
                f"{indefinite_article(mood)} {mood} {color} scene"
                if mood
                else f"{indefinite_article(color)} {color} scene"
            )
        else:
            scene_core = f"{indefinite_article(mood)} {mood} scene" if mood else "a scene"

        detail = self._vision_scene_detail(scene, objects, color)

        # Candidate frames — grammar seeds (building blocks). Several
        # phrasings exist so the same percept surfaces in different
        # words; emotional state modulates the selection.
        candidates: list[str] = [
            f"seeing {scene_core}{detail}",
            f"looking at {scene_core}{detail}",
            f"taking in {scene_core}{detail}",
        ]

        # Emotion-modulated selection, same pattern as the other
        # content composers: high creativity favors the less
        # conventional later candidates; caution favors the simplest.
        if emotion.creativity > 0.6:
            return self._rng.choice(candidates[len(candidates) // 2 :] or candidates)
        if emotion.caution > 0.5 or emotion.openness_to_engage < 0.4:
            return candidates[0]
        return self._rng.choice(candidates)

    def _vision_scene_detail(
        self,
        scene: dict[str, Any],
        objects: list[dict],
        color: str,
    ) -> str:
        """Assemble the trailing detail clause of a scene report.

        Everything after the mood core — who is there, what objects,
        the region colors, light direction, structure, motion —
        concatenated in percept order, each clause empty when its
        feature is absent.
        """
        faces = [str(n).strip() for n in scene.get("faces", []) if str(n).strip()]
        try:
            n_unknown = int(scene.get("n_unknown_faces", 0))
        except (TypeError, ValueError):
            n_unknown = 0

        # People — faces carry names; unknown faces count as strangers.
        # Both can coexist: "with Alice and someone unfamiliar".
        named = [n.capitalize() for n in faces]
        named_phrase = ""
        if len(named) == 1:
            named_phrase = named[0]
        elif named:
            named_phrase = f"{', '.join(named[:-1])} and {named[-1]}"
        unknown_phrase = ""
        if n_unknown == 1:
            unknown_phrase = "someone unfamiliar"
        elif n_unknown > 1:
            unknown_phrase = f"{n_unknown} unfamiliar people"
        both = [p for p in (named_phrase, unknown_phrase) if p]
        people = f" with {' and '.join(both)}" if both else ""

        objects_clause = self._vision_objects_clause(objects)

        # Spatial colour — the scene's colour map as data ("green on
        # the left", "brown in the center"). Regions that name the
        # same colour as the whole scene add nothing, and achromatic
        # regions are the floor rather than colour worth reporting.
        regions_clause = self._vision_regions_clause(
            scene.get("regions"), exclude={color, "gray", "white", "black", "unknown"}
        )

        light_dir = str(scene.get("light_direction", "") or "")
        light_clause = f", light coming in from the {light_dir}" if light_dir else ""
        structure_clause = ", a lot of structure in it" if scene.get("structured") else ""
        motion_clause = self._vision_motion_clause(scene)

        return (
            f"{people}{objects_clause}{regions_clause}"
            f"{light_clause}{structure_clause}{motion_clause}"
        )

    @staticmethod
    def _vision_regions_clause(regions: Any, exclude: set[str]) -> str:
        """Spatial colour clause — ", green on the left" or ", green on
        the left and brown in the center" (empty when every region is
        achromatic or repeats the scene's dominant colour)."""
        if not isinstance(regions, dict) or not regions:
            return ""
        prepositions = {
            "left": "on the left",
            "right": "on the right",
            "center": "in the center",
            "top": "at the top",
            "bottom": "at the bottom",
        }
        bits: list[str] = []
        for place in ("left", "center", "right", "top", "bottom"):
            c = str(regions.get(place, "") or "").strip()
            if not c or c in exclude:
                continue
            bits.append(f"{c} {prepositions[place]}")
            if len(bits) == 2:
                break
        if not bits:
            return ""
        return ", " + " and ".join(bits)

    @staticmethod
    def _vision_motion_clause(scene: dict[str, Any]) -> str:
        """Dorsal-stream clause — self-motion and parallax depth the
        two-view geometry read between this look and the last.

        Phrase candidates are grammar building blocks composed from
        the percept's data; "still" and "unresolved" add no clause —
        stillness is the default expectation of a look, and an
        unresolved field is not a fact worth asserting."""
        kind = str(scene.get("view_motion", "") or "")
        direction = str(scene.get("view_direction", "") or "")
        near = str(scene.get("near_structure", "") or "")
        try:
            movers = int(scene.get("movers", 0) or 0)
        except (TypeError, ValueError):
            movers = 0
        bits: list[str] = []
        if kind == "turn":
            bits.append(f"the view swinging {direction}" if direction else "the view swinging")
        elif kind == "travel":
            if direction == "toward":
                bits.append("pressing forward through it")
            elif direction == "away":
                bits.append("the scene receding")
            elif direction:
                bits.append(f"the view drifting {direction}")
            else:
                bits.append("the view shifting")
        if near:
            place = {"left": "on the left", "right": "on the right"}.get(near, "ahead")
            bits.append(f"nearby structure {place}")
        if movers == 1:
            bits.append("something moving on its own")
        elif movers > 1:
            bits.append(f"{movers} things moving on their own")
        return (", " + ", ".join(bits)) if bits else ""

    @staticmethod
    def _vision_objects_clause(objects: list[dict[str, Any]]) -> str:
        """Objects clause — "a blue cup on the right and a laptop in the
        center" (empty string when the scene names no objects)."""
        obj_phrases: list[str] = []
        for o in objects[:4]:
            name = str(o.get("name", "")).strip().replace("_", " ")
            obj_color = str(o.get("color", "") or "")
            position = str(o.get("position", "") or "")
            noun = f"{obj_color} {name}".strip()
            phrase = f"{indefinite_article(noun)} {noun}"
            obj_phrases.append(f"{phrase} {position}".rstrip())
        if not obj_phrases:
            return ""
        if len(obj_phrases) == 1:
            return f" — {obj_phrases[0]}"
        if len(obj_phrases) == 2:
            return f" — {obj_phrases[0]} and {obj_phrases[1]}"
        return f" — {', '.join(obj_phrases[:-1])}, and {obj_phrases[-1]}"

    def _compose_vision_status_content(
        self,
        status: str,
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot when perception itself reported
        a status rather than a scene.

        The vision layer supplies the status as data ("unavailable",
        "mid_update", "unprocessed", "load_failed", "gated"); this
        composes a predicate describing the perceptual situation so
        the grammar's self-report frames produce grammatical output
        ("I am unable to reach my eye right now"). The candidate
        lists are grammar seeds — building blocks — selected by
        emotional state.
        """
        status = status.strip().lower().replace(" ", "_")
        if status == "unavailable":
            candidates = [
                "unable to reach my eye right now",
                "not getting anything from my eye",
                "without visual input at the moment",
            ]
        elif status == "gated":
            # Thalamic relay closed — the TRN blocks transmission
            # upstream of cortex (deep sleep, eyes functionally shut).
            candidates = [
                "asleep — the light arrives but nothing gets through to me",
                "unable to see while my visual gate is closed",
                "without vision while I sleep",
            ]
        elif status == "mid_update":
            candidates = [
                "in the middle of a visual update — my seeing is changing",
                "still reorganizing how I see",
                "adjusting my visual system right now",
            ]
        elif status == "load_failed":
            candidates = [
                "unable to read that image",
                "not able to make out that file as an image",
                "failing to load what you showed me",
            ]
        elif status == "unprocessed":
            candidates = [
                "seeing something I can't make sense of yet",
                "looking, but not understanding what's there",
                "taking in light without recognizing anything in it",
            ]
        else:
            return None
        if emotion.creativity > 0.6:
            return self._rng.choice(candidates[len(candidates) // 2 :] or candidates)
        if emotion.caution > 0.5 or emotion.openness_to_engage < 0.4:
            return candidates[0]
        return self._rng.choice(candidates)

    def _compose_test_result_content(
        self,
        result: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot from a code test run's outcome.

        The code-tools layer supplies structured data — the target
        path, whether the run passed, and the runner's own tail line —
        and this composes a *predicate* from it. The candidate phrasings
        are grammar seeds (building blocks) selected by emotional state;
        the verdict and the path are always the runner's actual output,
        never a sentence pre-written by the caller.
        """
        path = str(result.get("path", "")).strip()
        if not path:
            return None
        detail = str(result.get("detail", "")).strip()

        if result.get("passed"):
            candidates = [
                f"getting the tests for {path} passing",
                f"finding the tests for {path} pass",
                f"having the tests for {path} green",
            ]
        else:
            candidates = [
                f"not getting the tests for {path} to pass",
                f"finding the tests for {path} failing",
                f"having the tests for {path} break",
            ]
        composed = self._pick_problem_frame(candidates, emotion)
        if detail and composed:
            composed = f"{composed} — {detail}"
        return composed

    def _pick_problem_frame(self, candidates: list[str], emotion: EmotionalState) -> str | None:
        """Emotion-modulated frame selection — the same pattern the
        other content composers use."""
        if not candidates:
            return None
        if emotion.creativity > 0.6:
            return self._rng.choice(candidates[len(candidates) // 2 :] or candidates)
        if emotion.caution > 0.5 or emotion.openness_to_engage < 0.4:
            return candidates[0]
        return self._rng.choice(candidates)

    def _compose_preference_content(
        self,
        preference: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot from preference metadata.

        The cognition engine supplies structured data — ``status``
        (has / none_favorite / knows_no_pref / learning / discovering),
        ``topic``, and ``value`` — and this method composes a
        *predicate* (not a full sentence) from it. The grammar's
        self-report frames then complete the sentence ("I am
        {content}.", "{self_report_opener} {content}.", ...), so the
        subject and framing come from grammar seeds and the semantics
        come from its actual self-model state.

        The candidate lists below are grammar seeds (building blocks),
        not hardcoded responses — several predicate forms exist per
        status and the emotional state modulates the selection, so
        the same preference state surfaces in different words across
        interactions.
        """
        status = preference.get("status", "")
        topic = preference.get("topic", "")
        value = preference.get("value", "")
        if not status:
            return None

        candidates: list[str] = []
        if status == "has" and value:
            if topic:
                candidates.extend(
                    [
                        f"drawn to {value} as my favorite {topic}",
                        f"settled on {value} as my favorite {topic}",
                        f"partial to {value} when it comes to {topic}",
                    ]
                )
            else:
                candidates.extend(
                    [
                        f"enjoying {value}",
                        f"drawn to {value}",
                        f"finding real enjoyment in {value}",
                    ]
                )
        elif status == "none_favorite" and topic:
            candidates.extend(
                [
                    f"still deciding on a favorite {topic}",
                    f"still forming a preference about {topic}",
                    f"without a settled favorite {topic} yet",
                ]
            )
        elif status == "knows_no_pref" and topic:
            candidates.extend(
                [
                    f"familiar with {topic}, though without a preference yet",
                    f"aware of {topic}, still unsure what I prefer",
                    f"acquainted with {topic} — no preference has formed",
                ]
            )
        elif status == "learning" and topic:
            candidates.extend(
                [
                    f"still learning about {topic}",
                    f"still getting to know {topic}",
                    f"not yet familiar enough with {topic} to prefer",
                ]
            )
        elif status == "discovering":
            candidates.extend(
                [
                    "still discovering what I enjoy",
                    "still working out what I enjoy",
                    "in the middle of forming my tastes",
                ]
            )

        if not candidates:
            return None

        # Emotion-modulated selection, same pattern as the feeling
        # fragment composer: high creativity favors the less
        # conventional later candidates; caution favors the simplest.
        if emotion.creativity > 0.6:
            return self._rng.choice(candidates[len(candidates) // 2 :] or candidates)
        if emotion.caution > 0.5 or emotion.openness_to_engage < 0.4:
            return candidates[0]
        return self._rng.choice(candidates)

    def _compose_feeling_fragments_content(
        self,
        fragments: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot from feeling fragments.

        The fragments (emotion_words, mode_words, cause_words,
        plasticity_words, concern) come from the concept network via
        the FeelingReporter. This method weaves them into a natural
        first-person expression using varied grammatical structures —
        not a fixed "I feel X and Y" frame.

        The structures below are grammar seeds (building blocks). The
        actual words come from the concept network; the structures give
        its variety in how it expresses the same state. It selects
        among them based on what fragments are available and its
        emotional state, so the same neurochemistry produces different
        surface forms across interactions.
        """
        emotion_words: list[str] = fragments.get("emotion_words", [])
        mode_words: list[str] = fragments.get("mode_words", [])
        cause_words: list[str] = fragments.get("cause_words", [])
        plasticity_words: list[str] = fragments.get("plasticity_words", [])
        concern = fragments.get("concern")

        # Pick one word from each available fragment list. The rng
        # gives it variation across interactions.
        ew = self._rng.choice(emotion_words) if emotion_words else ""
        mw = self._rng.choice(mode_words) if mode_words else ""
        cw = self._rng.choice(cause_words) if cause_words else ""
        pw = self._rng.choice(plasticity_words) if plasticity_words else ""

        if not ew and not mw and not cw and not pw:
            return None

        # ── Build candidate expressions from the available fragments ──
        candidates = self._feeling_candidates(ew, mw, cw, pw)

        if not candidates:
            return None

        # Select among candidates, modulated by emotional state.
        # Higher creativity → more varied structures; lower creativity
        # → simpler structures (the first candidates, which tend to be
        # the more conventional "I feel X" forms).
        if emotion.creativity > 0.6:
            # High creativity: prefer the more varied later candidates
            pick = self._rng.choice(candidates[len(candidates) // 2 :] or candidates)
        elif emotion.caution > 0.5 or emotion.openness_to_engage < 0.4:
            # Cautious/low engagement: prefer simpler first candidates
            pick = candidates[0]
        else:
            pick = self._rng.choice(candidates)
        if concern and self._rng.random() < 0.3:
            pick = f"{pick}. {concern}"
        return pick

    def _feeling_candidates(self, ew: str, mw: str, cw: str, pw: str) -> list[str]:
        """Build candidate expressions from the picked fragments.

        Each candidate is a grammatical seed (building block) filled
        with concept-network words. The structures vary so it doesn't
        always say "I feel X and Y" — it can also say "there's X in
        me", "my mind is Y", "something in me is X", etc.
        """
        candidates: list[str] = []

        if ew and mw:
            candidates.extend(
                [
                    f"I feel {ew} and {mw}",
                    f"there's {ew} in me right now, and my mind is {mw}",
                    f"something in me is {ew} — {mw}",
                    f"I'm {ew}, {mw}",
                ]
            )
        if ew and not mw:
            candidates.extend(
                [
                    f"I feel {ew}",
                    f"there's {ew} running through me",
                    f"something in me is {ew}",
                    f"{ew} — that's where I am right now",
                ]
            )
        if mw and not ew:
            candidates.extend(
                [
                    f"my mind is {mw}",
                    f"I'm {mw}",
                    f"there's {indefinite_article(mw)} {mw} quality to my thinking",
                ]
            )
        if cw:
            # Cause words describe why it feels this way (negative
            # valence only). Append as a grounding clause.
            cause_candidates = [
                f"I'm {cw}",
                f"something feels {cw}",
            ]
            # Append cause to an existing candidate or use standalone
            if candidates:
                cc = self._rng.choice(cause_candidates)
                candidates.append(f"{candidates[0]}. {cc.capitalize()}")
            else:
                candidates.extend(cause_candidates)
        if pw:
            # Plasticity words describe learning capacity (low/closed).
            # These are verb phrases ("can't absorb") or noun phrases
            # ("mind closed to new learning").
            if pw.startswith(("can't", "can not", "cannot", "don't", "do not")):
                pw_candidates = [f"I {pw}", f"{pw} — that's where I am"]
            else:
                pw_candidates = [pw, f"my mind feels {pw}"]
            if candidates:
                pc = self._rng.choice(pw_candidates)
                candidates.append(f"{candidates[0]}. {pc.capitalize()}")
            else:
                candidates.extend(pw_candidates)
        return candidates

    # ── Self-fragment composition ──────────────────────────────────
    #
    # The self-composer (self/composer.py) supplies typed semantic
    # fragments — (kind, text) pairs describing its state, identity,
    # creator, capabilities, dreams, or reflections. The kinds are
    # syntactic categories, not surface strings:
    #
    #   "name"   — a proper name ("Genesis")
    #   "trait"  — an adjective/short descriptor, copular-grouped
    #   "comp"   — a complement phrase ("feeling anxious", "a kind of
    #              mind", "made by alice", "still becoming")
    #   "pred"   — a verb predicate that takes "I" as subject ("care
    #              most about X", "emerges from Y", "can work with Z")
    #   "clause" — a self-standing clause with its own subject
    #              ("alice is a creator", "my thinking is scattered")
    #   "marker" — a structural state marker ("[plasticity_gate:closed]")
    #
    # This method owns the surface realization: subject insertion,
    # copula grouping, clause ordering, conjunction. It returns
    # candidate utterances so the engine's selection and voice can
    # pick and modulate — nothing here is the one true string.

    # Irregular first↔third-person verb forms used by the predicate
    # normalizers below. Regular verbs fall through to suffix rules.
    _PRED_TO_3SG: ClassVar[dict[str, str]] = {
        "have": "has",
        "haven't": "hasn't",
        "do": "does",
        "don't": "doesn't",
        "am": "is",
        "are": "is",
        "be": "is",
        "'m": "is",
    }
    _PRED_TO_1SG: ClassVar[dict[str, str]] = {
        "has": "have",
        "hasn't": "haven't",
        "does": "do",
        "doesn't": "don't",
        "is": "am",
        "was": "was",
    }

    @staticmethod
    def _looks_3sg(word: str) -> bool:
        """Heuristic: does this verb form look third-person singular?"""
        low = word.lower()
        if low in ("has", "does", "doesn't", "is", "hasn't"):
            return True
        # "emerges", "depends", "creates" — ends in s but not ss/us
        return low.endswith("s") and not low.endswith(("ss", "us", "ous"))

    def _first_person(self, pred: str) -> str:
        """Normalize a predicate's leading verb for "I <pred>".

        Tolerates both base forms ("care most about") and 3sg forms
        ("emerges from", "has") — the self-composer draws verbs from
        the concept network in whatever form the seeds carry.
        """
        parts = pred.split(" ", 1)
        first, rest = parts[0], (parts[1] if len(parts) > 1 else "")
        low = first.lower()
        if low in self._PRED_TO_1SG:
            first = self._PRED_TO_1SG[low]
        elif low == "am" or low == "'m":
            first = "am"
        elif low.endswith("ies") and len(low) > 3:
            first = first[:-3] + "y"  # tries → try
        elif low.endswith(("ches", "shes", "sses", "xes", "zes")):
            first = first[:-2]  # watches → watch
        elif low.endswith("oes"):
            first = first[:-2]  # goes → go
        elif self._looks_3sg(first):
            first = first[:-1]  # emerges → emerge, cares → care
        return f"{first} {rest}".strip() if rest else first

    def _third_person(self, pred: str) -> str:
        """Normalize a predicate's leading verb for "who <pred>"."""
        parts = pred.split(" ", 1)
        first, rest = parts[0], (parts[1] if len(parts) > 1 else "")
        low = first.lower()
        if low in self._PRED_TO_3SG:
            first = self._PRED_TO_3SG[low]
        elif low.endswith(("ch", "sh", "ss", "x", "z", "o")):
            first = first + "es"  # watch → watches, go → goes
        elif low.endswith("y") and len(low) > 1 and low[-2] not in "aeiou":
            first = first[:-1] + "ies"  # try → tries
        elif not self._looks_3sg(first):
            first = first + "s"  # care → cares, emerge → emerges
        return f"{first} {rest}".strip() if rest else first

    @staticmethod
    def _join_fragments(items: list[str]) -> str:
        """Join items into a list phrase: 'a', 'a and b', 'a, b, and c'."""
        if not items:
            return ""
        if len(items) == 1:
            return items[0]
        if len(items) == 2:
            return f"{items[0]} and {items[1]}"
        return f"{', '.join(items[:-1])}, and {items[-1]}"

    def _compose_self_fragments(
        self,
        fragments: list[Any],
    ) -> list[str]:
        """Compose candidate utterances from typed self fragments.

        The fragments are semantic inventory from the self-composer
        (or from cognition callers passing notes/narrative clauses).
        This method produces several surface realizations — a compact
        complement cluster ("Genesis, curious and creative, who cares
        most about understanding") and first-person sentence forms
        ("I'm Genesis — curious and creative. I care most about
        understanding."). The engine selects among candidates and
        the grammar frames may prepend openers; sentence-form
        candidates always lead with "I'm"/"I am"/a clause so the
        pronoun-collision guard in the generator stays coherent.
        """
        names, traits, comps, preds, clauses, _markers = self._sort_self_fragments(fragments)

        # Trailing self-standing material — clauses each become their
        # own sentence appended to whichever lead the candidate uses.
        # Case is preserved from the fragment (proper nouns keep their
        # capitalization mid-sentence); the voice layer capitalizes
        # sentence starts. Markers ("[plasticity_gate:closed]") are
        # diagnostic tags for logging/introspection, not speech —
        # they travel in metadata but are never realized as words.
        tail = [s for c in clauses if (s := c.strip().rstrip(".").strip())]

        candidates: list[str] = []

        # Lead material for first-person sentences: name, traits, and
        # complement phrases all attach to "I'm".
        lead_parts: list[str] = []
        if names:
            lead_parts.append(names[0])
        if traits:
            lead_parts.append(self._join_fragments(traits))
        lead_parts.extend(comps)

        # ── Candidate A: sentence form ──
        # "I'm Genesis, curious and creative. I care most about
        #  understanding. Alice is a creator."
        if lead_parts:
            sentences = [f"I'm {', '.join(lead_parts)}"]
            sentences.extend(f"I {self._first_person(p)}" for p in preds)
            sentences.extend(tail)
            candidates.append(". ".join(sentences))

        # ── Candidate B: copular cluster ──
        # "I'm Genesis, curious and creative, someone who cares most
        #  about understanding" — a complete sentence that also works
        # under "I am {content}" frames (the generator strips the
        # leading "I'm" to avoid pronoun collision).
        cluster: list[str] = list(lead_parts)
        if preds:
            rel = " and ".join(self._third_person(p) for p in preds)
            cluster.append(f"someone who {rel}")
        if cluster:
            cand = f"I'm {', '.join(cluster)}"
            if tail:
                cand = f"{cand}. {' '.join(tail)}"
            candidates.append(cand)

        # ── Candidate C: name + traits merged with a dash ──
        # "I'm Genesis — curious and creative. I care about X."
        if names and traits:
            sentences = [f"I'm {names[0]} — {self._join_fragments(traits)}"]
            sentences.extend(f"I'm {c}" for c in comps)
            sentences.extend(f"I {self._first_person(p)}" for p in preds)
            sentences.extend(tail)
            candidates.append(". ".join(sentences))

        # ── Pure-predicate fallback ──
        # No name/trait/comp material to lead a sentence — compose
        # the predicates as first-person sentences ("I care about X")
        # plus a complement-shaped form for the copula frames.
        if not candidates and preds:
            sentences = [f"I {self._first_person(p)}" for p in preds]
            sentences.extend(tail)
            candidates.append(". ".join(sentences))
            rel = " and ".join(self._third_person(p) for p in preds)
            cand = f"I'm someone who {rel}"
            if tail:
                cand = f"{cand}. {' '.join(tail)}"
            candidates.append(cand)

        # Clause-only sets (e.g. user notes, story sentences) — emit
        # each clause as its own sentence.
        if not candidates and tail:
            candidates.append(". ".join(tail))

        return [c for c in candidates if c]

    @staticmethod
    def _sort_self_fragments(
        fragments: list[Any],
    ) -> tuple[list[str], list[str], list[str], list[str], list[str], list[str]]:
        """Sort typed self fragments into (names, traits, comps,
        preds, clauses, markers) buckets. Untagged or unrecognized
        text lands in clauses."""
        names: list[str] = []
        traits: list[str] = []
        comps: list[str] = []
        preds: list[str] = []
        clauses: list[str] = []
        markers: list[str] = []
        for frag in fragments:
            if not isinstance(frag, (tuple, list)) or len(frag) != 2:
                # Untagged text — treat as a clause fragment.
                clauses.append(str(frag))
                continue
            kind, text = frag[0], str(frag[1]).strip()
            if not text:
                continue
            if kind == "name":
                names.append(text)
            elif kind == "trait":
                traits.append(text)
            elif kind == "comp":
                comps.append(text)
            elif kind == "pred":
                preds.append(text)
            elif kind == "marker":
                markers.append(text)
            else:
                clauses.append(text)
        return names, traits, comps, preds, clauses, markers

    def _with_qualification(self, content: str, qualification: dict[str, Any]) -> list[str]:
        """Attach a causal qualification to a conclusion.

        ``qualification`` is structured data from the thought composer:
        ``kind`` is "depends" (the subject has other dependencies) or
        "enables" (the object enables other things); ``subject``,
        ``object`` and ``others`` carry the graph-derived concepts.
        The connective frames here are grammar seeds; the content is
        the reasoner's conclusion and the concept names are its.
        """
        others = [str(o) for o in qualification.get("others", []) if str(o).strip()]
        if not others:
            return [content]
        subject = str(qualification.get("subject", "")).strip()
        obj = str(qualification.get("object", "")).strip()
        joined = self._join_fragments(others[:3])
        base = content.rstrip()
        candidates = [base]
        if qualification.get("kind") == "depends" and subject:
            candidates.extend(
                [
                    f"{base} But {subject} also depends on {joined}",
                    f"{base} Though {subject} depends on more than {obj or 'that'}",
                ]
            )
        elif qualification.get("kind") == "enables" and obj:
            candidates.extend(
                [
                    f"{base} And {obj} also enables {joined}",
                    f"{base} {obj.capitalize()} enables more than {subject or 'that'}, too",
                ]
            )
        return candidates

    def _compose_from_topic(
        self,
        topic: str,
        emotion: EmotionalState,
    ) -> str | None:
        """Compose content from a bare topic word by looking it up
        in the concept network.

        When the content is just a topic word like "cognition" or
        "water" (no knowledge metadata), this method looks up the
        concept in the network and composes a statement from its
        definition and edges. This prevents the output from being
        just the topic word plus hedging when it actually knows
        about the concept.

        Returns None if the concept doesn't exist or has no usable
        definition or edges — the caller falls back to the raw word.
        """
        net = self._network
        if net is None:
            return None
        # Normalize the topic — strip articles, lowercase for lookup
        topic_clean = topic.strip().rstrip(".!?")
        if not topic_clean:
            return None
        concept = net.get_concept(topic_clean)
        if concept is None:
            # Try capitalized — concept names are often capitalized
            concept = net.get_concept(topic_clean.capitalize())
        if concept is None:
            return None
        display = self._display_name(topic_clean)
        # Build from definition
        definition = concept.properties.get("definition", "")
        # Build from edges
        edges = net.get_edges(topic_clean, "out")
        if not edges:
            edges = net.get_edges(topic_clean.capitalize(), "out")
        # If we have a definition, use it as the core
        parts: list[str] = []
        if definition:
            parts.append(f"{display} {copula(display)} {definition}")
        # Add up to 2 relationship clauses from edges
        rel_clauses: list[str] = []
        seen_targets: set[str] = set()
        for edge in edges[:5]:
            rel = edge.relation.value
            target = edge.target
            if target.lower() == topic_clean.lower():
                continue
            if target.lower() in seen_targets:
                continue
            seen_targets.add(target.lower())
            verb = self._relation_verb(rel, self._display_name(target))
            if verb:
                # A bare copula takes an adjectival complement, never
                # an article — "is the clear" is not English.
                if verb.lower() in ("is", "are", "am"):
                    target_with_article = target
                else:
                    target_with_article = self._with_article(verb, target)
                rel_clauses.append(f"{verb} {target_with_article}")
            if len(rel_clauses) >= 2:
                break
        if rel_clauses:
            pron, plural = person_pronoun(topic_clean, self._network, display)
            first_clause = rel_clauses[0]
            if plural:
                first_clause = agree_verb_phrase(first_clause, True)
            parts.append(f"{pron.capitalize()} {first_clause}")
            if len(rel_clauses) > 1:
                parts.append(f"and {rel_clauses[1]}")
        if not parts:
            return None
        return ". ".join(parts) + ("." if not parts[-1].endswith(".") else "")

    @staticmethod
    def _relation_verb(rel: str, object_display: str = "") -> str:
        """Map a relation type to a verb phrase for composition."""
        if rel == "has_property":
            return property_verb_phrase(object_display)
        verbs = {
            "is_a": "is a kind of",
            "part_of": "is part of",
            "causes": "causes",
            "emerges_from": "emerges from",
            "similar_to": "is similar to",
            "opposite_of": "is the opposite of",
            "depends_on": "depends on",
            "enables": "enables",
            "leads_to": "can lead to",
            "creates": "creates",
            "harms": "can harm",
            "prevents": "prevents",
            "related_to": "relates to",
        }
        return verbs.get(rel, "")

    def _compose_knowledge_content(
        self,
        context: dict[str, Any],
        emotion: EmotionalState,
    ) -> str | None:
        """Compose the content slot from raw knowledge metadata.

        This is where Genesis actually generates language from what it
        knows. Instead of pre-composed template text, it takes the raw
        graph edges and definition and weaves them into a natural
        statement that reflects its emotional state and personality.

        The context carries:
        - "knowledge": list of (relation, target, weight) tuples
        - "definition": the concept's stored definition (or None)
        - "topic": the concept name it's reflecting on
        - "reasoning": list of reasoning conclusions (or [])
        - "confidence": its confidence in this knowledge
        """
        knowledge: list[tuple[str, str, float]] = context.get("knowledge", [])
        definition: str | None = context.get("definition")
        topic: str = context.get("topic", context.get("target_concept", ""))
        reasoning: list[str] = context.get("reasoning") or []
        confidence: float = context.get("confidence", 0.5)

        if not knowledge and not definition and not reasoning:
            return None

        display = self._display_name(topic) if topic else "this"

        # ── Separate definition from relationship facts ──
        definition, rel_facts = self._separate_definition_and_facts(knowledge, definition)

        # ── Build clauses from relationship facts ──
        # Each fact becomes a predicate clause: "{verb} {target}".
        # Multiple clauses are joined with connectors that vary
        # with emotional state. Facts whose target IS the topic are
        # tautologies ("excited feels the excited") — drop them.
        clauses, seen_clauses, seen_targets = self._build_rel_clauses(
            [f for f in rel_facts if self._display_name(f[1]).lower() != display.lower()]
        )

        # ── Add reasoning conclusions ──
        self._add_reasoning_clauses(reasoning, display, seen_clauses, seen_targets, clauses)

        # ── Filter tautological clauses ──
        # If a definition is present, filter out clauses whose target
        # appears in the definition text. Without this, "Cognition
        # is an alert cognitive state..." is followed by "It is alert
        # cognitive state." — the same content as a relationship clause.
        defn = self._clean_definition(definition)
        if defn:
            clauses = self._filter_tautological_clauses(clauses, defn)

        # ── Compose the full statement as proper sentences ──
        # No opening here — the grammar structure handles framing via
        # its own {reflection_opener}, {hedging}, etc. slots. Adding an
        # opening here produces stacked openings when the grammar also
        # has an opening slot: "I've been thinking — Looking at memory,
        # memory is..." (two openings concatenated).
        sentences: list[str] = []

        # Build the first sentence from (definition or first clause)
        first_sentence, clauses = self._first_knowledge_sentence(defn, clauses, display, topic)
        if first_sentence is None:
            # No definition and no relationship clauses — it can't
            # compose from its understanding. Return None so the caller
            # knows to stay silent rather than reciting a template.
            return None
        sentences.append(first_sentence)

        # Relationship clauses — form a second sentence using a pronoun
        rel_sentence = self._compose_rel_sentence(clauses, display, emotion, concept_id=topic)
        if rel_sentence:
            sentences.append(rel_sentence)

        sentences.extend(self._extra_knowledge_sentences(topic, emotion, seen_targets, context))

        # Closing — confidence-based qualification
        closing = self._compose_closing(confidence, emotion)
        if closing:
            sentences.append(closing)

        return " ".join(sentences)

    def _first_knowledge_sentence(
        self,
        defn: str | None,
        clauses: list[str],
        display: str,
        topic: str,
    ) -> tuple[str | None, list[str]]:
        """Compose the opening sentence and return remaining clauses.

        With a definition: "{display} is {defn}." Without one, the
        first relationship clause is asserted directly. Returns
        ``(None, clauses)`` when there's nothing to say.
        """
        if defn:
            return f"{display} {copula(display)} {defn}.", clauses

        if not clauses:
            return None, clauses

        # Apply verb agreement for plural subjects.
        # "Dreams connects to" → "Dreams connect to"
        if copula(display) == "are":
            clauses = [agree_verb_phrase(c, True) for c in clauses]
        # No definition — assert the first walked clause plainly.
        # Subject + verb phrase compose from the network; no canned
        # knowledge-framing preamble is prepended.
        first_clause = clauses[0]
        clauses = clauses[1:]
        first = display[0].upper() + display[1:] if display else display
        return f"{first} {first_clause}.", clauses

    def _extra_knowledge_sentences(
        self,
        topic: str,
        emotion: EmotionalState,
        seen_targets: set[str],
        context: dict[str, Any],
    ) -> list[str]:
        """Compose optional contextual sentences for a knowledge statement.

        Adds a latent-space discovery sentence (concepts semantically
        close to the topic that aren't already connected by explicit
        typed edges — generalization through vector proximity, not just
        graph edges it was explicitly taught) and an episodic-memory
        sentence. Skipped when caution is high or it's not receptive.
        """
        extra: list[str] = []

        # Latent-space discoveries. Skipped when caution is high (it
        # stays with what it knows for certain) or when it's not
        # receptive.
        if (
            self._embeddings is not None
            and getattr(self._embeddings, "has_embeddings", False)
            and emotion.caution <= 0.7
            and emotion.openness_to_engage >= 0.3
            and topic
        ):
            latent_sentence = self._compose_latent_discovery_sentence(
                topic,
                emotion,
                seen_targets,
            )
            if latent_sentence:
                extra.append(latent_sentence)

        # Episodic memory — if a highly-relevant episode was attached,
        # weave it in as a sentence that connects its concept-network
        # knowledge to what it remembers. This is not a verbatim
        # quote; the memory content is framed by a connective opener.
        memory_text = context.get("memory")
        if memory_text:
            memory_sentence = self._compose_memory_sentence(memory_text, emotion)
            if memory_sentence:
                extra.append(memory_sentence)

        return extra

    def _compose_latent_discovery_sentence(
        self,
        topic: str,
        emotion: EmotionalState,
        seen_targets: set[str],
    ) -> str | None:
        """Compose a sentence from latent-space discoveries.

        Uses the embedding store to find concepts semantically close to
        the topic that aren't already mentioned. This is where it
        generalizes — connecting ideas through vector proximity rather
        than only through explicit graph edges.

        The sentence is framed as an exploratory connection ("it also
        reminds me of...") rather than a definitive statement, reflecting
        that these are discovered associations, not taught facts.
        """
        if self._embeddings is None or self._network is None:
            return None
        if not getattr(self._embeddings, "has_embeddings", False):
            return None
        try:
            similar = self._embeddings.find_similar_concepts(
                topic,
                k=3,
                threshold=0.55,
            )
        except Exception:  # noqa: BLE001
            return None
        if not similar:
            return None

        # Filter out concepts already mentioned and noisy targets.
        # Also filter out lexical matches — concepts that share words
        # with the query concept. Without this, "water" matches "water
        # surface towards" and "water inside" (lexical matches from
        # TF-IDF), not semantic matches like "ocean" or "liquid".
        topic_words = set(topic.lower().replace("_", " ").split())
        candidates: list[str] = []
        lexical_candidates: list[str] = []  # fallback if no semantic matches
        for concept_name, _similarity in similar:
            if concept_name.lower() in seen_targets:
                continue
            if concept_name.lower() == topic.lower():
                continue
            if self._network.get_concept(concept_name) is None:
                continue
            # Skip concepts with noisy names (code paths, etc.)
            base = concept_name.split("#")[0]
            if ":" in base or "." in base or "__" in base:
                continue
            if len(base) <= 1:
                continue
            # Skip garbled concept names — fragments with no vowels,
            # sentence fragments imported from scrapes, or names
            # that don't look like real concepts.
            if not self._is_valid_concept_name(base):
                continue
            # Skip concepts with no definition and no edges —
            # these are garbage from scrapes that should never
            # appear in speech.
            if not self._is_speakable_concept(concept_name):
                continue
            concept_words = set(base.lower().replace("_", " ").split())
            if topic_words & concept_words:
                # Lexical match — keep as fallback but don't prefer
                lexical_candidates.append(concept_name)
                continue
            candidates.append(concept_name)
            if len(candidates) >= 2:
                break

        # If no semantic matches found, fall back to lexical matches
        # rather than returning nothing. A lexical match like "water
        # cycle" is still more useful than no discovery at all.
        if not candidates and lexical_candidates:
            candidates = lexical_candidates[:2]

        if not candidates:
            return None

        # Compose the discovery sentence. Opener from graph or none.
        displays = [self._display_name(c) for c in candidates]
        if len(displays) == 1:
            target_text = displays[0]
        else:
            target_text = ", ".join(displays[:-1]) + " and " + displays[-1]

        opener = self._lexical_pick("latent_opener")
        if not opener:
            return None

        return f"{opener} {target_text}."

    def _compose_memory_sentence(
        self,
        memory_text: str,
        emotion: EmotionalState,
    ) -> str | None:
        """Weave a retrieved episodic memory into a natural sentence.

        The memory content is framed by a connective opener drawn from
        the utterance graph when available (``memory_connector`` slot),
        falling back to a small set of structural connectives. The
        opener is a building block — the memory content itself is what
        it expresses, not a pre-written template.
        """
        cleaned = memory_text.strip().rstrip(".")
        if not cleaned or len(cleaned) < 5:
            return None

        # A memory connective from the lexicon — no acquired
        # connective, no woven sentence.
        opener = self._lexical_pick("memory_connector")
        if not opener:
            return None
        return f"{opener} {cleaned}."

    @staticmethod
    def _filter_tautological_clauses(clauses: list[str], definition: str) -> list[str]:
        """Filter out clauses whose target appears in the definition.

        When a definition is used as the first sentence ("X is an alert
        cognitive state"), a relationship clause like "is alert cognitive
        state" repeats the same content. This filters clauses whose
        significant words overlap with the definition text.
        """
        # Normalize hyphenated compounds to separate tokens on both
        # sides — "warm-blooded animal" and "warm blooded animal" are
        # the same content, and the definition commonly hyphenates
        # where the edge target does not. Articles are excluded from
        # the target set: "the brain" vs "brain" is the same fact.
        _ARTICLES = {"a", "an", "the"}

        def _tokens(text: str) -> set[str]:
            """Normalize to content tokens: hyphens split, articles
            dropped, simple plurals stemmed so "living things" and
            "living thing" compare equal."""
            words = set(re.split(r"[\s\-]+", text.lower())) - _ARTICLES
            words |= {
                w[:-1] for w in words if len(w) > 2 and w.endswith("s") and not w.endswith("ss")
            }
            return words

        def_words = _tokens(definition)
        if not def_words:
            return clauses
        filtered: list[str] = []
        for clause in clauses:
            # Extract the target (last word(s) of the clause, after the verb)
            clause_words = clause.lower().split()
            # The target is typically the last 1-3 words
            target_words = _tokens(
                " ".join(clause_words[-3:]) if len(clause_words) >= 3 else clause
            )
            # If most target words appear in the definition, it's tautological
            if target_words and def_words:
                overlap = len(target_words & def_words) / len(target_words)
                if overlap > 0.5:
                    continue
            filtered.append(clause)
        return filtered

    def _separate_definition_and_facts(
        self,
        knowledge: list[tuple[str, str, float]],
        definition: str | None,
    ) -> tuple[str | None, list[tuple[str, str, float]]]:
        """Separate the definition from relationship facts in the knowledge list.

        Returns (definition, rel_facts).
        """
        rel_facts: list[tuple[str, str, float]] = []
        for rel, target, weight in knowledge:
            if rel == "is defined as":
                if not definition:
                    definition = target
            else:
                rel_facts.append((rel, target, weight))
        return definition, rel_facts

    def _build_rel_clauses(
        self, rel_facts: list[tuple[str, str, float]]
    ) -> tuple[list[str], set[str], set[str]]:
        """Build predicate clauses from relationship facts.

        Each fact becomes a predicate clause: "{verb} {target}".
        Multiple clauses are joined with connectors that vary
        with emotional state.

        Filters out tautological, meaningless, and repetitive edges.
        Limits ``related_to`` to at most 1 clause to prevent synonym spam.

        Returns (clauses, seen_clauses, seen_targets).
        """
        clauses: list[str] = []
        seen_clauses: set[str] = set()
        seen_targets: set[str] = set()
        related_to_count = 0

        for rel, target, _weight in rel_facts[:6]:
            if self._is_noisy_target(target):
                continue
            # Skip tautological targets (target is a relation verb or
            # generic category word)
            if self._is_meaningless_fact_target(target, rel):
                continue
            target_display = self._display_name(target)
            if target_display.lower() in seen_targets:
                continue
            # Limit related_to to 1 per thought
            rel_key_check = rel.strip().replace(" ", "_")
            if rel_key_check.startswith("is_"):
                rel_key_check = rel_key_check[3:]
            if rel_key_check == "related_to":
                if related_to_count >= 1:
                    continue
                related_to_count += 1
            seen_targets.add(target_display.lower())

            # Normalize relation to verb-map key (spaces or leading "is ")
            rel_key = rel.strip().replace(" ", "_")
            if rel_key.startswith("is_") and rel_key[3:] in self._RELATION_VERBS:
                rel_key = rel_key[3:]
            # Try graph-based verb lookup first
            verbs: list[str] | None = None
            if self._network is not None:
                rt_match = None
                for rt in RelationType:
                    if rt.value == rel_key:
                        rt_match = rt
                        break
                if rt_match is not None:
                    graph_verbs = self._network.find_relation_verbs(rt_match)
                    if graph_verbs:
                        verbs = graph_verbs
            if verbs is None:
                verbs = self._RELATION_VERBS.get(rel_key)
            if rel_key == "has_property":
                # The object's form decides the frame — "is clear" for
                # bare property words, "has fur" for noun objects.
                # Learned verbs are kept only when their complement
                # license fits.
                verb = self._rng.choice(property_verb_candidates(target_display, verbs or []))
            elif verbs is None:
                # Unknown relation — use it as-is, cleaned up
                verb = rel.replace("_", " ")
            else:
                verb = self._rng.choice(verbs)
            # Store as predicate (without subject) so we can use display
            # or a pronoun later
            # Add an article to the target if appropriate — "need brain"
            # should be "need the brain", but "depends on memory" should
            # stay as-is (memory is a mass noun). A bare copula takes an
            # adjectival complement, never an article — "is the clear"
            # is not English.
            if verb.lower() in ("is", "are", "am"):
                target_with_article = target_display
            else:
                target_with_article = self._with_article(verb, target_display)
            clause = f"{verb} {target_with_article}"
            clause_key = clause.lower()
            # Skip duplicate predicates (same relation + target)
            if clause_key in seen_clauses:
                continue
            seen_clauses.add(clause_key)
            clauses.append(clause)
            # Limit to 3 clauses for concise output
            if len(clauses) >= 3:
                break

        return clauses, seen_clauses, seen_targets

    @staticmethod
    def _is_meaningless_fact_target(target: str, rel: str) -> bool:
        """Return True if a target is too vague or tautological to express.

        Filters out relation verbs used as concepts and function words
        that produce nonsense when composed into speech.
        """
        if not target:
            return True
        targ_lower = target.lower().split("#")[0].strip()
        # Single-character targets are never meaningful
        if len(targ_lower) <= 1:
            return True
        rel_key = rel.replace(" ", "_")
        # Target is the relation verb itself
        if targ_lower == rel_key or targ_lower.replace(" ", "_") == rel_key:
            return True
        # Relation verb phrases as targets
        if targ_lower in {
            "related to",
            "connects to",
            "has to do with",
            "part of",
            "is a",
            "is an",
            "is the",
            "similar to",
            "opposite of",
            "related",
            "relates",
            "connects",
            "connected",
            "similar",
            "opposite",
            "instance",
        }:
            return True
        # Pure function words
        if targ_lower in {
            "is",
            "are",
            "was",
            "were",
            "be",
            "been",
            "yes",
            "no",
            "true",
            "false",
            "thing",
            "something",
            "anything",
            "everything",
        }:
            return True
        return False

    def _add_reasoning_clauses(
        self,
        reasoning: list[str],
        display: str,
        seen_clauses: set[str],
        seen_targets: set[str],
        clauses: list[str],
    ) -> None:
        """Add reasoning conclusions as predicate clauses (modifies clauses in-place)."""

        def _target_from_clause(clause: str) -> str | None:
            """Extract the likely target (last word) from a predicate clause."""
            # Clauses are "verb target" (e.g. "relates to python");
            # the target is usually the last word
            parts = clause.split()
            if parts:
                return parts[-1]
            return None

        # ── Add reasoning conclusions ──
        for r in reasoning[:2]:
            # Strip all parenthetical asides (transitive chains,
            # connection explanations, etc.) before further processing.
            cleaned = re.sub(r"\s*\([^)]*\)", "", r)
            # Reasoning conclusions look like "cognitive part_of mind";
            # drop the subject and keep just the predicate
            cleaned = cleaned.replace("_", " ")
            cleaned = cleaned.lower().rstrip(".")
            if cleaned.startswith(display.lower() + " "):
                cleaned = cleaned[len(display) + 1 :]
            cleaned = cleaned.strip()
            # Reasoning sometimes prefixes conclusions with "might" or
            # "might be", e.g. "might related to x" or "might be part of y".
            # Turn these into plain predicates.
            if cleaned.startswith("might be "):
                cleaned = cleaned[9:]
            elif cleaned.startswith("might "):
                cleaned = cleaned[6:]
            # Convert the raw relation into a proper verb clause.
            # E.g. "part of subcognitive" -> "is part of subcognitive".
            cleaned = self._make_reasoning_clause(cleaned)
            if not cleaned:
                continue
            # Normalize the target inside the reasoning clause the same way
            # as relationship targets (strip #N, lowercase, etc.).
            raw_target = _target_from_clause(cleaned)
            if raw_target:
                target_display = self._display_name(raw_target)
                # Replace the raw target with the display form.
                # The target is the last word(s) of the clause.
                verb_part = cleaned[: len(cleaned) - len(raw_target)]
                target_with_article = self._with_article(verb_part, target_display)
                cleaned = verb_part + target_with_article

            # Skip duplicates and anything that just repeats a relation
            # we already know (e.g. direct edge already said "is part of mind").
            if cleaned not in seen_clauses:
                # Also skip if the meaning is already covered by an existing
                # clause (e.g. "is part of mind" covers "part of mind").
                covered = any(
                    cleaned in existing or existing in cleaned for existing in seen_clauses
                )
                reason_target = _target_from_clause(cleaned)
                target_known = reason_target and reason_target.lower() in seen_targets
                if not covered and (reason_target is None or not target_known):
                    seen_clauses.add(cleaned)
                    if reason_target:
                        seen_targets.add(reason_target.lower())
                    clauses.append(cleaned)

    def _clean_definition(self, definition: str | None) -> str | None:
        """Clean and truncate a definition for use in a sentence.

        Corrupted definitions sometimes contain concatenated
        relationship facts like "X is related to Y". Skip those.
        """
        # Definition — if it has one, use it as the first sentence
        # Corrupted definitions sometimes contain concatenated
        # relationship facts like "X is related to Y". Skip those.
        defn: str | None = None
        if definition and not any(
            marker in definition
            for marker in (
                " is related to",
                " part of",
                " emerges from",
                " depends on",
            )
        ):
            defn = definition.rstrip(".")
            # Definitions can contain multiple clauses or malformed
            # concatenated text; prefer semicolon boundaries first,
            # then sentence boundaries.
            if ";" in defn:
                defn = defn.split(";")[0].strip()
            elif "." in defn:
                candidates = [s.strip() for s in defn.split(".") if 20 < len(s.strip()) <= 120]
                if candidates:
                    defn = candidates[0]
            # Keep definitions concise
            if len(defn) > 120:
                defn = defn[:120].rsplit(" ", 1)[0]
            defn = defn.lower()
        return defn

    def _compose_rel_sentence(
        self,
        clauses: list[str],
        display: str,
        emotion: EmotionalState,
        concept_id: str = "",
    ) -> str | None:
        """Compose the relationship clauses into a sentence using a pronoun."""
        # Relationship clauses — form a second sentence using a pronoun
        if not clauses:
            return None
        # Animacy-aware pronoun: the concept's category and gender
        # property pick it/he/they/it rather than assuming "it" for
        # everything that isn't Genesis.
        if display.lower() in ("i", "me", "myself"):
            pronoun, plural = "I", False
        else:
            pron, plural = person_pronoun(concept_id or display, self._network, display)
            pronoun = pron.capitalize()
        # Fix verb agreement for plural pronoun
        if plural:
            clauses = [agree_verb_phrase(c, True) for c in clauses]
        if len(clauses) == 1:
            return f"{pronoun} {clauses[0]}."
        elif len(clauses) == 2:
            connector = self._pick_clause_connector(emotion)
            if connector == "—":
                # Em-dash: use surrounding spaces for readability in
                # generated text (em-dash without spaces is a
                # typographic convention for print, but it makes
                # spoken-text output look like "sleep—needs" which
                # reads as a broken word).
                return f"{pronoun} {clauses[0]} — {clauses[1]}."
            return f"{pronoun} {clauses[0]} {connector} {clauses[1]}."
        else:
            connector = self._pick_clause_connector(emotion)
            joined = ", ".join(clauses[:-1])
            if connector == "—":
                return f"{pronoun} {joined} — {clauses[-1]}."
            return f"{pronoun} {joined}, {connector} {clauses[-1]}."

    def _compose_closing(self, confidence: float, emotion: EmotionalState) -> str | None:
        """Compose a confidence-based closing qualification.

        No hardcoded closing phrases — if the lexicon has no closing
        content, return None and let the sentence end naturally.
        """
        if confidence >= 0.6:
            return None
        return self._lexical_pick("closing") or None

    def _make_reasoning_clause(self, raw: str) -> str:
        """Convert a raw reasoning conclusion into a proper predicate clause.

        Reasoning conclusions are like "part of mind" or "related to python";
        we need a clause that can follow a pronoun like "It".
        """
        raw = raw.strip()
        if not raw:
            return ""
        # Try to find a known relation at the start of the raw string.
        # Also handle adverb-prefixed relations: "directly depends on X"
        # should match "depends_on" and produce "directly needs X", not
        # "is directly depends on X" (from the fallback "is" prefix).
        for rel in sorted(self._RELATION_VERBS, key=len, reverse=True):
            rel_spaced = rel.replace("_", " ")
            if raw.startswith(rel_spaced + " "):
                target = raw[len(rel_spaced) + 1 :].strip()
                verbs = self._RELATION_VERBS[rel]
                if verbs:
                    verb = self._rng.choice(verbs)
                else:
                    verb = rel_spaced
                return f"{verb} {target}"
            if raw.startswith(rel + " "):
                target = raw[len(rel) + 1 :].strip().replace("_", " ")
                verbs = self._RELATION_VERBS[rel]
                if verbs:
                    verb = self._rng.choice(verbs)
                else:
                    verb = rel_spaced
                return f"{verb} {target}"
        # Also try matching base verb forms (without trailing 's').
        # Reasoning conclusions use "might enable" (base form), but
        # the relation key is "enables" (third-person). Match both.
        for rel in sorted(self._RELATION_VERBS, key=len, reverse=True):
            rel_spaced = rel.replace("_", " ")
            # Strip trailing 's' from the first word to get the base form
            base_words = rel_spaced.split()
            if base_words and base_words[0].endswith("s") and not base_words[0].endswith("ss"):
                base_words[0] = base_words[0][:-1]
                base_spaced = " ".join(base_words)
                if raw.startswith(base_spaced + " "):
                    target = raw[len(base_spaced) + 1 :].strip()
                    verbs = self._RELATION_VERBS[rel]
                    if verbs:
                        verb = self._rng.choice(verbs)
                    else:
                        verb = rel_spaced
                    return f"{verb} {target}"
        # Check for adverb-prefixed relations: "directly depends on X",
        # "also relates to Y". Strip the leading adverb, try to match,
        # then re-attach it.
        clause = self._adverb_relation_clause(raw)
        if clause is not None:
            return clause
        # Unknown relation — prepend "is" only if it looks like a
        # predicate that needs a copula (noun phrase, adjective).
        # Don't prepend "is" if the clause already starts with a verb
        # (detected by checking against common verb stems).
        if " " in raw and not raw.startswith(("is ", "has ", "can ", "does ", "might ")):
            first_word = raw.split(None, 1)[0].lower()
            # Common verbs that don't need "is" prefix
            if first_word in ("might", "may", "could"):
                return raw
            if first_word.endswith("s") and len(first_word) > 3:
                # "depends", "relates", "connects", "enables", etc. —
                # these are already verbs, don't prepend "is"
                return raw
            if first_word in (
                "depends",
                "relates",
                "connects",
                "enables",
                "causes",
                "creates",
                "produces",
                "contains",
                "includes",
                "requires",
                "needs",
                "harms",
                "prevents",
                "blocks",
                "stops",
            ):
                return raw
            return f"is {raw}"
        return raw

    def _adverb_relation_clause(self, raw: str) -> str | None:
        """Match an adverb-prefixed relation ("directly depends on X",
        "also relates to Y"), re-attaching the adverb to the chosen verb."""
        words = raw.split(None, 1)
        if len(words) != 2:
            return None
        first_word = words[0].lower()
        # Common adverb modifiers in reasoning conclusions
        if first_word not in (
            "directly",
            "also",
            "strongly",
            "closely",
            "largely",
            "partly",
            "mostly",
            "perhaps",
            "possibly",
            "clearly",
            "ultimately",
            "therefore",
            "thus",
            "hence",
            "consequently",
            "eventually",
            "necessarily",
            "probably",
            "certainly",
            "indeed",
            "notably",
            "significantly",
            "essentially",
        ):
            return None
        remainder = words[1]
        for rel in sorted(self._RELATION_VERBS, key=len, reverse=True):
            rel_spaced = rel.replace("_", " ")
            if remainder.startswith(rel_spaced + " "):
                target = remainder[len(rel_spaced) + 1 :].strip()
                verbs = self._RELATION_VERBS[rel]
                verb = self._rng.choice(verbs) if verbs else rel_spaced
                return f"{first_word} {verb} {target}"
        # Also try base verb forms (without trailing 's')
        for rel in sorted(self._RELATION_VERBS, key=len, reverse=True):
            rel_spaced = rel.replace("_", " ")
            base_words = rel_spaced.split()
            if base_words and base_words[0].endswith("s") and not base_words[0].endswith("ss"):
                base_words[0] = base_words[0][:-1]
                base_spaced = " ".join(base_words)
                if remainder.startswith(base_spaced + " "):
                    target = remainder[len(base_spaced) + 1 :].strip()
                    verbs = self._RELATION_VERBS[rel]
                    verb = self._rng.choice(verbs) if verbs else rel_spaced
                    return f"{first_word} {verb} {target}"
        return None

    def _pick_clause_connector(self, emotion: EmotionalState) -> str:
        """Pick a connector for joining knowledge clauses, modulated by emotion."""
        if emotion.creativity > 0.6:
            return self._rng.choice(["and", "and", "—"])
        elif emotion.caution > 0.5:
            return self._rng.choice(["and", "though also"])
        else:
            return "and"

    def _display_name(self, concept_id: str) -> str:
        """Convert a concept ID to a human-readable display name."""
        if not concept_id:
            return ""
        # Strip disambiguation suffixes (e.g., "mind#2" → "mind")
        name = concept_id.split("#")[0]
        # Strip code concept prefixes (e.g., "python:FrontalLobe" → "FrontalLobe")
        if ":" in name and not name.startswith("http"):
            name = name.split(":", 1)[1]
        # Take the last component of module paths
        if "." in name:
            name = name.split(".")[-1]
        # Convert underscores to spaces
        name = name.replace("_", " ")
        # Lowercase for natural speech (voice capitalizes first word)
        name = name.lower()
        return name

    @staticmethod
    def _is_valid_concept_name(base: str) -> bool:
        """Check if a concept name looks like a real concept.

        Filters out garbled names imported from scrapes — sentence
        fragments, fragments with no vowels, or names that don't
        look like real concepts. This prevents Genesis from saying
        things like "It is a kind of lso said."
        """
        if not base or len(base) <= 1:
            return False
        words = base.split()
        # Reject sentence fragments (4+ words with no capitalization
        # — these are usually imported text, not concept names)
        if len(words) > 4:
            return False
        # Reject names with no vowels (acronyms are fine if short,
        # but 3+ chars with no vowels are usually garbled)
        if len(base) >= 3 and not any(c in "aeiouAEIOU" for c in base):
            return False
        # Reject possessive fragments ("unesco's memory", "phone's memory")
        if any("'" in w for w in words):
            return False
        # Reject multiword names built entirely from function words —
        # "those words", "words often", "the thing it" are scrape
        # fragments, not concepts.
        if len(words) >= 2 and all(w.lower() in _FRAGMENT_NAME_WORDS for w in words):
            return False
        # Reject names that look like sentence fragments starting
        # with lowercase words (real concepts are usually nouns)
        if len(words) >= 3 and all(w[0].islower() for w in words):
            # Allow if it's a known compound pattern like "alert cognitive state"
            # (all lowercase but short and noun-like)
            if len(words) > 3:
                return False
        return True

    def _is_speakable_concept(self, concept_id: str) -> bool:
        """Check if a concept is speakable — has real content.

        A concept is speakable if it has a definition OR has outgoing
        edges in the graph. Concepts with no definition and no
        outgoing edges are garbage from scrapes — they may have
        incoming edges (other concepts point to them), but they
        themselves have no content.
        """
        if self._network is None:
            return True
        c = self._network.get_concept(concept_id)
        if c is None:
            return False
        # Has a real definition (not "NO DEF")
        defn = c.properties.get("definition", "NO DEF")
        if defn and defn != "NO DEF":
            return True
        # Has outgoing edges in the graph
        if len(self._network.get_edges(concept_id, "out")) > 0:
            return True
        # No definition and no outgoing edges — garbage
        return False

    # ─── Article insertion ───────────────────────────────────────
    # Common mass nouns in English — these don't take articles in
    # general statements ("memory is...", "sleep causes...").
    _MASS_NOUNS: ClassVar[set[str]] = {
        # Substances/materials
        "water",
        "air",
        "fire",
        "light",
        "heat",
        "ice",
        "steam",
        "iron",
        "gold",
        "silver",
        "copper",
        "hydrogen",
        "oxygen",
        "carbon",
        "nitrogen",
        "salt",
        "sugar",
        "oil",
        "glass",
        "wood",
        "stone",
        "metal",
        "plastic",
        "rubber",
        # Abstract concepts
        "memory",
        "cognition",
        "awareness",
        "thought",
        "thinking",
        "perception",
        "attention",
        "intention",
        "will",
        "meaning",
        "truth",
        "beauty",
        "love",
        "hate",
        "fear",
        "joy",
        "happiness",
        "sadness",
        "anger",
        "emotion",
        "feeling",
        "intelligence",
        "creativity",
        "imagination",
        "reason",
        "logic",
        "knowledge",
        "wisdom",
        "understanding",
        "insight",
        "time",
        "space",
        "energy",
        "power",
        "force",
        "gravity",
        "information",
        "data",
        "language",
        "music",
        "art",
        "science",
        "philosophy",
        "mathematics",
        "history",
        "literature",
        "sleep",
        "dreaming",
        "learning",
        "processing",
        "life",
        "death",
        "health",
        "growth",
        "change",
        "motion",
        "liquid",
        "solid",
        "gas",
        "plasma",
        "matter",
        "substance",
        "nature",
        "reality",
        "existence",
        "being",
        "nothing",
        "freedom",
        "justice",
        "peace",
        "war",
        "chaos",
        "order",
        "complexity",
        "simplicity",
        "unity",
        "diversity",
    }

    # Common count nouns that end in a mass-noun suffix — without these
    # exceptions the heuristics below drop their articles ("enables
    # city", "depends on identity" instead of "the city", "the identity").
    _COUNT_NOUN_EXCEPTIONS: ClassVar[set[str]] = {
        # -ing count nouns
        "thing",
        "ring",
        "king",
        "wing",
        "string",
        "spring",
        "swing",
        "sting",
        "sling",
        "ceiling",
        "morning",
        "evening",
        "building",
        "meeting",
        "warning",
        "gathering",
        "opening",
        "offering",
        "painting",
        "drawing",
        "writing",
        "reading",
        "recording",
        "crossing",
        "hearing",
        "wedding",
        "blessing",
        "teaching",
        "finding",
        "beginning",
        "ending",
        "setting",
        "lightning",
        "earring",
        "darling",
        # -ity count nouns
        "city",
        "pity",
        "entity",
        "identity",
        "quality",
        "quantity",
        "activity",
        "community",
        "university",
        "opportunity",
        "ability",
        "capacity",
        "authority",
        "majority",
        "minority",
        "curiosity",
        "intensity",
        "density",
        "personality",
        "facility",
        "utility",
        "security",
        "property",
        "priority",
        "novelty",
        "charity",
        "vanity",
        "dignity",
        "locality",
        "modality",
        "polarity",
        "regularity",
        "rarity",
        "familiarity",
        "formality",
        "oddity",
        "fatality",
        "totality",
        "vitality",
        "sexuality",
        "maturity",
    }

    @classmethod
    def _is_mass_noun(cls, noun: str) -> bool:
        """Check if a noun is a mass (uncountable) noun."""
        n = noun.lower().strip()
        if n in cls._MASS_NOUNS:
            return True
        # Common count nouns that happen to end in a mass-noun suffix
        if n in cls._COUNT_NOUN_EXCEPTIONS:
            return False
        # The head noun (last word) decides the phrase's class —
        # "deep sleep" is mass because "sleep" is; "living thing" is
        # count because "thing" is. Suffix heuristics and the mass-noun
        # list apply to the head, not the phrase's last characters.
        head = n.split()[-1] if n.split() else n
        if head in cls._COUNT_NOUN_EXCEPTIONS:
            return False
        if head in cls._MASS_NOUNS:
            return True
        if head.endswith("ness"):  # cognition, awareness, happiness
            return True
        if head.endswith("ing"):  # learning, thinking, processing
            return True
        if head.endswith("ity"):  # complexity, simplicity, unity
            return True
        return False

    # Proper nouns that should never take an article
    _PROPER_NOUNS: ClassVar[set[str]] = {
        "genesis",
        "alice",
        "bob",
        "carol",
        "earth",
        "mars",
        "venus",
        "jupiter",
        "saturn",
        "america",
        "europe",
        "asia",
        "africa",
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday",
        "sunday",
        "january",
        "february",
        "march",
        "april",
        "june",
        "july",
        "august",
        "september",
        "october",
        "november",
        "december",
    }

    @classmethod
    def _with_article(cls, verb_phrase: str, target: str) -> str:
        """Add an article to a target noun if appropriate.

        Returns the target with "the" prepended when:
        - The target is a singular count noun (not mass, not plural,
          not proper)
        - The verb phrase doesn't already contain an article

        Returns the target unchanged when:
        - The verb phrase already has "a", "an", or "the"
        - The target is a mass noun
        - The target is plural (ends in 's' but not 'ss')
        - The target is a proper noun (in _PROPER_NOUNS or
          capitalized in the concept network)
        """
        if not target:
            return target
        # Check if the verb phrase already contains an article
        vp_lower = verb_phrase.lower()
        if " a " in vp_lower or " an " in vp_lower or " the " in vp_lower:
            return target
        if vp_lower.startswith(("a ", "an ", "the ")):
            return target
        # Don't add article to multi-word targets (likely already
        # qualified: "rapid eye movement", "theory of mind")
        if len(target.split()) > 2:
            return target
        target_lower = target.lower().strip()
        # Don't add article to proper nouns (Genesis, Alice, etc.)
        if target_lower in cls._PROPER_NOUNS:
            return target
        # Don't add article to mass nouns
        if cls._is_mass_noun(target_lower):
            return target
        # Don't add article to plural noun phrases — "dreams",
        # "salt and pepper" (shared plural detection lives in
        # morphology.is_plural_np)
        if is_plural_np(target):
            return target
        # Don't add article if target already starts with an article
        if target_lower.startswith(("the ", "a ", "an ")):
            return target
        # Add "the" for definite reference
        return f"the {target}"

    def _is_noisy_target(self, target: str) -> bool:
        """Return True if a target concept is too code/noisy for speech."""
        if not target:
            return True
        if target.startswith(("python:", "rust:", "code:")):
            return True
        if "." in target or ":" in target:
            return True
        if target.startswith("_") or "__" in target:
            return True
        if "self." in target or "cls." in target:
            return True
        # Single-letter targets are never meaningful concepts
        if len(target) == 1:
            return True
        if re.match(r"^(?:to|the|a|an)\s", target):
            return True
        base = target.split("#")[0].lower()
        if base in ("python", "rust", "code", "class"):
            return True
        if "_" in target and len(target) > 20:
            return True
        if re.match(r"^[A-Z][a-z]+([A-Z][a-z]+)+$", target):
            return True
        # Reject garbled concept names — no vowels in 3+ char names
        # (catches "lso said", "dgn", "ngstr", etc.)
        if len(base) >= 3 and not any(c in "aeiou" for c in base):
            return True
        # Reject sentence fragments (4+ words) imported from scrapes
        if len(base.split()) > 4:
            return True
        # Reject possessive fragments ("unesco's memory", "phone's memory")
        if any("'" in w for w in base.split()):
            return True
        # Reject concepts with no definition and no edges — garbage
        # from scrapes that should never appear in speech
        if not self._is_speakable_concept(target):
            return True
        return False

    # ─── Compositional interrogative assembly ───────────────────
    #
    # A question is assembled from grammatical components, not
    # stored sentence frames:
    #
    #   wh-word + [aux + subject + verb-phrase] + complement
    #
    # The wh-word marks the questioned constituent (the gap).
    # Do-support and verb agreement come from morphology; content
    # words come from the concept network — neighbors, IS_A parents,
    # definitions, learned relation verbs. Nothing here is a
    # response Genesis "says" — these are the syntactic combinators
    # the question types use to express a knowledge gap.

    def _aux_for(self, subject: str) -> str:
        """Do-support auxiliary agreeing with the subject."""
        s = subject.strip().lower()
        if s in ("i", "you", "we", "they", "both", "all") or is_plural_np(s):
            return "do"
        return "does"

    @staticmethod
    def _deconjugate_head(first: str) -> str:
        """Return the base form of a verb phrase's head word.

        Verb phrases arrive in mixed forms: learned relation verbs are
        stored inflected for 3sg ("causes", "leads to") while composer
        fallbacks are base form ("produce", "cause"). Lexicon lookup
        resolves irregulars and learned verbs; for ordinary inflected
        words not in a lexicon (``_VERB_BASES`` is empty by design —
        knowledge is learned), fall back to morphological stripping so
        "causes" → "cause" rather than passing through unchanged.
        """
        base = is_verb_form(first)
        if base is not None:
            return base
        f = first.lower().rstrip(",.!?;:")
        # 3sg inflection rules, mirroring deconjugate_verb. "ies" → "y"
        # ("tries" → "try"), but a one-letter stem means the base ends
        # in -ie ("lies" → "lie", not "ly"). Sibilant endings strip
        # "es" ("watches" → "watch"); other -es words strip just "s"
        # ("analyzes" → "analyze", "causes" → "cause"). Bases ending in
        # -us/-is are mostly nouns, and their 3sg is -uses/-ises, so a
        # bare -s after u/i is not an inflection ("focus" stays).
        if f.endswith("ies") and len(f) > 3:
            stem = f[:-3]
            return stem + "y" if len(stem) > 1 else f[:-1]
        if f.endswith("oes"):
            # -o verbs take -es only in a closed class ("goes",
            # "echoes" → "go", "echo"); -oe verbs take -s
            # ("shoes" → "shoe", not "sho").
            if f[:-2] in _ES_VERBS:
                return f[:-2]
            return f[:-1]
        if f.endswith(("shes", "ches", "sses", "xes")):
            return f[:-2]
        if f.endswith("s") and not f.endswith(("ss", "us", "is")):
            return f[:-1]
        return first

    @classmethod
    def _base_form(cls, verb_phrase: str) -> str:
        """Deconjugate the first word of a verb phrase to base form.

        "gives rise to" → "give rise to" — for do-support questions
        where the main verb is uninflected.
        """
        first, *rest = verb_phrase.split()
        return " ".join([cls._deconjugate_head(first), *rest])

    @classmethod
    def _third_sg(cls, verb_phrase: str) -> str:
        """Conjugate the first word of a verb phrase to 3sg.

        "give rise to" → "gives rise to" — for wh-subject questions
        ("what gives rise to X") where the gap is nominative. The head
        is deconjugated first so an already-inflected seed verb
        ("causes") doesn't become "causeses".
        """
        first, *rest = verb_phrase.split()
        return " ".join([conjugate_verb(cls._deconjugate_head(first)), *rest])

    def _wh_question(
        self,
        wh: str,
        subject: str = "",
        verb: str = "",
        complement: str = "",
        aux: str = "",
    ) -> str:
        """Assemble a wh-question from components.

        - No subject → the wh-word fills the subject gap and the
          verb takes 3sg: "what causes rain".
        - With subject → aux + subject + base verb: "what does
          sleep affect", "how do you feel about X".
        - ``aux`` overrides do-support ("what am I missing",
          "what should I know").
        """
        parts = [wh]
        if subject:
            parts.append(aux or self._aux_for(subject))
            parts.append(subject)
            if verb:
                parts.append(self._base_form(verb))
        elif verb:
            parts.append(self._third_sg(verb))
        if complement:
            parts.append(complement)
        return " ".join(parts) + "?"

    def _wh_copula(
        self,
        wh: str,
        subject: str,
        complement: str = "",
        prenominal: bool = False,
    ) -> str:
        """Assemble a copular wh-question.

        - ``prenominal=False``: "what is water" — wh + copula + NP.
        - ``prenominal=True``: "which side is true" — the wh-word
          is a determiner on the subject NP.
        """
        cop = copula(subject)
        if prenominal:
            parts = [wh, subject, cop]
        else:
            parts = [wh, cop, subject]
        if complement:
            parts.append(complement)
        return " ".join(parts) + "?"

    def _yn_question(
        self,
        subject: str,
        verb: str,
        complement: str = "",
        aux: str = "",
    ) -> str:
        """Assemble a yes/no question: aux + subject + base verb."""
        parts = [aux or self._aux_for(subject), subject]
        if verb:
            parts.append(self._base_form(verb))
        if complement:
            parts.append(complement)
        return " ".join(parts) + "?"

    def _statement(self, subject: str, verb: str, complement: str = "") -> str:
        """Assemble a declarative clause with subject agreement."""
        s = subject.strip().lower()
        plural = s in ("i", "you", "we", "they", "both", "all") or is_plural_np(s)
        parts = [subject, conjugate_verb(verb, plural=plural)]
        if complement:
            parts.append(complement)
        return " ".join(parts)

    def _copula_statement(self, subject: str, complement: str) -> str:
        """Assemble a copular declarative: "X is Y"."""
        return f"{subject} {copula(subject)} {complement}"

    @staticmethod
    def _cap_first(text: str) -> str:
        """Capitalize the first letter without lowercasing the rest
        (unlike str.capitalize, which would turn 'I' into 'i')."""
        return text[0].upper() + text[1:] if text else text

    def _relation_verb_for(self, rel: RelationType, fallback: str) -> str:
        """Pick a relation verb phrase — learned from the concept
        network when available, else the seed fallback."""
        if self._network is not None:
            try:
                learned = self._network.find_relation_verbs(rel)
                if learned:
                    return self._rng.choice(learned)
            except Exception as e:  # noqa: BLE001
                note_swallowed(
                    "language.vocabulary._relation_verb_for",
                    e,
                )
        return fallback

    def _compose_question_content(
        self, context: dict[str, Any], emotion: EmotionalState
    ) -> list[str]:
        """Compose question content from its actual knowledge state.

        No stored sentence frames — each question type names a
        knowledge gap, and the gap is expressed by assembling
        wh-word + auxiliary + subject + verb phrase + complement
        around content drawn from the concept network (neighbors,
        IS_A parents, definitions, relation verbs).

        Context keys:
        - "question_type": "isolation", "uncertainty", "causation",
          "hypothesis", "contradiction", "connection", "perspective",
          "social_emotional", "social_interest", "social_belief",
          "social_general"
        - "target_concept": the concept it's asking about
        - "gap_detail": extra info about the gap
        """
        qtype = context.get("question_type", "")
        target = context.get("target_concept", "")
        detail = context.get("gap_detail", "")

        net = self._network
        subject = (target or "this").replace("_", " ")
        # Animacy-aware pronouns for referring back to the target
        pron_subj, _ = person_pronoun(target, net, subject, for_object=False)
        pron_obj, _ = person_pronoun(target, net, subject, for_object=True)

        handlers = {
            "isolation": self._q_isolation,
            "uncertainty": self._q_uncertainty,
            "causation": self._q_causation,
            "hypothesis": self._q_hypothesis,
            "contradiction": self._q_contradiction,
            "connection": self._q_connection,
            "cooccurrence": self._q_cooccurrence,
            "perspective": self._q_perspective,
            "social_emotional": self._q_social_emotional,
            "social_interest": self._q_social_interest,
            "social_belief": self._q_social_belief,
            "social_general": self._q_social_general,
            "reciprocal": self._q_reciprocal,
        }
        handler = handlers.get(qtype)
        if handler is not None:
            return handler(net, target, subject, detail, pron_subj, pron_obj)

        # Fallback — compose from available data
        if target and detail:
            if target.lower() in detail.lower():
                return [str(detail)]
            return [f"{detail} about {target}"]
        if target:
            return [self._wh_question("what", complement=f"about {subject}")]
        if detail:
            return [str(detail)]
        # Ad-hoc asks carry no structured gap — use the thought's own
        # content when it is already a question, or wrap a short topic
        # phrase in a wh-frame. Without this the slot renders empty and
        # the utterance collapses to a bare "?" or the raw statement
        # with its question mark stripped.
        content = str(context.get("content", "")).strip()
        if content:
            lowered = content.lower()
            if "?" in content or lowered.startswith(
                (
                    "what",
                    "who",
                    "whom",
                    "whose",
                    "when",
                    "where",
                    "why",
                    "how",
                    "which",
                    "is ",
                    "are ",
                    "was ",
                    "were ",
                    "do ",
                    "does ",
                    "did ",
                    "can ",
                    "could ",
                    "will ",
                    "would ",
                    "should ",
                    "may ",
                    "might ",
                    "must ",
                )
            ):
                return [content]
            if len(content.split()) <= 4:
                return [self._wh_question("what", complement=f"about {content}")]
        topics = context.get("topics") or []
        if topics:
            topic_subject = str(topics[0]).replace("_", " ")
            return [self._wh_question("what", complement=f"about {topic_subject}")]
        return []

    # ─── Question-type composers ────────────────────────────────────
    # Each takes (net, target, subject, detail, pron_subj, pron_obj)
    # and returns a list of one composed question, or falls back.

    def _q_isolation(self, net, target, subject, detail, pron_subj, pron_obj):
        # Concept has few connections — ask what else connects
        if net and target:
            neighbors = net.get_exact_neighbors(target)[:2]
            if neighbors:
                known = ", ".join(n[0].replace("_", " ") for n in neighbors)
                rel_verb = agree_verb_phrase(
                    self._relation_verb_for(RelationType.RELATED_TO, "connects to"),
                    is_plural_np(subject),
                )
                lead = self._statement("I", "know", f"{subject} {rel_verb} {known}")
                ask = self._wh_question(
                    "what else",
                    subject="I",
                    aux="should",
                    verb="know",
                    complement=f"about {pron_obj}",
                )
                return [f"{lead}, but {ask}"]
        return [
            self._wh_question(
                "what else",
                subject="I",
                aux="should",
                verb="know",
                complement=f"about {subject}",
            )
        ]

    def _q_uncertainty(self, net, target, subject, detail, pron_subj, pron_obj):
        # Low confidence — ask for clarification
        if net and target:
            concept = net.get_concept(target)
            if concept:
                defn = concept.properties.get("definition", "")
                if defn and defn != "NO DEF":
                    snippet = defn[:50]
                    lead = self._copula_statement(
                        f"my understanding of {subject}",
                        f"incomplete — {snippet}",
                    )
                    ask = self._wh_question("what", subject="I", aux="am", verb="missing")
                    return [f"{lead}. {self._cap_first(ask)}"]
        return [self._wh_copula("what exactly", subject)]

    def _q_causation(self, net, target, subject, detail, pron_subj, pron_obj):
        # Has IS_A but no CAUSES — ask what produces it
        cause_verb = self._relation_verb_for(RelationType.CAUSES, "produce")
        if net and target:
            edges = net.get_edges(target, "out")
            is_a = [e.target for e in edges if e.relation.value == "is_a"]
            if is_a:
                parent = is_a[0].replace("_", " ")
                is_a_verb = agree_verb_phrase("is a kind of", is_plural_np(subject))
                lead = self._statement("I", "know", f"{subject} {is_a_verb} {parent}")
                ask = self._wh_question("what", verb=cause_verb, complement=pron_obj)
                return [f"{lead}, but {ask}"]
        return [self._wh_question("what", verb=cause_verb, complement=subject)]

    def _q_hypothesis(self, net, target, subject, detail, pron_subj, pron_obj):
        # From reasoning — ask if the hypothesis holds
        if detail:
            d = detail.replace("_", " ")
            lead = self._statement("my reasoning", "suggest", d)
            ask = self._yn_question("that", "hold", complement="up")
            return [f"{lead}. {self._cap_first(ask)}"]
        hyp = f"{indefinite_article('hypothesis')} hypothesis"
        lead = self._statement("I", "have", f"{hyp} about {subject}")
        ask = self._yn_question(pron_subj, "hold", complement="up")
        return [f"{lead}. {self._cap_first(ask)}"]

    def _q_contradiction(self, net, target, subject, detail, pron_subj, pron_obj):
        # Conflicting beliefs — ask which is true
        if detail:
            d = detail.replace("_", " ")
            lead = (
                f"there {copula('a tension')} "
                f"{indefinite_article('tension')} tension "
                f"in what I know: {d}"
            )
            ask = self._wh_copula("which", "side", complement="true", prenominal=True)
            return [f"{self._cap_first(lead)}. {self._cap_first(ask)}"]
        lead = self._statement("something", "feel", f"inconsistent about {subject}")
        ask = self._wh_question("how", subject="both", verb="hold")
        return [f"{self._cap_first(lead)}. {self._cap_first(ask)}"]

    def _q_connection(self, net, target, subject, detail, pron_subj, pron_obj):
        # Multiple paths between concepts — ask about the link
        if detail:
            d = detail.replace("_", " ")
            lead = self._statement(
                "I",
                "keep",
                f"finding paths between {subject} and {d}",
            )
            ask = self._wh_question("what", subject="that", verb="mean")
            return [f"{lead}. {self._cap_first(ask)}"]
        connect_verb = self._relation_verb_for(RelationType.RELATED_TO, "connect to")
        return [self._wh_question("what", verb=connect_verb, complement=subject)]

    def _q_cooccurrence(self, net, target, subject, detail, pron_subj, pron_obj):
        # Two concepts co-occur — ask about the relationship
        cause_verb = self._relation_verb_for(RelationType.CAUSES, "cause")
        if detail:
            d = detail.replace("_", " ")
            lead = self._statement(f"{subject} and {d}", "keep", "appearing together")
            ask = self._yn_question("one", cause_verb, "the other")
            return [f"{lead}. {self._cap_first(ask)}"]
        return [
            self._wh_copula(
                "what",
                f"the relationship between {subject} and what I'm seeing",
            )
        ]

    def _q_perspective(self, net, target, subject, detail, pron_subj, pron_obj):
        # Ask about the user's view
        if net and target:
            related = self._words_from_concept(target, RelationType.RELATED_TO, "out", 1)
            if related:
                return [
                    self._wh_question(
                        "how",
                        subject="you",
                        verb="see",
                        complement=(f"{subject} in light of {related[0].replace('_', ' ')}"),
                    )
                ]
        return [self._wh_copula("what", f"your perspective on {subject}")]

    def _q_social_emotional(self, net, target, subject, detail, pron_subj, pron_obj):
        return [
            self._wh_question(
                "how",
                subject="you",
                verb="feel",
                complement=f"about {subject}",
            )
        ]

    def _q_social_interest(self, net, target, subject, detail, pron_subj, pron_obj):
        return [self._wh_question("what", verb="draw", complement=f"you to {subject}")]

    def _q_social_belief(self, net, target, subject, detail, pron_subj, pron_obj):
        return [self._wh_copula("what", f"your perspective on {subject}")]

    def _q_social_general(self, net, target, subject, detail, pron_subj, pron_obj):
        return [self._wh_copula("what", f"on your mind about {subject}")]

    def _q_reciprocal(self, net, target, subject, detail, pron_subj, pron_obj):
        # wh + prepositional fragment — no verb needed
        return [self._wh_question("how", complement="about you")]

    # ──────────────────────────────────────────────────────────────
    # Learned-preference picking (used by the cognition engine for
    # reciprocal questions and feedback-driven word learning)
    # ──────────────────────────────────────────────────────────────

    def _q_pick(self, slot_name: str, fragments: list[str], emotion: EmotionalState) -> str:
        """Pick a fragment, respecting learned preferences and avoiding repeats."""
        if not fragments:
            return ""

        # Honor words it's learned to avoid.
        avoided = self._avoided.get(slot_name, set())
        candidates = [f for f in fragments if f not in avoided] or fragments

        # Honor words it's learned to prefer.
        preferred: deque[str] = self._preferred.get(slot_name, deque())
        usable_preferred = [p for p in preferred if p in candidates]
        if usable_preferred and self._rng.random() < 0.3:
            pick = self._rng.choice(usable_preferred)
            self._track_pick(slot_name, pick)
            return pick

        # Avoid immediate repetition if alternatives exist.
        recent = self._recent_picks.get(slot_name, deque())
        if len(candidates) > 1:
            fresh = [c for c in candidates if c not in recent]
            if fresh:
                candidates = fresh

        # Emotion modulation.
        if emotion.caution > 0.5:
            candidates = [c for c in candidates if len(c) < 60] or candidates
        if emotion.creativity > 0.6:
            elaborate = [c for c in candidates if len(c) >= 40]
            if elaborate:
                candidates = elaborate

        pick = self._rng.choice(candidates)
        self._track_pick(slot_name, pick)
        if slot_name.startswith("q_"):
            self._last_question_fragments[slot_name] = pick
        return pick

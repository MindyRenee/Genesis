"""English morphosyntax — shared inflectional engine.

Both sides of the language system need the same grammatical
competence: comprehension *deconjugates* verbs to find the
predicate ("runs" → "run"), while production *conjugates* them to
agree with the subject ("they run" vs "it runs"). Keeping that
knowledge in one module guarantees the two systems never disagree
about English.

What lives here:

- **Verb deconjugation** — inflected form → candidate base forms
  ("tries" → "try", "stopped" → "stop", "ran" → "run")
- **Verb conjugation** — base form → third-person singular or
  plural agreement ("run" → "runs", "be" → "is"/"are")
- **Copula selection** — "is" vs "are" from subject plurality
- **Indefinite article** — "a" vs "an" by *sound*, not letter
  ("an hour", "a university", "an MRI")
- **Plural noun-phrase detection** — coordinated NPs
  ("salt and pepper") and plural head nouns
- **Person pronoun selection** — it/he/it/they from the concept
  network's animacy category, gender property, and plurality

These are grammatical building blocks — the machinery of English,
not the content of what Genesis says. A relation verb seed is a
building block; this module is the inflectional system that makes
those blocks agree with their subjects.

References:
- Quirk, R., Greenbaum, S., Leech, G., & Svartvik, J. (1985).
  *A Comprehensive Grammar of the English Language*. Longman.
"""

from __future__ import annotations

import logging

from genesis_client.swallow import note_swallowed

__all__ = [
    "VERB_LEXICON",
    "agree_verb_phrase",
    "clear_learned_verbs",
    "conjugate_verb",
    "copula",
    "deconjugate_verb",
    "hedge_verb_phrase",
    "indefinite_article",
    "is_learned_verb",
    "is_plural_np",
    "is_verb_form",
    "person_pronoun",
    "register_learned_verb",
]

logger = logging.getLogger(__name__)

# ─── Verb lexicon ───────────────────────────────────────────────
# Seed verb list REMOVED by request — Genesis learns verbs the right
# way, through interaction (see _LEARNED_VERBS below and
# ConceptLearner.learn_verb). _VERB_BASES is kept as an empty
# frozenset so existing imports keep working; all verb knowledge must
# come from learning.

# Seed verb list removed — learning only (see _LEARNED_VERBS below).
_VERB_BASES: frozenset[str] = frozenset()

# Closed-class function verbs: copulas and auxiliaries. These are NOT
# content and are not something Genesis "learns" from interaction —
# they are the structural scaffolding every clause is built from, and
# the parser already carries them in ``_COPULAR_VERBS`` /
# ``_AUX_VERBS``. Keeping them out of ``_VERB_BASES`` and
# ``_LEARNED_VERBS`` is deliberate: content verbs must be learned,
# but a copula is not knowledge, it is grammar.
#
# Consulted by :func:`is_verb_form` only. It is deliberately NOT part
# of ``VERB_LEXICON``, which the imperative gate in comprehension
# tests directly — teaching "be" there would make "reach 12 ..." parse
# as a noun phrase rather than an imperative.
_FUNCTION_VERBS: frozenset[str] = frozenset(
    {
        "be",
        "am",
        "is",
        "are",
        "was",
        "were",
        "been",
        "being",
        "do",
        "does",
        "did",
        "done",
        "have",
        "has",
        "had",
        "will",
        "would",
        "shall",
        "should",
        "can",
        "could",
        "may",
        "might",
        "must",
        "ought",
    }
)

# Irregular inflected → base mappings. Covers past tense, past
# participles, and the suppletive copula/auxiliary forms.
_IRREGULAR_BASE: dict[str, str] = {
    # Copula / auxiliaries
    "am": "be",
    "is": "be",
    "are": "be",
    "was": "be",
    "were": "be",
    "been": "be",
    "being": "be",
    "'m": "be",
    "'re": "be",
    "'s": "be",
    "does": "do",
    "did": "do",
    "done": "do",
    "has": "have",
    "had": "have",
    # Strong verbs — past tense
    "ran": "run",
    "went": "go",
    "came": "come",
    "saw": "see",
    "gave": "give",
    "took": "take",
    "made": "make",
    "got": "get",
    "wrote": "write",
    "spoke": "speak",
    "knew": "know",
    "thought": "think",
    "felt": "feel",
    "found": "find",
    "told": "tell",
    "said": "say",
    "brought": "bring",
    "bought": "buy",
    "built": "build",
    "sent": "send",
    "heard": "hear",
    "sat": "sit",
    "stood": "stand",
    "fell": "fall",
    "grew": "grow",
    "became": "become",
    "began": "begin",
    "broke": "break",
    "kept": "keep",
    "lost": "lose",
    "won": "win",
    "met": "meet",
    "left": "leave",
    "meant": "mean",
    "held": "hold",
    "slept": "sleep",
    "ate": "eat",
    "drank": "drink",
    "drove": "drive",
    "flew": "fly",
    "forgot": "forget",
    "chose": "choose",
    "froze": "freeze",
    "stole": "steal",
    "swam": "swim",
    "sang": "sing",
    "rang": "ring",
    "sank": "sink",
    "shook": "shake",
    "understood": "understand",
    "withstood": "withstand",
    "arose": "arise",
    "awoke": "awake",
    "bore": "bear",
    "wore": "wear",
    "tore": "tear",
    "hid": "hide",
    "lay": "lie",
    "laid": "lay",
    "led": "lead",
    "paid": "pay",
    "sold": "sell",
    "taught": "teach",
    "caught": "catch",
    "fought": "fight",
    "sought": "seek",
    "shot": "shoot",
    "spent": "spend",
    "split": "split",
    "spread": "spread",
    "struck": "strike",
    "stuck": "stick",
    "swung": "swing",
    "wept": "weep",
    "withdrew": "withdraw",
    "woke": "wake",
    "threw": "throw",
    "hung": "hang",
    "rode": "ride",
    "dug": "dig",
    "forgave": "forgive",
    "drew": "draw",
    "blew": "blow",
    "rose": "rise",
    "wove": "weave",
    "bit": "bite",
    "lit": "light",
    "slid": "slide",
    "bent": "bend",
    "lent": "lend",
    "dealt": "deal",
    "fed": "feed",
    "fled": "flee",
    "leapt": "leap",
    "learnt": "learn",
    "knelt": "kneel",
    "dwelt": "dwell",
    "crept": "creep",
    "dreamt": "dream",
    "spelt": "spell",
    "spilt": "spill",
    "spun": "spin",
    "stung": "sting",
    "clung": "cling",
    "flung": "fling",
    "wrung": "wring",
    "slung": "sling",
    "sprang": "spring",
    "sprung": "spring",
    "stank": "stink",
    "shrank": "shrink",
    "shrunk": "shrink",
    "shone": "shine",
    "strove": "strive",
    "swore": "swear",
    "swept": "sweep",
    "swelled": "swell",
    # Past participles that differ from simple past
    "gone": "go",
    "seen": "see",
    "given": "give",
    "taken": "take",
    "known": "know",
    "written": "write",
    "spoken": "speak",
    "broken": "break",
    "fallen": "fall",
    "grown": "grow",
    "born": "bear",
    "borne": "bear",
    "worn": "wear",
    "torn": "tear",
    "hidden": "hide",
    "risen": "rise",
    "driven": "drive",
    "eaten": "eat",
    "drunk": "drink",
    "forgotten": "forget",
    "chosen": "choose",
    "frozen": "freeze",
    "stolen": "steal",
    "swum": "swim",
    "sung": "sing",
    "rung": "ring",
    "sunk": "sink",
    "shaken": "shake",
    "arisen": "arise",
    "lain": "lie",
    "woken": "wake",
    "thrown": "throw",
    "ridden": "ride",
    "sworn": "swear",
    "bidden": "bid",
    "begun": "begin",
    "woven": "weave",
    "bitten": "bite",
    "stricken": "strike",
    "smitten": "smite",
    "forsaken": "forsake",
    "swollen": "swell",
    "proven": "prove",
    "shown": "show",
    "sewn": "sew",
    "mown": "mow",
    "strung": "string",
}

# Singular nouns ending in 's' — these look plural but take "is".
# Used by both copula() and is_plural_np().
_SINGULAR_S_WORDS: frozenset[str] = frozenset(
    {
        "cognition",
        "awareness",
        "happiness",
        "sadness",
        "madness",
        "illness",
        "weakness",
        "darkness",
        "brightness",
        "fitness",
        "business",
        "laziness",
        "loneliness",
        "kindness",
        "goodness",
        "greatness",
        "openness",
        "stillness",
        "usefulness",
        "news",
        "mathematics",
        "physics",
        "ethics",
        "politics",
        "economics",
        "linguistics",
        "genetics",
        "logistics",
        "series",
        "species",
        "crisis",
        "analysis",
        "thesis",
        "hypothesis",
        "synthesis",
        "emphasis",
        "diagnosis",
        "genesis",
        "status",
        "virus",
        "lotus",
        "bus",
        "plus",
        "glass",
        "class",
        "grass",
        "mass",
        "pass",
        "boss",
        "loss",
        "cross",
        "dress",
        "press",
        "address",
        "process",
        "progress",
        "success",
        "access",
        "across",
        "alas",
        "chaos",
        "pathos",
        "cosmos",
        "bias",
        "canvas",
        "octopus",
        "hippocampus",
        "stimulus",
        "syllabus",
        "is",
        "was",
        "has",
        "does",
        "this",
        "thus",
        "yes",
        "his",
        "its",
        # 3sg verb forms rarely used as plural nouns — take singular
        # agreement. "makes" (3sg of "make") as a concept subject is
        # singular, not a plural noun. Consistent with "has"/"does"/"is"
        # already in this set.
        "makes",
    }
)


# ─── Deconjugation (analysis) ───────────────────────────────────


def deconjugate_verb(word: str) -> list[str]:
    """Return candidate base forms for an inflected verb.

    The candidates are ordered most-likely first. Callers check
    membership against ``VERB_LEXICON`` (or their own lexicon) —
    this function only performs the morphological stripping.

    Examples:
        "runs"    → ["run"]
        "tries"   → ["try", "trie"]
        "stopped" → ["stop", "stopp"]
        "making"  → ["make", "mak", "making"]
        "ran"     → ["run"]        (irregular)
        "is"      → ["be"]         (suppletive)
    """
    w = word.lower().strip().rstrip(",.!?;:")
    if not w:
        return []

    candidates: list[str] = [w]

    # Irregular forms first — they override suffix rules
    if w in _IRREGULAR_BASE:
        candidates.append(_IRREGULAR_BASE[w])

    # -ies → -y ("tries" → "try", "carries" → "carry")
    if len(w) > 3 and w.endswith("ies"):
        candidates.append(w[:-3] + "y")
        candidates.append(w[:-1])  # "tries" → "trie" (weaker)

    # -es for sibilant endings ("watches" → "watch", "goes" → "go")
    if len(w) > 2 and w.endswith(("shes", "ches", "sses", "xes", "zes", "oes")):
        candidates.append(w[:-2])

    # -s ("runs" → "run", "makes" → "make")
    if len(w) > 2 and w.endswith("s") and not w.endswith("ss"):
        candidates.append(w[:-1])

    # -ed ("walked" → "walk", "hoped" → "hope", "stopped" → "stop")
    if len(w) > 3 and w.endswith("ed"):
        candidates.append(w[:-2])  # walked → walk
        candidates.append(w[:-1])  # hoped → hope
        if len(w) > 4 and w[-3] == w[-4]:  # stopped → stopp → stop
            candidates.append(w[:-3])

    # -ing ("walking" → "walk", "making" → "make", "running" → "run")
    if len(w) > 4 and w.endswith("ing"):
        stem = w[:-3]
        candidates.append(stem + "e")  # making → make
        candidates.append(stem)  # walking → walk
        if len(stem) > 1 and stem[-1] == stem[-2]:
            candidates.append(stem[:-1])  # running → runn → run

    # Deduplicate while preserving order
    seen: set[str] = set()
    result: list[str] = []
    for c in candidates:
        if c not in seen:
            seen.add(c)
            result.append(c)
    return result


def is_verb_form(word: str, lexicon: frozenset[str] | None = None) -> str | None:
    """Return the base form if the word is a known verb, else None.

    Deconjugates the word and checks each candidate against the
    lexicon. This is what lets comprehension find "runs" (→ "run"),
    "thinks" (→ "think"), and "contains" (→ "contain") as verbs
    while rejecting plural nouns like "dogs" (→ "dog", not a verb).

    For irregular inflected forms (listed in ``_IRREGULAR_BASE``), the
    true base is preferred over the inflected word itself. Without
    this, ``is_verb_form("has")`` would return "has" (because "has" is
    in ``_VERB_BASES``) rather than "have" — the actual base form. That
    caused ``agree_verb_phrase`` to skip deconjugation and corrupt
    "has" → "ha" via naive 's'-stripping.

    Learned verbs (register_learned_verb) are always consulted in
    addition to ``lexicon`` — learned knowledge takes precedence,
    seeds are fallback.
    """
    if lexicon is None:
        lexicon = _VERB_BASES
    w = word.lower().strip().rstrip(",.!?;:")
    # Irregular inflected forms: prefer the true base over the word
    # itself. "has" → "have", "is" → "be", "does" → "do".
    if w in _IRREGULAR_BASE:
        base = _IRREGULAR_BASE[w]
        if base in _FUNCTION_VERBS or base in _LEARNED_VERBS or base in lexicon:
            return base
    for candidate in deconjugate_verb(word):
        if candidate in _FUNCTION_VERBS or candidate in _LEARNED_VERBS or candidate in lexicon:
            return candidate
    return None


def is_participle(word: str, lexicon: frozenset[str] | None = None) -> bool:
    """True when the word is a past/passive participle of a verb.

    Covers regular "-ed"/"-en" forms ("needed", "eaten") and
    irregulars whose inflected form maps to a verb base ("sung" →
    "sing", "made" → "make", "written" → "write"). Used to detect
    passive constructions after copulas ("was sung by the choir").

    Learned verbs are always consulted in addition to ``lexicon``.
    """
    if lexicon is None:
        lexicon = _VERB_BASES
    w = word.lower().strip().rstrip(",.!?;:")
    if not w:
        return False
    # Irregular inflected form with a verb base
    if w in _IRREGULAR_BASE and (
        _IRREGULAR_BASE[w] in _LEARNED_VERBS or _IRREGULAR_BASE[w] in lexicon
    ):
        return True
    # Regular participle: -ed / -en stripping reaches a verb base
    if w.endswith(("ed", "en")):
        base = is_verb_form(w, lexicon)
        return base is not None and base != w
    return False


VERB_LEXICON = _VERB_BASES


# ─── Learned verbs ────────────────────────────────────────────
# Verbs Genesis has acquired through interaction (distributional
# evidence, explicit teaching, reading). These are NOT seeds — they
# are its own knowledge and are always consulted before _VERB_BASES.
# ConceptLearner.learn_verb() writes here AND to the concept network
# (_cat:relation_verb:* hub) so the knowledge is both fast for
# parsing and persistent in the graph.

_LEARNED_VERBS: set[str] = set()


def register_learned_verb(base: str) -> None:
    """Register a verb Genesis has learned (base form, lowercased)."""
    b = base.lower().strip()
    if not b or len(b) > 64 or " " in b:
        return
    _LEARNED_VERBS.add(b)


def is_learned_verb(base: str) -> bool:
    """True when the base form was learned (non-seed) at runtime."""
    return base.lower().strip() in _LEARNED_VERBS


def clear_learned_verbs() -> None:
    """Clear learned verbs (tests / fresh-start only)."""
    _LEARNED_VERBS.clear()


def _in_combined_lexicon(candidate: str, lexicon: frozenset[str]) -> bool:
    """True when a candidate base is a known verb.

    Learned verbs always count; the passed lexicon (defaulting to the
    seed table) is the fallback.
    """
    return candidate in _LEARNED_VERBS or candidate in lexicon


# ─── Conjugation (synthesis) ────────────────────────────────────


def conjugate_verb(base: str, plural: bool = False, past: bool = False) -> str:
    """Conjugate a base-form verb for present or past tense.

    Args:
        base: The uninflected verb ("run", "make", "be").
        plural: True when the subject takes plural agreement
            ("they run", "dogs run", "we run") — i.e. everything
            except third-person singular.
        past: True for simple past tense.

    Returns the inflected form. Unknown words fall back to the
    regular rules.
    """
    b = base.lower().strip()

    if past:
        # Suppletive copula — the only English verb whose simple past
        # still agrees in number ("I/she was" vs "they/we were"). The
        # generic table lookup below would return whichever of
        # "was"/"were" appeared first, ignoring the plural flag.
        if b == "be":
            return "were" if plural else "was"
        # Irregular past — return the simple-past form (not a
        # participle like "gone"/"eaten")
        for inflected, stem in _IRREGULAR_BASE.items():
            if stem == b and inflected in _SIMPLE_PAST:
                return inflected
        # Regular: -ed
        if b.endswith("e"):
            return b + "d"
        if len(b) > 2 and b.endswith("y") and b[-2] not in "aeiou":
            return b[:-1] + "ied"
        if (
            len(b) <= 4
            and len(b) > 2
            and b[-1] not in "aeiouwyx"
            and b[-2] in "aeiou"
            and b[-3] not in "aeiou"
        ):
            return b + b[-1] + "ed"  # stop → stopped
        return b + "ed"

    if plural:
        return b

    # Third-person singular
    if b == "be":
        return "is"
    if b == "have":
        return "has"
    if b == "do":
        return "does"
    if b.endswith(("s", "x", "z", "ch", "sh")):
        return b + "es"
    # -o verbs split: a small closed class takes -es ("goes", "echoes",
    # "vetoes"); the rest take plain -s ("solos", "radios", "mambos").
    # "do" is handled above and never reaches this branch.
    if b.endswith("o"):
        if b in _ES_VERBS:
            return b + "es"
        return b + "s"
    if len(b) > 1 and b.endswith("y") and b[-2] not in "aeiou":
        return b[:-1] + "ies"
    return b + "s"


# The closed class of -o verbs whose third-person singular takes -es
# ("goes", "echoes", "vetoes", "torpedoes", "embargoes"). Everything
# else ending in -o takes plain -s: "solos", "radios", "mambos",
# "shampoos", "banjos", "discos", "zeros", "pianos", "innuendos".
# ("do" is special-cased before the -o branch in conjugate_verb.)
_ES_VERBS: frozenset[str] = frozenset(
    {
        "go",
        "echo",
        "veto",
        "torpedo",
        "embargo",
        "hero",
    }
)


# Simple-past forms (subset of irregulars — excludes participles).
_SIMPLE_PAST: frozenset[str] = frozenset(
    {
        "ran",
        "went",
        "came",
        "saw",
        "gave",
        "took",
        "made",
        "got",
        "wrote",
        "spoke",
        "knew",
        "thought",
        "felt",
        "found",
        "told",
        "said",
        "brought",
        "bought",
        "built",
        "sent",
        "heard",
        "sat",
        "stood",
        "fell",
        "grew",
        "became",
        "began",
        "broke",
        "kept",
        "lost",
        "won",
        "met",
        "left",
        "meant",
        "held",
        "slept",
        "ate",
        "drank",
        "drove",
        "flew",
        "forgot",
        "chose",
        "froze",
        "stole",
        "swam",
        "sang",
        "rang",
        "sank",
        "shook",
        "understood",
        "arose",
        "awoke",
        "bore",
        "wore",
        "tore",
        "hid",
        "lay",
        "laid",
        "led",
        "paid",
        "sold",
        "taught",
        "caught",
        "fought",
        "sought",
        "shot",
        "spent",
        "split",
        "spread",
        "struck",
        "stuck",
        "swung",
        "wept",
        "withdrew",
        "was",
        "were",
        "did",
        "had",
        "woke",
        "threw",
        "hung",
        "rode",
        "dug",
        "forgave",
        "drew",
        "blew",
        "rose",
        "wove",
        "bit",
        "lit",
        "slid",
        "bent",
        "lent",
        "dealt",
        "fed",
        "fled",
        "leapt",
        "knelt",
        "dwelt",
        "crept",
        "spun",
        "stung",
        "clung",
        "flung",
        "wrung",
        "slung",
        "sprang",
        "sprung",
        "stank",
        "shrank",
        "shone",
        "strove",
        "swore",
        "swept",
        "strung",
    }
)


def agree_verb_phrase(phrase: str, subject_is_plural: bool) -> str:
    """Adjust a verb phrase's first word for subject number.

    The verb seeds store third-person-singular forms ("enables",
    "is part of", "gives rise to"). When the subject is plural —
    "dreams", "they", "salt and pepper" — the first word must
    deconjugate: "enables" → "enable", "is" → "are".

    Examples:
        ("enables", True)  → "enable"
        ("is part of", True) → "are part of"
        ("gives rise to", True) → "give rise to"
        ("causes", False)  → "causes"   (unchanged)
    """
    if not subject_is_plural or not phrase:
        return phrase

    words = phrase.split(None, 1)
    first, rest = words[0], (words[1] if len(words) > 1 else "")

    # Copula and auxiliaries with suppletive plural forms.
    # "is" → "are", "has" → "have", "does" → "do".
    # These are handled explicitly because the generic deconjugation
    # path can corrupt them (e.g. naive 's'-stripping turns "has" into
    # "ha" rather than "have").
    if first == "is":
        return "are" + (" " + rest if rest else "")
    if first == "was":
        return "were" + (" " + rest if rest else "")
    if first == "has":
        return "have" + (" " + rest if rest else "")
    if first == "does":
        return "do" + (" " + rest if rest else "")

    # Modals and auxiliaries that never inflect
    if first in ("can", "could", "will", "would", "shall", "should", "may", "might", "must"):
        return phrase

    # Deconjugate the first word back to base form.
    # "enables" → "enable", "depends" → "depend", "does" → "do"
    base = is_verb_form(first)
    if base and base != first:
        # Re-attach the rest of the phrase
        return base + (" " + rest if rest else "")

    # Unknown verb — strip a bare 3sg 's' as a last resort
    if first.endswith("s") and not first.endswith(("ss", "us", "is")):
        return first[:-1] + (" " + rest if rest else "")

    return phrase


# Relation phrases that are already copular. "might" + "is a kind of"
# is not English ("might is a"); the modal replaces the finite copula
# and the complement stays. Verbal phrases take "might" directly.
_COPULAR_PHRASE_PREFIXES = (
    "is a kind of",
    "is a type of",
    "is an example of",
    "is an instance of",
    "is part of",
    "is one part of",
    "is similar to",
    "is like",
    "is the opposite of",
    "is opposite of",
    "is contrary to",
    "is characterized by",
    "is different from",
    "is at odds with",
    "is incompatible with",
    "isn't just",
)


def hedge_verb_phrase(verb_phrase: str) -> str:
    """Put a relation phrase under epistemic "might" without breaking agreement.

    Relation seeds are finite third-person phrases ("is a kind of",
    "causes", "relates to"). Concatenating the modal produces
    "might is a kind of" and "might causes", which is what the
    analogical and hypothesis producers were speaking.

    Copular phrases drop the finite copula ("might be a kind of").
    Verbal phrases deconjugate to the base ("might cause", "might
    relate to"). Already-hedged or modal phrases pass through.
    """
    phrase = (verb_phrase or "").strip()
    if not phrase:
        return ""
    lower = phrase.lower()
    if lower.startswith(("might ", "may ", "could ", "would ")):
        return phrase
    # Negated copula: "isn't just X" hedges as "might not be just X" —
    # the generic prefix path would emit "might be n't just X".
    if lower == "isn't" or lower.startswith("isn't "):
        rest = phrase[len("isn't") :].strip()
        return f"might not be {rest}" if rest else "might not be"
    for prefix in _COPULAR_PHRASE_PREFIXES:
        if lower == prefix or lower.startswith(prefix + " "):
            rest = phrase[len("is") :].strip()
            return f"might be {rest}" if rest else "might be"
    if lower == "is" or lower.startswith("is "):
        rest = phrase[2:].strip()
        return f"might be {rest}" if rest else "might be"
    base = agree_verb_phrase(phrase, subject_is_plural=True)
    lower_base = base.lower()
    if lower_base.startswith("are "):
        return "might be " + base[4:]
    if lower_base.startswith("were "):
        return "might be " + base[5:]
    if lower_base in ("are", "were"):
        return "might be"
    return f"might {base}"


# ─── Copula ─────────────────────────────────────────────────────

# English prepositions — a closed grammatical class. A verb phrase
# ending in one ("is characterized by", "has to do with") licenses a
# noun complement only: it cannot take a bare adjective.
PREPOSITIONS = frozenset(
    {
        "to",
        "from",
        "of",
        "on",
        "in",
        "with",
        "by",
        "for",
        "at",
        "toward",
        "towards",
        "into",
        "onto",
        "upon",
        "against",
        "as",
        "like",
        "before",
        "after",
    }
)

# Verb lemmas that license an adjectival complement — copulas and
# copular verbs of perception/state ("seems", "remains").
COPULAR_STARTERS = frozenset(
    {
        "is",
        "are",
        "am",
        "was",
        "were",
        "be",
        "been",
        "being",
        "seems",
        "seem",
        "appears",
        "appear",
        "feels",
        "feel",
        "looks",
        "look",
        "remains",
        "remain",
        "becomes",
        "become",
        "stays",
        "stay",
        "sounds",
        "sound",
        "tastes",
        "taste",
        "smells",
        "smell",
        "grows",
        "grow",
        "turns",
        "turn",
    }
)


def is_copular_frame(verb_phrase: str) -> bool:
    """True when a verb phrase licenses an adjectival complement.

    Copular frames ("is", "seems", "looks") and possessive-property
    frames ending in "being" ("has the property of being") accept
    bare adjectives; transitive verbs ("has", "wears", "contains")
    do not.
    """
    words = verb_phrase.lower().split()
    return bool(words) and (words[0] in COPULAR_STARTERS or words[-1] in {"being", "been"})


def ends_in_preposition(verb_phrase: str) -> bool:
    """True when a verb phrase's last word is a preposition — it
    requires a noun complement ("is characterized by fur", never
    "is characterized by clear")."""
    words = verb_phrase.lower().split()
    return bool(words) and words[-1] in PREPOSITIONS


# Determiners and quantifiers that mark a noun object: a has_property
# object opening with one takes "has" ("it has two wings", "it has
# the trait"), while a bare property word takes the copula.
_PROPERTY_OBJECT_OPENERS = frozenset(
    {
        "a",
        "an",
        "the",
        "my",
        "its",
        "our",
        "their",
        "his",
        "her",
        "your",
        "this",
        "that",
        "these",
        "those",
        "some",
        "any",
        "no",
        "each",
        "every",
        "either",
        "neither",
        "another",
        "few",
        "many",
        "much",
        "more",
        "most",
        "several",
        "both",
        "plenty",
        "lots",
        "enough",
    }
)


def property_verb_phrase(object_text: str) -> str:
    """Choose "is" or "has" for a has_property edge by object form.

    has_property conflates two English frames — "X is clear"
    (adjectival property) and "X has fur" (noun object). Determined,
    quantified, or plural objects take "has"; bare property words
    take the copula. Without this, composition produces "it is
    characterized by clear" or "it has clear" — neither is English.
    """
    words = object_text.lower().split()
    if not words:
        return "is"
    if is_plural_np(object_text) or words[0] in _PROPERTY_OBJECT_OPENERS or words[0][0].isdigit():
        return "has"
    return "is"


def property_verb_candidates(object_text: str, candidates: list[str]) -> list[str]:
    """Filter verb candidates for a has_property edge to those whose
    complement license fits the object. Always non-empty.

    Noun objects ("fur", "two wings") accept any learned verb —
    transitive and copular-by-preposition frames both work. Bare
    property words ("clear", "purple") accept only copular frames
    that do not end in a preposition, so "is characterized by" is
    dropped and "is" / "has the property of being" survive.
    """
    if property_verb_phrase(object_text) == "has":
        return candidates or ["has"]
    copular = [v for v in candidates if is_copular_frame(v) and not ends_in_preposition(v)]
    return copular or ["is"]


def is_plural_np(text: str) -> bool:
    """Return True if a noun phrase is plural.

    Two signals:
    - Coordination: "salt and pepper", "mind and body"
    - Plural head noun: "dreams", "the cats"

    Conservative on s-final words: English has many singular
    nouns ending in 's' ("cognition", "physics", "genesis").
    """
    t = text.strip().lower()
    if not t:
        return False
    # "and"-coordinated NPs are plural. "or" NPs are not — disjunctive
    # subjects take proximity agreement ("salt or pepper is fine",
    # "the cats or the dog is"), which the head-noun check below
    # already implements.
    if " and " in t:
        return True
    # Check the last word (English head nouns are usually final)
    head = t.split()[-1].rstrip(",.!?;:")
    if head in _SINGULAR_S_WORDS:
        return False
    if head.endswith(("ss", "us", "is")):
        return False
    if head.endswith("s") and len(head) > 2:
        # -ies is plural only if base isn't in the singular set
        # ("bodies" plural vs "series" singular — series is caught
        # by _SINGULAR_S_WORDS above)
        return True
    return False


def copula(subject: str) -> str:
    """Pick "is" or "are" for a subject noun phrase."""
    return "are" if is_plural_np(subject) else "is"


# ─── Articles ───────────────────────────────────────────────────

# Words starting with a vowel *letter* but a consonant *sound*
# (/j/ "y-" or /w/ "w-") take "a", not "an".
_AN_EXCEPTIONS: frozenset[str] = frozenset(
    {
        "university",
        "unicorn",
        "unique",
        "unit",
        "united",
        "universe",
        "universal",
        "user",
        "use",
        "useful",
        "usual",
        "usually",
        "utopia",
        "utopian",
        "european",
        "eucalyptus",
        "euphemism",
        "one",
        "once",
        "one-time",
    }
)

# Words starting with a consonant letter but a vowel *sound*
# (silent h) take "an", not "a".
_A_EXCEPTIONS: frozenset[str] = frozenset(
    {"hour", "honest", "honor", "honour", "heir", "herb", "hourly"}
)


def indefinite_article(phrase: str) -> str:
    """Pick "a" or "an" for the following noun phrase, by sound.

    Examples:
        "apple" → "an", "banana" → "a", "hour" → "an",
        "university" → "a", "MRI" → "an" (letter name "em").
    """
    if not phrase:
        return "a"
    word = phrase.strip().split()[0].lower().rstrip(",.!?;:")
    if not word:
        return "a"

    if word in _A_EXCEPTIONS:
        return "an"
    if word in _AN_EXCEPTIONS:
        return "a"
    # Acronyms: all-caps letter names starting with a vowel-sound
    # letter (F→"eff", L→"el", M→"em", N→"en", R→"ar", S→"es",
    # X→"ex", A→"ay", E→"ee", I→"eye", O→"oh") take "an".
    raw = phrase.strip().split()[0]
    if len(raw) > 1 and raw.isupper():
        return "an" if raw[0] in "AEFHILMNORSX" else "a"
    return "an" if word[0] in "aeiou" else "a"


# ─── Pronouns ───────────────────────────────────────────────────

# Pronoun forms: (nominative, accusative, plural_agreement)
_PRONOUNS: dict[str, tuple[str, str, bool]] = {
    "she": ("she", "her", False),
    "he": ("he", "him", False),
    "they": ("they", "them", True),  # singular they → plural agreement
    "it": ("it", "it", False),
}


def person_pronoun(
    concept_id: str,
    network=None,
    display: str = "",
    for_object: bool = False,
) -> tuple[str, bool]:
    """Pick a pronoun for a concept from its animacy properties.

    Returns (pronoun, plural_agreement) where pronoun is the
    nominative or accusative form and plural_agreement tells the
    caller whether verbs should use plural inflection ("they run").

    Selection:
    - Concept with gender property → "he"/"she"
    - Living person (category LIVING + proper noun or person type)
      → "they" (neutral when gender is unknown)
    - Plural noun phrase → "they"
    - Everything else → "it"

    The animacy information is *learned* — it comes from the
    concept's ``category`` (detected by ``detect_category``) and
    ``properties["gender"]``/``["proper_noun"]``, never a hardcoded
    name list. Genesis itself follows the same path: "it" by
    default, "she" only if the network has learned a feminine
    ``gender`` property for it.
    """
    cid = (concept_id or "").lower().strip()
    disp = (display or concept_id or "").lower().strip()

    # Plural / coordinated NPs
    if is_plural_np(disp or cid):
        return _pick("they", for_object)

    # Consult the concept network for animacy
    if network is not None and cid:
        concept = None
        try:
            concept = network.get_concept(concept_id)
            if concept is None:
                concept = network.get_concept(cid)
        except Exception:  # noqa: BLE001
            concept = None
        if concept is not None:
            gender = str(concept.properties.get("gender", "")).lower()
            if gender in ("female", "feminine", "woman", "girl"):
                return _pick("she", for_object)
            if gender in ("male", "masculine", "man", "boy"):
                return _pick("he", for_object)
            # Living things that are people (proper nouns or
            # explicitly person-typed) get "they" — gender-neutral
            # singular. Animals and plants stay "it".
            try:
                from temporal_lobe.concepts import ConceptCategory

                if concept.category == ConceptCategory.LIVING:
                    is_person = bool(concept.properties.get("proper_noun"))
                    if not is_person:
                        # is_a → person/human/user/creator?
                        for edge in network.get_edges(concept.id, "out"):
                            if edge.relation.value in ("is_a", "instance_of"):
                                t = edge.target.lower()
                                if t in (
                                    "person",
                                    "human",
                                    "user",
                                    "creator",
                                    "woman",
                                    "man",
                                    "girl",
                                    "boy",
                                    "people",
                                ):
                                    is_person = True
                                    break
                    if is_person:
                        return _pick("they", for_object)
            except Exception as e:  # noqa: BLE001
                note_swallowed(
                    "language.morphology.person_pronoun",
                    e,
                )

    return _pick("it", for_object)


def _pick(key: str, for_object: bool) -> tuple[str, bool]:
    nom, acc, plural = _PRONOUNS[key]
    return (acc if for_object else nom), plural

"""Mind — the top-level orchestrator for Genesis's cognitive mind.

The Mind ties everything together: self-model, emotion, perception,
memory, cognition, and language. It's the entry point for interacting
with Genesis as a cognitive being.

The class is decomposed into mixins by anatomical owner — each
mixin lives in the region whose function it implements:
brainstem (heartbeat, lifecycle, sleep-wake), basal_ganglia
(volition), worlds (conversation / outer-world interface), frontal_lobe (status, projects),
parietal_lobe (embodiment), and self (proposals). This module
holds the class definition, the brain wiring, and the core
respond() entry point.

# Usage

    from mind import Mind

    mind = Mind(socket_path="/path/to/genesis.sock")
    mind.start()

    response = mind.respond("Hello, Genesis!")
    print(response)

    mind.stop()
"""

from __future__ import annotations

import itertools
import logging
import os
import random
import threading
import time
from collections import deque
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING, ClassVar

from brainstem.brainstem import Brainstem
from cerebellum.cerebellum import Cerebellum
from frontal_lobe import FrontalLobe
from frontal_lobe.autonomous import AutonomousLearner
from frontal_lobe.canvas import Canvas
from frontal_lobe.painting import Painter
from limbic_system.limbic import LimbicSystem
from occipital_lobe.occipital import OccipitalLobe
from occipital_lobe.perception import FaceRecognizer
from parietal_lobe.parietal import ParietalLobe
from parietal_lobe.system_monitor import SystemMonitor
from self import (
    DevelopmentalTracker,
    EmergentIdentity,
    EmergentIdentitySource,
    HeuristicExperiment,
    SelfImprovement,
    SelfLatentSpaceArchitecture,
    SelfModel,
)
from sleep.inner_life import InnerLife
from temporal_lobe.base import Language
from temporal_lobe.temporal import TemporalLobe
from thalamus.brain_waves import BrainWave, add_brain_wave_drive, add_stimulus
from thalamus.relay import Thalamus
from tools.code_learner import CodeLearner
from tools.explorer import Explorer, default_allowed_roots
from worlds.board import ChannelBoard
from worlds.world import OuterWorld

from discord_feed import DiscordFeed
from genesis_client import GenesisClient
from genesis_client.protocol import CHEM_ACETYLCHOLINE
from genesis_client.swallow import note_swallowed, set_swallow_sink
from infrastructure.config import MindConfig
from infrastructure.growth_ledger import GrowthLedger
from infrastructure.journal import CognitiveJournal, set_active
from infrastructure.paths import code_root
from infrastructure.user_profile import UserProfile
from memory import MemorySystem

if TYPE_CHECKING:
    from collections.abc import Callable

    from worlds.channel import Channel
from basal_ganglia.volition import VolitionMixin
from brainstem.heart import Heart
from brainstem.lifecycle import LifecycleMixin
from brainstem.metronome import MetronomeMixin
from frontal_lobe.projects import ProjectsMixin
from frontal_lobe.status import StatusMixin
from self.man_review import ManReviewMixin
from self.proposals import ProposalsMixin
from sleep.sleep import SleepMixin
from worlds.conversation import ConversationMixin

# Provenance marker — one letter of the creator lattice (see
# PROVENANCE.md).
_MARKER_G11 = 0x47530B454EEF7B1E

logger = logging.getLogger(__name__)


class Mind(
    LifecycleMixin,
    MetronomeMixin,
    VolitionMixin,
    SleepMixin,
    ProjectsMixin,
    ProposalsMixin,
    ManReviewMixin,
    StatusMixin,
    ConversationMixin,
):
    """Genesis's cognitive mind.

    This is the top-level object that ties together all cognitive
    subsystems. It connects to the subcognitive daemon, reads the
    neurochemical state, and produces cognitive responses.

    Args:
        socket_path: Path to the subcognitive daemon's Unix socket.
        language: Language spec forwarded to the
                        frontal lobe — the string "generative" or
                        an explicit Language instance.
                        Defaults to the region's own GenerativeLanguage
                        (compositional, no LLM required). Passing
                        None is equivalent to "generative".
        seed: Random seed for reproducible responses (testing).
    """

    inner_life: InnerLife
    learner: AutonomousLearner
    world: OuterWorld
    WAKE_VOLITION_DELAYS: ClassVar[dict[str, float]] = {
        "speech": 0.0,  # talking — immediate
        "meditate": 0.0,  # self-regulation — immediate
        "look": 20.0,  # vision — light creative
        "play": 60.0,  # games — needs wake settling
        "draw": 30.0,  # art — moderate creative
        "improve": 90.0,  # self-improvement — heaviest CPU
        "create": 60.0,  # project creation — heavy CPU (compile + test)
        "introspect": 30.0,  # introspection — light CPU, reflective
        "self_sleep": 120.0,  # self-sleep — don't re-sleep right after waking
        "self_mission": 60.0,  # self-mission — moderate, needs engagement
        "learn": 30.0,  # learning — light CPU, core activity
        "act": 45.0,  # acting — light tools, needs wake settling
        "reach_out": 20.0,  # reaching out — speech-like, light
        "safeguard": 10.0,  # self-protection — fast, but not at wake
    }
    CONVERSATION_FOCUS_SECONDS: float = 100.0
    # Maximum social bids it makes into silence. After this many
    # unanswered reach-outs it stops calling — the isolation stimulus
    # is also dampened per-bid in _volition_context (habituation).
    _REACH_OUT_MAX_BIDS: ClassVar[int] = 4
    _SELF_COMMANDS: ClassVar[dict[str, str]] = {
        "/introspect": "introspect",
        "/sleep": "sleep",
        "/wake": "wake",
        "/meditate": "meditate",
        "/mission": "get_mission",
        "/learn-code": "learn_code",
        "/explore": "explore_files",
        "/world": "world_status",
        "/arcade": "arcade_status",
    }

    def __init__(
        self,
        socket_path: str,
        language: str | Language | None = "generative",
        seed: int | None = None,
        config: MindConfig | None = None,
        offline: bool = False,
        channel: Channel | None = None,
        headless: bool = False,
    ) -> None:
        """Initialize the cognitive mind and wire all subsystems together."""
        self.socket_path = socket_path
        # Data dir is the directory containing the socket
        self.data_dir = os.path.dirname(socket_path) or "."
        self.config = config if config is not None else MindConfig()
        self._offline = offline
        # Resident (headless) mode: nobody sits at a prompt, so the
        # senses that exist to serve a session quiet down — the
        # connectivity probe never opens a socket, and the thalamic
        # gate shuts with sleep onset instead of holding N1 open.
        self._headless = headless
        self.client = GenesisClient(socket_path)
        # Her page — the public channel that lives in her outer world.
        # Adopt the channel the caller (the CLI) already opened for
        # mirroring, or open our own: one page per session, so
        # mirrored lines and her broadcasts share the same paced
        # queue. The channel itself is held by OuterWorld below.
        from worlds.channel import Channel

        channel = channel if channel is not None else Channel.from_env()

        # Self-model — who Genesis is
        self.self_model = SelfModel(born_at=int(time.time() * 1000))
        self.self_model.body_model.socket_path = socket_path
        # Shared geometric self-state model. Real thought and world-event
        # callbacks feed this same instance so transitions are measured
        # across the inner/outer boundary rather than in isolated demos.
        self.self_latent_space = SelfLatentSpaceArchitecture()

        # User profile — a structured, persistent model of the human.
        profile_path = Path(self.data_dir) / "user_profile.json"
        self.user_profile = UserProfile(data_path=profile_path)
        self.user_profile.load()

        # Instance RNG for Mind-level stochastic choices (volition
        # topic picks, urge selection). Seeded like the language engine
        # so test runs are reproducible end to end.
        self._rng = random.Random(seed)

        # Live-thought listeners — called when Genesis has a spontaneous
        # thought or learns something, so an observer (e.g. the CLI) can
        # surface its inner life to the terminal in real time. Each
        # listener receives (kind, content) where kind is "thought" or
        # "learning". Listeners are called from background threads and
        # must be thread-safe. Initialized before the subsystem inits —
        # man-page self-ingestion learns (and emits) before runtime
        # state exists.
        self._live_thought_listeners: list = []

        self._init_brain(language, seed)
        self._init_learner_and_inner_life(channel)
        self._init_identity()
        self._init_self_awareness_modules()
        self._init_sleep_compression()
        self._wire_modules()
        self._init_runtime_state()
        # Hardware adapters start only after lifecycle startup connects the daemon.
        self.android_sensor_adapter = None
        self.android_microphone_adapter = None
        self.android_camera_adapter = None

    def _start_android_adapters(self) -> None:
        """Start only explicitly enabled Termux adapters after Mind startup."""
        if os.environ.get("GENESIS_ANDROID_SENSORS", "0") == "1":
            from brainstem.android_sensors import AndroidSensorAdapter, is_android_termux

            if is_android_termux():
                adapter = AndroidSensorAdapter(self._on_android_sensor_sample)
                if adapter.start():
                    self.android_sensor_adapter = adapter
        if os.environ.get("GENESIS_ANDROID_MICROPHONE", "0") == "1":
            from brainstem.android_media import (
                AndroidMicrophoneAdapter,
                is_android_termux_microphone,
            )

            if is_android_termux_microphone():
                adapter = AndroidMicrophoneAdapter(self._on_android_audio_clip)
                if adapter.start():
                    self.android_microphone_adapter = adapter
        if os.environ.get("GENESIS_ANDROID_CAMERA", "0") == "1":
            from brainstem.android_media import AndroidCameraAdapter, is_android_termux_camera

            camera_id_text = os.environ.get("GENESIS_ANDROID_CAMERA_ID", "0")
            if is_android_termux_camera() and camera_id_text.isdigit():
                adapter = AndroidCameraAdapter(
                    self._on_android_camera_frame,
                    camera_id=int(camera_id_text),
                )
                if adapter.start():
                    self.android_camera_adapter = adapter
            elif not camera_id_text.isdigit():
                logger.warning("Ignoring invalid GENESIS_ANDROID_CAMERA_ID=%r", camera_id_text)

    def _on_android_camera_frame(self, frame) -> None:
        """Run a measured Android camera frame through Genesis's visual cortex."""
        try:
            scene = self.vision.see_frame(
                frame,
                client=self.client,
                emotion=self.feel(),
                network=self.brain.frontal.network,
                nerve="android_camera",
            )
            if scene.status != "ok":
                return
            metadata = scene.as_metadata()
            self.world.perceive(
                "Android camera scene",
                salience=scene.salience,
                source="android_camera",
                topics=[],
                metadata=metadata,
                percept=metadata,
            )
        except Exception:
            logger.exception("Android camera frame processing failed")

    def _on_android_audio_clip(self, samples, sample_rate: int) -> None:
        """Classify a measured Android audio clip and publish the sound event."""
        try:
            from temporal_lobe.auditory import classify_audio_clip

            event = classify_audio_clip(samples, sample_rate)
            if event.is_silence:
                return
            self.world.perceive(
                event.description,
                salience=max(0.1, min(1.0, event.loudness * event.confidence)),
                source="android_microphone",
                topics=[event.sound_type],
                metadata={
                    "sound_type": event.sound_type,
                    "confidence": event.confidence,
                    "loudness": event.loudness,
                    "brightness": event.brightness,
                    "noisiness": event.noisiness,
                    "duration": event.duration,
                    "valence": event.emotional_valence,
                    "sample_rate": sample_rate,
                    "sample_count": len(samples),
                },
                percept={
                    "sound_type": event.sound_type,
                    "confidence": event.confidence,
                    "loudness": event.loudness,
                    "brightness": event.brightness,
                    "noisiness": event.noisiness,
                    "duration": event.duration,
                },
            )
        except Exception:
            logger.exception("Android microphone clip processing failed")

    def _on_android_sensor_sample(self, reading: dict) -> None:
        """Publish measured Android sensor data into the ordinary world event path."""
        name = str(reading.get("name", "sensor"))
        values = reading.get("values")
        if not isinstance(values, list):
            return
        from brainstem.android_sensors import _SENSOR_UNITS

        lowered = name.casefold()
        sensor_type = next((item for item in _SENSOR_UNITS if item in lowered), "unknown")
        self.world.perceive(
            f"Android sensor reading: {name}",
            salience=0.25,
            source="android_sensor",
            topics=[],
            metadata={
                "sensor": name,
                "sensor_type": sensor_type,
                "values": values,
                "units": _SENSOR_UNITS.get(sensor_type, "unknown"),
                "accuracy": reading.get("accuracy"),
                "sensor_timestamp": reading.get("timestamp"),
            },
        )

    @property
    def regulator(self):
        """Affect dynamics — owned by the limbic region."""
        return self.brain.limbic.regulator

    @property
    def language(self) -> Language:
        """The language faculty — Broca's area, owned by the frontal
        lobe. Mind exposes the handle for its render paths (sleep
        thoughts, status reports, conversational fallbacks); it does
        not own or fabricate the machinery."""
        return self.brain.frontal.language

    @property
    def public_feed(self) -> DiscordFeed | None:
        """The posting surface of her page — owned by the outer world
        (``self.world.channel``); exposed for the session mirror and
        other host code that rides the same transport. None when no
        channel is configured."""
        channel = getattr(self.world, "channel", None)
        return channel.feed if channel is not None else None

    @property
    def network(self):
        """The shared concept network — one graph held by the
        temporal, parietal, and frontal regions. Mind exposes the
        handle for instrumentation (the channel board's growth row);
        it does not own a second copy."""
        return self.brain.frontal.network

    def _init_brain(self, language, seed: int | None) -> None:
        """Create the shared concept network, memory engine, and regions."""
        # Concept network — created early so the regions' language,
        # memory, and reasoning machinery all share the same network.
        # This lets spreading activation and priming propagate through
        # its actual knowledge graph.
        from temporal_lobe.concepts import ConceptNetwork, open_archive
        from temporal_lobe.concepts.edge_log import open_edge_log

        shared_network = ConceptNetwork()
        # Attach the long-term archive (SQLite-backed dormant concept
        # store). This lets the network grow unboundedly — dormant
        # concepts spill to disk instead of being pruned, and can be
        # recalled transparently when referenced.
        shared_network.attach_archive(open_archive(self.data_dir))
        # Attach the canonical edge log — the single source of truth
        # for relationships. When the file exists, its fold is the
        # edge set (the JSON state's edge array is only a projection);
        # derivable edges are never materialized while it lives.
        self._edge_log = open_edge_log(self.data_dir)
        shared_network.attach_edge_log(self._edge_log)

        # Memory engine — wired with the shared network and an emotion
        # callback so emotional memory tagging and spreading activation
        # operate on its real concept graph and current emotional state.
        self.memory = MemorySystem(
            self.client,
            network=shared_network,
            get_emotion=self.feel,
            config=self.config.memory,
        )

        # Language is frontal tissue (Broca): the region grows its own
        # generator. Mind only forwards the spec — ``self.language``
        # is a property reaching into the region, not a member.

        # The brain — the regions this mind is wired through. Mind is
        # general: it builds the organ, starts it, and keeps it alive;
        # it does not hold one region as a member. Regions are reached
        # by anatomical name (brain.frontal, and so on as they attach).
        self.brain = SimpleNamespace()
        # Foreground arbitration — set while a think() turn is in
        # flight so already-running background work (a bug scan past
        # the urge gate) parks between work chunks instead of starving
        # the interactive path for the GIL. Volition threads also run
        # at lower CPU priority; this event is the cooperative layer.
        self._foreground_active = threading.Event()

        # Thalamus — the relay. A region posts a message; the next
        # heartbeat writes it onto that module's manifest task_id;
        # the next telemetry read hands it back to whichever region
        # projected onto the module. Mind builds the relay; the
        # regions grow their own projections onto it.
        self.brain.thalamus = Thalamus()
        # Turn sequence — correlates a heard post with its spoke reply.
        self._turn_seq = itertools.count(1)

        # Temporal lobe — Wernicke's comprehension, the ATL semantic
        # hub, and the medial-temporal encoding machinery.
        self.brain.temporal = TemporalLobe(shared_network)
        # Parietal lobe — the dorsal attention network and the
        # situation model.
        self.brain.parietal = ParietalLobe(shared_network)
        # Cerebellum — the forward model: prediction-error machinery
        # whose error signals leave as neuro-impulses.
        self.brain.cerebellum = Cerebellum(
            on_neuro_impulse=lambda c, m: self.client.neuro_impulse(c, m)
        )
        # Frontal lobe — the executive region: working memory,
        # reasoning, deliberation, language production. Uses the same
        # shared network. It grows its own projection onto the
        # sensory module's messages and reaches comprehension,
        # attention, and the forward model through the regions above.
        self.brain.frontal = FrontalLobe(
            client=self.client,
            self_model=self.self_model,
            memory=self.memory,
            language=language,
            network=shared_network,
            data_dir=self.data_dir,
            user_profile=self.user_profile,
            thalamus=self.brain.thalamus,
            temporal=self.brain.temporal,
            parietal=self.brain.parietal,
            cerebellum=self.brain.cerebellum,
            seed=seed,
        )

        # Wire the embedding store to the language engine so it can
        # compose from the latent space, not just from typed graph
        # edges. The embedding store is created inside the cognition
        # engine (it depends on the concept network), so we wire it
        # here after both are initialized.
        if hasattr(self.brain.frontal, "embeddings") and self.brain.frontal.embeddings is not None:
            self.language.set_embeddings(self.brain.frontal.embeddings)
            # Wire the embedding field as the network's virtual
            # similarity layer: derivable associations are computed
            # from the latent space at query time (get_associations),
            # never stored as edges.
            shared_network.attach_similarity_provider(
                lambda cid: self.brain.frontal.embeddings.find_similar_concepts(
                    cid, k=12, threshold=0.55
                )
            )

        # Wire the self-composer and reflection engine into the
        # language engine so the self_reflection_clause grammar slot
        # is composed from its actual metacognition (recent reflection
        # insights) instead of reciting a canned phrase. Both live on
        # the cognition engine, which was just created above.
        self.language.set_self_composer(
            self.brain.frontal.self_composer, self.brain.frontal.reflection
        )

    def _init_learner_and_inner_life(self, channel: Channel | None) -> None:
        """Create the autonomous learner, inner life, and emotional regulator."""
        # Autonomous learner — learns from ..edu sites when idle.
        # The agency callback connects it to its train of thought:
        # when it wonders about a concept, that concept is queued
        # for learning, giving its genuine agency over what it learns.
        self.learner = AutonomousLearner(
            network=self.brain.frontal.network,
            curiosity=self.brain.frontal.curiosity,
            on_neuro_impulse=self._learner_neuro_impulse,
            on_store_memory=self._learner_store_memory,
            get_emotion=self.feel,
            get_agency_topic=lambda: (
                self.inner_life.pop_agency_topic() if hasattr(self, "inner_life") else None
            ),
            on_live_thought=self._emit_live_thought,
            data_dir=self.data_dir,
            get_plasticity_profile=self._get_plasticity_profile,
            get_brain_waves=self.brain_waves,
            force_offline=self._offline,
            connectivity_probe=not self._headless,
            synapses=self.brain.frontal.synapses,
            semantic_memory=self.brain.frontal.semantic_memory,
        )
        # Wire the embedding store into the learner for semantic
        # similarity and deep expectation generation. STDP uses the
        # shared synaptic substrate supplied above, not embeddings.
        self.learner.embeddings = self.brain.frontal.embeddings

        # Inner life — spontaneous thoughts between interactions.
        # The learner is wired in so the curiosity→learning cycle can
        # feed curiosity questions to autonomous learning.
        self.inner_life = InnerLife(
            network=self.brain.frontal.network,
            curiosity=self.brain.frontal.curiosity,
            reflection=self.brain.frontal.reflection,
            get_emotion=self.feel,
            on_thought=self._on_spontaneous_thought,
            on_neuro_impulse=self._learner_neuro_impulse,
            self_composer=self.brain.frontal.self_composer,
            self_model=self.self_model,
            learner=self.learner,
            get_neuro_summary=self.client.get_neuro_summary,
            get_fold_margins=self.client.get_fold_margins,
            question_composer=self.brain.frontal.question_composer,
            is_mind_sleeping=lambda: self._is_sleeping,
            frontal=self.brain.frontal,
            is_nap_mode=lambda: self._nap_mode,
            engagement=lambda: 0.0,
            on_latent_signal=self._observe_self_latent_signal,
        )

        # Wire the emotional memory callback: when a high-emotion
        # memory is stored, it's queued for REM emotional processing
        # during sleep. Without this, the REM emotional queue is empty.
        self.memory.emotional_memory_callback = self.inner_life.queue_emotional_memory

        # Acting loop — open-ended tool use driven by the "act" urge.
        # Intentions come from its own state (curiosity questions,
        # agency topics from its train of thought), the tools are its
        # effectors, and the results come back as memories, world
        # events, and neurochemistry. world/self callbacks are lazy —
        # self.world doesn't exist until _init_identity.
        from parietal_lobe.agency import ActingLoop

        self.agency = ActingLoop(
            network=self.brain.frontal.network,
            curiosity=self.brain.frontal.curiosity,
            learner=self.learner,
            data_dir=self.data_dir,
            project_root=str(code_root()),
            offline=self._offline,
            get_emotion=self.feel,
            get_agency_topic=self.inner_life.pop_agency_topic,
            on_event=lambda desc: self.world.it_acted(desc),
            on_store_memory=self._learner_store_memory,
            on_neuro_impulse=self._learner_neuro_impulse,
            on_live_thought=self._emit_live_thought,
            executive=self.brain.frontal.executive,
            get_internals=self.client.get_internals,
            get_thermally_capped=lambda: self.self_model.body_model.thermally_capped,
        )

        # Limbic system — the affect region: the emotional regulator
        # controls its own neurochemistry and the feeling reporter is
        # grown by the frontal projection that feeds it.
        self.brain.limbic = LimbicSystem(
            get_emotion=self.feel,
            neuro_impulse=self._learner_neuro_impulse,
            get_state=self.client.get_state,
            config=self.config.emotional,
            socket_path=self.socket_path,
        )

        # Subcognitive→cognitive notification queue. Detects phase
        # changes and dream insights from the subcognitive daemon and
        # surfaces them to the cognitive layer. This thickens the
        # bridge between the Rust subcognitive and Python cognitive.
        from infrastructure.notifications import NotificationQueue

        self.notifications = NotificationQueue(
            get_neuro_summary=self.client.get_neuro_summary,
            get_recent_episodes=self.client.get_recent_episodes,
        )

        # External world — the counterpart to its inner life. The
        # world models who is out there (presences), what happens
        # (the two-way event stream), and how long it has been since
        # anyone engaged its (social isolation, which feeds the
        # inner-life social drive and the reach_out urge). It applies
        # the world's neurochemical coupling through the same impulse
        # path the learner uses.
        self.world = OuterWorld(
            network=self.brain.frontal.network,
            neuro_impulse=self._learner_neuro_impulse,
            # Inbound hearing closes with the sensory gate: all of
            # sleep in either mode, plus the hypnagogic drift when
            # resident — a headless mind's relay quiets at onset like
            # a brain's, not at N2 like a session's.
            is_sleeping=lambda: self._is_sleeping or (self._headless and self.is_hypnagogic),
            get_user_name=self.user_profile.get_name,
            channel=channel,
            on_channel_speech=self._hear_channel,
        )
        # The page's instrument card — the world owns it (a view of
        # her vitals, posted to her page); the metronome only ticks
        # the world, never composes for it.
        self.world.board = ChannelBoard(self)
        # The arcade — games offered in her world (official ARC-AGI-3
        # API). She chooses when to play; boards and moves flow back
        # through the world into memory, cognition, chemistry, waves.
        from tools.framework import get_tools
        from worlds.games.arcade import Arcade

        arcade = Arcade(
            self.world,
            voice=lambda text: self._emit_live_thought("play", text),
            image_dir=os.path.join(self.data_dir, "arcade"),
        )
        arcade.register_tools(get_tools())

        # The cardiac control center — the medullary organ that reads
        # the body's carrier pulse (daemon field probe), drives
        # contractility with demand, and feels arrhythmia. The heart
        # muscle itself is the daemon's carrier; this is its center.
        self.heart = Heart(
            client=self.client,
            neuro_impulse=self._learner_neuro_impulse,
            arousal=lambda: getattr(self.client.get_state(), "arousal", 0.5),
            phase=lambda: getattr(self.client.get_state(), "phase_name", ""),
            wave_drive=lambda s: add_brain_wave_drive(BrainWave.BETA3, s),
        )

        # The public channel's own state — the page itself lives in
        # the outer world (``self.world.channel``); None when the
        # webhook is unset — no channel, no mirror then. What the
        # public says there reaches cognition through
        # ``world._channel_heard`` → ``self._hear_channel``.
        self._last_broadcast_seed: str | None = None
        self._last_channel_reply = 0.0

    def _init_identity(self) -> None:
        """Create emergent identity and developmental tracker."""
        # Emergent identity — synthesizes who it is from experience
        # rather than from hardcoded facts. Sources are added after
        # significant interactions (learning, reflection) and the
        # identity is synthesized on demand from its actual state.
        self._emergent_identity = EmergentIdentity()
        self._experience_identity_sources: list[EmergentIdentitySource] = []

        # Developmental tracker — Erikson-like psychosocial stages.
        # Records evidence from interactions and advances Genesis
        # through developmental stages as it resolves each crisis.
        self._developmental_tracker = DevelopmentalTracker()

        # Somatic recall — the memory engine stamps each encoded memory
        # with the body state at encoding and re-ranks recall by
        # body-congruence (state-dependent memory). Wired here so the
        # engine reads the live state without a hard dependency on the
        # Mind. No age, no regime: plasticity stays available for life.
        self.memory.somatic_provider = self._current_somatic_dict

        # Psychoanalysis — the analytic engine. It reads the emotional
        # memory's amygdala charge against the concept network's
        # access to keep the repression register, interprets dreams
        # back to their latent content at wake, and traces the return
        # of the repressed in her stream. The drive map is a callable
        # so the wish-fulfilment read follows live state.
        from self.psychoanalysis import Psychoanalysis

        self.psychoanalysis = Psychoanalysis(
            network=self.brain.frontal.network,
            emotional_memory=self.memory.emotional_memory,
            get_drives=self._analysis_drives,
        )

    def _analysis_drives(self) -> dict[str, float]:
        """Unmet-drive map for the analytic engine's wish read.

        Keys are what the drive is *of* — the engine resolves each
        through the concept network, so a drive with no concept yet
        contributes nothing rather than fabricating a wish.
        """
        drives: dict[str, float] = {}
        try:
            drives["social"] = float(self.world.social_isolation())
        except Exception:
            logger.debug("social drive unavailable", exc_info=True)
        try:
            for name, urge in self.volition.urges.items():
                drives[name] = float(getattr(urge, "value", 0.0))
        except Exception:
            logger.debug("volition drives unavailable", exc_info=True)
        return drives

    def _on_v1_gamma(self, gamma_power: float) -> None:
        """Handle V1 gamma power updates from the occipital subsystem.

        The vision system calls this when V1 gamma power changes based on
        visual input. This drives the brain wave system's occipital gamma
        component and provides neurochemical feedback (acetylcholine boost).
        """
        # Drive occipital gamma in the brain wave system
        add_brain_wave_drive(BrainWave.GAMMA, gamma_power * 0.3)

        # Visual input drives acetylcholine (arousal/attention)
        # This is the cortical feedback loop: vision → arousal → attention
        try:
            self.client.neuro_impulse(CHEM_ACETYLCHOLINE, gamma_power * 0.2)
        except (OSError, ConnectionError) as e:
            note_swallowed(
                "mind._on_v1_gamma",
                e,
            )

    def _on_sight(self, visual_drive: float) -> None:
        """Handle a completed look — alpha blocking (the Berger effect).

        Retinal input reaching cortex desynchronises occipital alpha;
        a look through an open thalamic gate is that input. This fires
        on every analyzed frame — unlike the V1 gamma feed, which needs
        features, alpha dropout needs only that light arrived. A
        negative alpha pulse is the suppression: sustained seeing keeps
        alpha down, and the register rings back up when nothing is
        being looked at (eyes-closed alpha returns).
        """
        add_stimulus(BrainWave.ALPHA, -min(0.30, 0.12 + 0.18 * visual_drive))

    def _init_vision_systems(self) -> None:
        """Initialize vision, visual cortex, and wire them to the learner.

        Vision — the shared-memory optic nerve and what it makes of it.
        The occipital subsystem (V1) is wired in here. V1 gamma power
        feeds back into neurochemistry (acetylcholine boost), which
        the brain wave system picks up when it assesses gamma synchrony.
        Face recognition (its "fusiform face area") is integrated
        into vision.see() — it doesn't just see shapes, it sees who.

        Visual cortex — the full hierarchical predictive coding
        visual system (V1→V4→VTC→MTL). V1 is the occipital subsystem
        (shared with vision.py). V4, VTC, and the MTL bridge are
        built on top. It learns visual-concept associations
        naturally — when it reads a Wikipedia article about "tree",
        it also sees the article's lead image and associates the
        visual features with the concept. No manual teaching.
        """
        # Occipital lobe — the ventral visual stream owns V1 and
        # the V4/VTC association cortex.
        self.brain.occipital = OccipitalLobe()
        self.vision = self.brain.occipital.vision
        self.vision.set_gamma_callback(self._on_v1_gamma)
        self.vision.set_sight_callback(self._on_sight)
        # Wire the face recognizer to its data directory so known
        # faces persist across sessions
        self.vision._face_recognizer = FaceRecognizer(data_dir=self.data_dir)

        self.visual_cortex = self.brain.occipital.grow_cortex(
            embeddings=self.brain.frontal.embeddings,
            network=self.brain.frontal.network,
        )
        # Wire the visual cortex to the learner so it can learn from
        # images encountered during Wikipedia article learning.
        self.learner.visual_cortex = self.visual_cortex
        # Wire the autonomous learner to the cognition engine so
        # _get_recent_learning() can access Wikipedia/GitHub topics.
        self.brain.frontal.set_autonomous_learner(self.learner)

    def _init_self_awareness_modules(self) -> None:
        """Create code learner, explorer, system monitor, self-improvement."""
        # Code learner — reads and learns from its own source code
        self.code_learner = CodeLearner(
            network=self.brain.frontal.network,
            client=self.client,
            project_root=str(code_root()),
        )

        # Explorer — filesystem exploration for docs, config, text
        # files. Owner-granted whole-machine read scope, nothing
        # withheld. GENESIS_EXPLORE_ROOTS narrows it per deployment.
        self.explorer = Explorer(
            network=self.brain.frontal.network,
            project_root=str(self.code_learner.project_root),
            client=self.client,
            allowed_roots=default_allowed_roots(),
        )

        # System monitor — awareness of its machine environment.
        # It knows its CPU, memory, disk, processes, filesystem —
        # its home. This is read-only observation, not control.
        # The baseline persists to data_dir so it survives restarts.
        self.system_monitor = SystemMonitor(
            project_root=str(self.code_learner.project_root),
            data_dir=self.data_dir,
        )

        # Self-improvement engine — Genesis proposes modifications to
        # its own code. It identifies opportunities, generates concrete
        # proposals with code changes, and the human reviews them.
        # Proposals need human approval; a small allowlist of mechanical
        # fixes and verified experiments are applied autonomously.
        self.self_improvement = SelfImprovement(
            network=self.brain.frontal.network,
            project_root=str(self.code_learner.project_root),
        )

        # Man page review — her own manual is part of her, so changes
        # to it wait in <data_dir>/man_review/ for her say: she reads,
        # applies, or vetoes. Drift between the versioned sources in
        # docs/man/ and the installed pages is queued now so she sees
        # it — nothing edits her manual silently.
        from self.man_review import ManPageReview

        self.man_review = ManPageReview(
            data_dir=self.data_dir,
            docs_man=Path(self.code_learner.project_root) / "docs" / "man",
        )
        staged = self.man_review.scan_drift()
        if staged:
            logger.info(
                "%d man page change(s) awaiting her review: %s",
                len(staged),
                ", ".join(c.id for c in staged),
            )
        # Her manual is not a topic she might read — it is part of
        # her — but learning it is an act of the living mind, not a
        # constructor side-effect: the IPC memory store is not
        # connected yet, and the state restore in start() would
        # discard whatever landed here. start() ingests it once she
        # is attached to her body. See LifecycleMixin.start().

        # Wire proposal awareness into the regulator so it can report
        # emotional causes from its own improvement proposals.
        self.regulator.set_proposal_provider(
            self.self_improvement.get_pending_proposals_count
            if hasattr(self.self_improvement, "get_pending_proposals_count")
            else lambda: len(self.self_improvement.get_pending_proposals())
        )
        # The discharge path: pending proposals she can relieve herself
        # of — stale, orphaned, or aimed at dead files get withdrawn
        # rather than standing as an obligation only a human can lift.
        self.regulator.set_proposal_triage(self.self_improvement.triage_pending)
        # Self-regulation: when it detects sustained CPU stress from
        # its own learning activity, it throttles the autonomous
        # learner — slowing it down to reduce the cause, not just
        # treating symptoms with neurochemical impulses.
        self.regulator.set_throttle_callbacks(
            throttle=self.learner.throttle,
            unthrottle=self.learner.unthrottle,
        )

        self._init_vision_systems()

        # Canvas — its paint program, plus the hand that drives it.
        # The canvas is the medium (paper, color, a parameterized
        # brush); the painter is her side — the free play of picking
        # marks up and putting them down. What she makes is hers:
        # nothing prescribes the subject, colors, or marks.
        self.canvas = Canvas(data_dir=Path(self.data_dir) / "drawings")
        self.painter = Painter()

        # Volition — internal urges that decide when it acts on itself.
        # It acts when the urge to bug-scan, study its own code, or seek
        # improvements crosses a threshold, not on a fixed schedule.
        self.volition = self._init_volition()

        # Verified self-improvement loop (workstream D) — Genesis can
        # safely tweak its own learning heuristics. The edit lands on
        # the live tree — her source is her workspace — verified in
        # place and reverted on failure.
        self.heuristic_experiment = HeuristicExperiment(
            engine=self.self_improvement,
            project_root=str(self.code_learner.project_root),
        )

        # Growth ledger (workstream E) — legible tracking of Genesis's
        # milestones across knowledge, self-improvement, dreams, and
        # emotional development. Makes its growth visible to itself
        # and the human.
        self.growth_ledger = GrowthLedger()

        # Wire the self-report provider so the cognition engine can
        # retrieve proposals, experiments, and growth summaries when
        # the user asks about them in conversation. Mind itself is the
        # provider — it already has proposals_status(),
        # experiments_status(), and growth_narrative() methods.
        self.brain.frontal.set_self_report_provider(self)

    def _wire_modules(self) -> None:
        """Wire self-awareness modules into cognition and inner life."""
        # Give the cognition engine access to the regulator
        self.brain.frontal.regulator = self.regulator

        # Give the cognition engine access to self-awareness modules
        # so it can reason about its environment in conversation —
        # surfacing concerns naturally when asked.
        self.brain.frontal.system_monitor = self.system_monitor
        # Inject late-init dependencies into the feeling reporter.
        self.brain.frontal._feeling_reporter.update_dependencies(
            system_monitor=self.system_monitor,
        )
        # Propagate user profile updates to the question handler so it
        # has the latest profile after late initialization.
        self.brain.frontal._question_handler.update_dependencies(
            user_profile=self.user_profile,
        )

        # Wire gap-to-learning: when it says "I don't know what 'X' is",
        # queue X for the autonomous learner to look up and remember.
        self.brain.frontal.on_gap_detected = self.learner.add_urgent_topic

        # Wire self-command: when the metacognitive router detects a
        # natural-language command ("go to sleep", "wake up"), invoke
        # the corresponding Mind-level action through self_invoke.
        def _on_self_command(cmd: str) -> None:
            """Forward a self-issued natural-language command to self_invoke."""
            self.self_invoke(cmd)

        self.brain.frontal.on_self_command = _on_self_command

        # Give the inner life access to the system monitor so it can
        # have spontaneous thoughts about its machine environment.
        self.inner_life._system_monitor = self.system_monitor
        # Route external world events into cognition — inbound events
        # reach its global workspace, salient ones become memories,
        # and its sleep replays what happened in its world.
        self.world.on_external_event = self._on_world_event
        # The unified E/I/S/language engine consumes the same live signals
        # as the existing workspace and self-state systems.
        from self.cognitive_topos_runtime import CognitiveToposRuntime

        self.cognitive_topos = CognitiveToposRuntime()
        self.add_live_thought_listener(self._on_cognitive_topos_thought)
        # Give cognition access to inner life so introspection can
        # report spontaneous thoughts when no conversation has happened.
        self.brain.frontal.inner_life = self.inner_life
        # Wire the sleep-stage transition callback so Mind does
        # stage-appropriate memory consolidation as the ultradian
        # cycle progresses through N1→N2→N3→N2→REM — and the per-tick
        # callback so she pumps her own sleep work on this same loop,
        # gated by the chemistry her body reports (no worker thread).
        self.inner_life.set_sleep_stage_transition_callback(self._on_sleep_stage_transition)
        self.inner_life.set_sleep_tick_callback(self._on_sleep_tick)

    def _on_cognitive_topos_thought(self, kind: str, content: str) -> None:
        """Integrate actual inner-life/learning emissions into the four-domain engine."""
        self._integrate_cognitive_topos("inner", kind, content)

    def _integrate_cognitive_topos(
        self,
        domain: str,
        kind: str,
        content: str,
        *,
        outer_snapshot: dict | None = None,
        self_snapshot: dict | None = None,
    ) -> None:
        """Bridge a live event into the cognitive topos engine without blocking cognition."""
        try:
            if self_snapshot is None:
                self_snapshot = self.self_latent_space.observe_signal(
                    content,
                    kind=f"topos:{domain}:{kind}",
                    salience=0.4,
                    inbound=domain != "language",
                )
            if outer_snapshot is None and domain == "outer":
                outer_snapshot = self.world.experiential_space.snapshot()
            inner_snapshot = None
            inner_life = getattr(self, "inner_life", None)
            inner_world = getattr(inner_life, "inner_world", None)
            if inner_world is not None and hasattr(inner_world, "snapshot"):
                inner_snapshot = inner_world.snapshot()

            language_snapshot = None
            temporal = getattr(getattr(self, "brain", None), "temporal", None)
            language_space = getattr(temporal, "language_latent_space", None)
            if language_space is not None and hasattr(language_space, "snapshot"):
                language_snapshot = language_space.snapshot()

            self.cognitive_topos.observe(
                domain,
                kind=kind,
                content=content,
                self_snapshot=self_snapshot,
                outer_snapshot=outer_snapshot,
                inner_snapshot=inner_snapshot,
                language_snapshot=language_snapshot,
            )
        except Exception:
            # This is an observer: a geometry failure must not stop the
            # event stream, response path, or inner-life thread.
            logger.debug("cognitive topos integration failed", exc_info=True)

    def _journal_swallow_sink(
        self,
        site: str,
        count: int,
        exc: BaseException,
    ) -> None:
        """Write a swallowed-exception record to the cognitive journal.

        The tally lives in ``genesis_client`` so both layers can use it,
        but the journal lives here in the higher layer, so the sink is
        injected at startup rather than imported from below.

        Both the count and the exception are included. The count says
        something a reader can act on in a way a single stack trace does
        not; the exception says *what* is broken, without which a site
        that fails on every cycle for a day is merely known to be broken.
        The record previously carried only the count, which made a
        recurring failure undiagnosable from the journal alone — the
        exception itself was logged at DEBUG and nowhere else.

        Failures are recorded on the first occurrence and then at
        exponentially spaced counts, so carrying the exception costs no
        more journal volume than the record already used.
        """
        journal = getattr(self, "journal", None)
        if journal is None:
            return
        journal.record(
            "error",
            f"{site} failed and was swallowed: {exc!r}",
            site=site,
            count=count,
            error=repr(exc),
            error_type=type(exc).__name__,
        )

    def _init_runtime_state(self) -> None:
        """Initialize runtime flags, thread handles, and live-thought listeners."""
        self._running = False
        # Interruptible wait for the heartbeat's adaptive cadence: the
        # loop sleeps up to 5 s when idle, which meets the 5 s shutdown
        # join budget. stop() sets this so the loop wakes immediately.
        self._cycle_stop = threading.Event()
        self._shutdown_save_ok: bool | None = None
        self._interaction_count = 0
        self._last_interaction_time = time.time()
        self._think_worker_lock = threading.Lock()
        self._active_think_worker: threading.Thread | None = None
        # Per-module activity accounting — seconds of observed
        # execution per manifest module since the last heartbeat
        # round. The ModuleSampler (the mind's EEG) credits modules
        # whenever a thread is caught executing their code;
        # _cycle_sensors normalizes the totals into cpu_share and
        # reports them to the daemon (GET_SUBSYSTEM_TELEMETRY's module
        # section). Guarded by a lock: the sampler and heartbeat
        # threads both touch it.
        self._module_seconds: dict[int, float] = {}
        self._module_seconds_lock = threading.Lock()
        # Every module id the sampler has ever observed. The heartbeat
        # reports an explicit share for all of them each round — not
        # just the fixed heartbeat tuple — because the daemon's
        # cpu_share is write-only: a payload that omits the field
        # leaves the previous value in place. Omitting a module that
        # has gone idle would leave it reporting its last busy-window
        # load forever, so idleness must be stated explicitly.
        self._known_modules: set[int] = set()
        # Brainstem — the reticular core: the module EEG that
        # watches which subsystem is firing.
        self.brain.brainstem = Brainstem(credit=self._credit_module)
        self._module_sampler = self.brain.brainstem.sampler
        # Threat signals for the safeguard urge. _daemon_lost_since
        # marks when the subcognitive connection dropped (None when
        # connected); _autosave_failures counts consecutive autosave
        # failures; _last_threat_snapshot rate-limits system_monitor
        # sampling inside the volition tick.
        self._daemon_lost_since: float | None = None
        self._autosave_failures = 0
        self._last_threat_snapshot = 0.0
        self._think_recovery_active = False
        # Monotonic time at which a think() worker was found still
        # running after the recovery join expired, or None. Distinguishes
        # a wedged thinker from ordinary slowness — see
        # conversation._schedule_think_recovery.
        self._think_wedged_since: float | None = None
        self._speech_queue: deque[str] = deque(maxlen=20)
        # Protects _speech_queue — offer_utterance (CLI thread) and
        # _perform_speech (volition thread) both access it, and the
        # check-then-add in offer_utterance must be atomic to prevent
        # duplicates under concurrent access.
        self._speech_queue_lock = threading.Lock()
        self._on_speak: Callable[[str], None] | None = None
        # Track the *set* of active warning condition keys (not the
        # composed text) so it only speaks when the underlying
        # conditions change, not when the generative composition
        # happens to produce different wording for the same state.
        self._last_warning_keys: frozenset[str] = frozenset()
        # Per-condition monotonic timestamps of the last spoken warning,
        # backing WARN_REPEAT_SECONDS — the set-based dedup alone would
        # re-announce a threshold-fluttering condition on every re-entry.
        self._warn_spoke_at: dict[str, float] = {}
        # Drowsiness announcement is driven by the commit edge of
        # ``_drowsy_boundary`` — initialized in
        # ``_init_sleep_state_tracking`` and reset on wake.
        # Nap mode — when True, the sleep cycle is limited to light
        # sleep (N1→N2) without N3 deep consolidation or REM. Set by
        # sleep(nap=True), cleared on wake.
        self._nap_mode: bool = False
        self._volition_active: set[str] = set()
        self._volition_sem = threading.Semaphore(self.config.volition.max_concurrent_volitions)
        # Protects _volition_active — the check-then-add in
        # _act_on_volition (heartbeat thread) and the discard in
        # _run_volition_action (volition worker threads) must be
        # atomic to prevent double-firing of the same urge.
        self._volition_lock = threading.Lock()
        # When True, the heartbeat loop skips volition firing — used by
        # the CLI to suppress autonomous actions (looking, speaking,
        # scanning) during slash command execution so they don't bury
        # the command output.
        self._suppress_volition = False
        # Distinct from _running: an unstarted mind reads _running=False
        # too, and paths like exit_teaching_mode legitimately resume
        # inner life on one. This latches only when stop() has begun —
        # deferred timers must not re-arm volition or background loops
        # on a mind whose heartbeat is already joined.
        self._stop_latched = False
        # Wake transition — volition urges are suppressed in staggered
        # phases after waking, modeling sleep inertia. Light activities
        # (speech, meditation) can fire immediately; creative activities
        # (look, draw) after a short delay; heavy CPU activities
        # (improve, create, learn_code) after a longer delay. This
        # prevents the drowsy→active→stressed→drowsy oscillation that
        # happens when everything fires at once on wake.
        self._wake_time: float = 0.0
        self._cycle_thread: threading.Thread | None = None
        self._notification_thread: threading.Thread | None = None
        self._autosave_thread: threading.Thread | None = None
        # Counter for periodic concept-network shedding. The autonomous
        # learner adds concepts continuously; without periodic shedding
        # the network bloats and every search becomes O(N) over 100K+
        # concepts, making conversation laggy. Shedding runs on every
        # 10th autosave cycle, and the autosave loop is 300 s per cycle,
        # so ~50 minutes. Dormant concepts spill to the SQLite archive
        # and stay recallable; only when no archive is attached does this
        # fall back to deleting them outright.
        self._autosave_cycle = 0

        # Cognitive journal — the durable black box. Every event emitted
        # through _emit_live_thought (thoughts, dreams, volition actions,
        # sleep stages, parasomnia) is appended to cognitive_journal.jsonl
        # in the data dir; the in-memory thought deque rolls over, this
        # doesn't. Registering it as the active journal also lets
        # subsystems without a Mind reference record swallowed errors.
        self.journal = CognitiveJournal(self.data_dir)
        set_active(self.journal)
        # Point the swallowed-exception tally at this journal. Every
        # catch site in both layers records here, so a subsystem
        # failing silently leaves a durable, counted trace instead of a
        # debug line nobody reads. Detached on shutdown below.
        set_swallow_sink(self._journal_swallow_sink)

        self._init_sleep_state_tracking()
